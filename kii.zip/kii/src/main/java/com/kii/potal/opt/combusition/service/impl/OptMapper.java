package com.kii.potal.opt.combusition.service.impl;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;

import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface OptMapper {
    //사용자 리스트
    
	List<CombusitionElementInDTO> getElementin(Map map) throws Exception;
	List<CombusitionElementInDTO> getElementinByname(Map map) throws Exception;
	
	List<CombusitionPipeAddDTO> getPipeadd(Map map) throws Exception;
	List<CombusitionPipeAddDTO> getPipeaddByname(Map map) throws Exception;
	
	
	List<CombusitionConsTantDTO> getConstant(Map map) throws Exception;
	List<CombusitionConsTantDTO> getConstantByField(Map map) throws Exception;
	List<CombusitionCpDTO> getCp(Map map) throws Exception;
	List<CombusitionCpDTO> getCpBytemp(Map map) throws Exception;
	
	List<CombusitionPipeOutDTO> getPipeout(Map map) throws Exception;
	List<CombusitionPipeOutDTO> getPipeoutByField(Map map) throws Exception;
	List<CombusitionPipeOutDTO> getPipeoutBygroupcd(Map map) throws Exception;
	
	void insertElementin(Map map)throws Exception;
	void insertPipeadd(Map map)throws Exception;
	void insertConstant(Map map)throws Exception;
	void insertPipeout(Map map)throws Exception;
	void insertCp(Map map)throws Exception;
	
	void updatePipeadd(Map map)throws Exception;
	void updateElementin(Map map)throws Exception;
	void updateConstant(Map map)throws Exception;
	void updatePipeout(Map map)throws Exception;
	void updatePipeoutValue(Map map)throws Exception;
	
	
	void delElementin(Map map)throws Exception;
	void delPipeadd(Map map)throws Exception;
	void delConstant(Map map)throws Exception;
	void delPipeout(Map map)throws Exception;
	void delCp(Map map)throws Exception;
	
}
