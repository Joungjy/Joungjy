package com.kii.potal.opt.combusition.service.impl;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaElement2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaElement2ServiceImpl extends EgovAbstractServiceImpl implements OptFormulaElement2Service {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap waste(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		pmap.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("code", OptConstant.wp_c_waste);
		List<CombusitionElementInDTO> wp_c_waste_list =  optMapper.getElementin(map);
		double wp_c_waste = wp_c_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_h_waste);
		List<CombusitionElementInDTO> wp_h_waste_list =  optMapper.getElementin(map);
		double wp_h_waste = wp_h_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_o_waste);
		List<CombusitionElementInDTO> wp_o_waste_list =  optMapper.getElementin(map);
		double wp_o_waste = wp_o_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_n_waste);
		List<CombusitionElementInDTO> wp_n_waste_list =  optMapper.getElementin(map);
		double wp_n_waste = wp_n_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_s_waste);
		List<CombusitionElementInDTO> wp_s_waste_list =  optMapper.getElementin(map);
		double wp_s_waste = wp_s_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_cl_waste);
		List<CombusitionElementInDTO> wp_cl_waste_list =  optMapper.getElementin(map);
		double wp_cl_waste = wp_cl_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_h2o_waste);
		List<CombusitionElementInDTO> wp_h2o_waste_list =  optMapper.getElementin(map);
		double wp_h2o_waste = wp_h2o_waste_list.get(0).getValue();
		
		map.put("code", OptConstant.mflow_waste);
		List<CombusitionElementInDTO> mflow_waste_list =  optMapper.getElementin(map);
		double mflow_waste = mflow_waste_list.get(0).getValue();
		
		
		map.put("code", OptConstant.ratio_exair_waste);
		List<CombusitionElementInDTO> ratio_exair_waste_list =  optMapper.getElementin(map);
		double ratio_exair_waste = ratio_exair_waste_list.get(0).getValue();
		
		map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		map.put("fieldnm", "molm_co2");
		List<CombusitionConsTantDTO> molm_co2_list =  optMapper.getConstantByField(map);
		double molm_co2 = molm_co2_list.get(0).getValue();
		
		map.put("fieldnm", "molm_n2");
		List<CombusitionConsTantDTO> molm_n2_list =  optMapper.getConstantByField(map);
		double molm_n2 = molm_n2_list.get(0).getValue();
		
		map.put("fieldnm", "molm_o2");
		List<CombusitionConsTantDTO> molm_o2_list =  optMapper.getConstantByField(map);
		double molm_o2 = molm_o2_list.get(0).getValue();
		
		map.put("fieldnm", "molm_h2o");
		List<CombusitionConsTantDTO> molm_h2o_list =  optMapper.getConstantByField(map);
		double molm_h2o = molm_h2o_list.get(0).getValue();
		
		map.put("fieldnm", "molm_so2");
		List<CombusitionConsTantDTO> molm_so2_list =  optMapper.getConstantByField(map);
		double molm_so2 = molm_so2_list.get(0).getValue();
		
		map.put("fieldnm", "molm_hcl");
		List<CombusitionConsTantDTO> molm_hcl_list =  optMapper.getConstantByField(map);
		double molm_hcl = molm_hcl_list.get(0).getValue();
		
		double ah_kg = 0.01469;
	    double ah_nm3 = (ah_kg * (0.21 * 32 + 0.79 * 28)) / 18;

		
	    double vuflow_oxygen_combst12 =
	    	      (molv_igas / 12) * (wp_c_waste / 100) +
	    	      (molv_igas / 2 / 2) * (wp_h_waste / 100) +
	    	      (molv_igas / 32) * (wp_s_waste / 100) -
	    	      ((molv_igas / 2 / 2) * (wp_cl_waste / 100)) / 35.5 -
	    	      (molv_igas / 32) * (wp_o_waste / 100);
	    double vuflow_iair_combst12 = vuflow_oxygen_combst12 / 0.2095;
	    	    
    	double vuflow_air_combst12 = ratio_exair_waste * vuflow_iair_combst12;
    	double vuflow_air1_combst12 = ratio_exair_waste * vuflow_iair_combst12 * (1 + ah_nm3);

    	double vuflow_co2_combst1 = ((molv_igas / 12) * wp_c_waste) / 100.0;
   
    	double vuflow_n2_combst1 = 0.7905 * vuflow_air_combst12 + ((molv_igas / 28) * wp_n_waste) / 100.0;
		    //
	    double vuflow_o2_combst1 = 0.2095 * (ratio_exair_waste - 1.0) * vuflow_iair_combst12;

	    double vuflow_h2o_combst1 =
			      ((molv_igas / 18) * wp_h2o_waste) / 100 +
			      ((molv_igas / 2) * (wp_h_waste - (0 * wp_cl_waste) / 35.5)) / 100 +
			      0 * ah_nm3 * vuflow_air_combst12;

	    double vuflow_so2_combst1 = ((molv_igas / 32) * wp_s_waste) / 100.0;
	    double vuflow_hcl_combst1 = ((molv_igas / 35.5) * wp_cl_waste) / 100.0;
	    double vuflow_gas_combst1 =
			      vuflow_co2_combst1 +
			      vuflow_n2_combst1 +
			      vuflow_o2_combst1 +
			      vuflow_h2o_combst1 +
			      vuflow_so2_combst1 +
			      vuflow_hcl_combst1;

			    // (2023-02-15,SHKim) 체적기준구성비 단위(%)를 고려하여 수식 변경 (기존식 * 100)
	    double vufp_co2_combst1 = (vuflow_co2_combst1 / vuflow_gas_combst1) * 100.0;
	    double vufp_n2_combst1 = (vuflow_n2_combst1 / vuflow_gas_combst1) * 100.0;
	    double vufp_o2_combst1 = (vuflow_o2_combst1 / vuflow_gas_combst1) * 100.0;
	    double vufp_h2o_combst1 = (vuflow_h2o_combst1 / vuflow_gas_combst1) * 100.0;
	    double vufp_so2_combst1 = (vuflow_so2_combst1 / vuflow_gas_combst1) * 100.0;
	    double vufp_hcl_combst1 = (vuflow_hcl_combst1 / vuflow_gas_combst1) * 100.0;

	    double muflow_co2_combst1 = (vuflow_co2_combst1 * molm_co2) / molv_igas;
	    double muflow_n2_combst1 = (vuflow_n2_combst1 * molm_n2) / molv_igas;
	    double muflow_o2_combst1 = (vuflow_o2_combst1 * molm_o2) / molv_igas;
	    double muflow_h2o_combst1 = (vuflow_h2o_combst1 * molm_h2o) / molv_igas;
	    double muflow_so2_combst1 = (vuflow_so2_combst1 * molm_so2) / molv_igas;
	    double muflow_hcl_combst1 = (vuflow_hcl_combst1 * molm_hcl) / molv_igas;
	    double muflow_gas_combst1 =
			      muflow_co2_combst1 +
			      muflow_n2_combst1 +
			      muflow_o2_combst1 +
			      muflow_h2o_combst1 +
			      muflow_so2_combst1 +
			      muflow_hcl_combst1;

			    //
			    // (2023-02-15,SHKim) 체적기준구성비 단위(%)를 고려하여 수식 변경 (기존식 * 100)
	    double mufp_co2_combst1 = (muflow_co2_combst1 / muflow_gas_combst1) * 100.0;
	    double mufp_n2_combst1 = (muflow_n2_combst1 / muflow_gas_combst1) * 100.0;
	    double mufp_o2_combst1 = (muflow_o2_combst1 / muflow_gas_combst1) * 100.0;
	    double mufp_h2o_combst1 = (muflow_h2o_combst1 / muflow_gas_combst1) * 100.0;
	    double mufp_so2_combst1 = (muflow_so2_combst1 / muflow_gas_combst1) * 100.0;
	    double mufp_hcl_combst1 = (muflow_hcl_combst1 / muflow_gas_combst1) * 100.0;

	    // 폐기물 연소 공기량 및 배가스 발생량 (Nm3/hr)
			   
	    double vflow_air_combst12 = mflow_waste * vuflow_air_combst12;
	    double vflow_gas_combst12 = mflow_waste * vuflow_gas_combst1;

	    map.put("groupcd", "5002");
	    map.put("fieldnm", "vuflow_iair_combst12");
		map.put("value", vuflow_iair_combst12);
		pmap.put("vuflow_iair_combst12", vuflow_iair_combst12);
		optMapper.updatePipeoutValue(map);
		
		
		map.put("fieldnm", "vuflow_air1_combst12");
		map.put("value", vuflow_air1_combst12);
		pmap.put("vuflow_air1_combst12", vuflow_air1_combst12);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vuflow_co2_combst1");
		map.put("value", vuflow_co2_combst1);
		pmap.put("vuflow_co2_combst1", vuflow_co2_combst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vuflow_n2_combst1");
		map.put("value", vuflow_n2_combst1);
		pmap.put("vuflow_n2_combst1", vuflow_n2_combst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vuflow_o2_combst1");
		map.put("value",vuflow_o2_combst1 );
		pmap.put("vuflow_o2_combst1", vuflow_o2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vuflow_h2o_combst1");
		map.put("value", vuflow_h2o_combst1);
		pmap.put("vuflow_h2o_combst1", vuflow_h2o_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vuflow_so2_combst1");
		map.put("value", vuflow_so2_combst1);
		pmap.put("vuflow_so2_combst1", vuflow_so2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vuflow_hcl_combst1");
		map.put("value", vuflow_hcl_combst1);
		pmap.put("vuflow_hcl_combst1", vuflow_hcl_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vuflow_gas_combst1");
		map.put("value", vuflow_gas_combst1);
		pmap.put("vuflow_gas_combst1", vuflow_gas_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vufp_co2_combst1");
		map.put("value", vufp_co2_combst1);
		pmap.put("vufp_co2_combst1", vufp_co2_combst1);
		optMapper.updatePipeoutValue(map);

		map.put("fieldnm", "vufp_n2_combst1");
		map.put("value", vufp_n2_combst1);
		pmap.put("vufp_n2_combst1", vufp_n2_combst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vufp_o2_combst1");
		map.put("value", vufp_o2_combst1);
		pmap.put("vufp_o2_combst1", vufp_o2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vufp_h2o_combst1");
		map.put("value", vufp_h2o_combst1);
		pmap.put("vufp_h2o_combst1", vufp_h2o_combst1);
		optMapper.updatePipeoutValue(map);


	    map.put("fieldnm", "vufp_so2_combst1");
		map.put("value", vufp_so2_combst1);
		pmap.put("vufp_so2_combst1", vufp_so2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vufp_hcl_combst1");
		map.put("value", vufp_hcl_combst1);
		pmap.put("vufp_hcl_combst1", vufp_hcl_combst1);
		optMapper.updatePipeoutValue(map);
//

	    map.put("fieldnm", "muflow_co2_combst1");
		map.put("value", muflow_co2_combst1);
		pmap.put("muflow_co2_combst1", muflow_co2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "muflow_n2_combst1");
		map.put("value", muflow_n2_combst1);
		pmap.put("muflow_n2_combst1", muflow_n2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "muflow_o2_combst1");
		map.put("value", muflow_o2_combst1);
		pmap.put("muflow_o2_combst1", muflow_o2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "muflow_h2o_combst1");
		map.put("value", muflow_h2o_combst1);
		pmap.put("muflow_h2o_combst1", muflow_h2o_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "muflow_so2_combst1");
		map.put("value", muflow_so2_combst1);
		pmap.put("muflow_so2_combst1", muflow_so2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "muflow_hcl_combst1");
		map.put("value", muflow_hcl_combst1);
		pmap.put("muflow_hcl_combst1", muflow_hcl_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "muflow_gas_combst1");
		map.put("value", muflow_gas_combst1);
		pmap.put("muflow_gas_combst1", muflow_gas_combst1);
		optMapper.updatePipeoutValue(map);
//

	    map.put("fieldnm", "mufp_co2_combst1");
		map.put("value", mufp_co2_combst1);
		pmap.put("mufp_co2_combst1", mufp_co2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "mufp_n2_combst1");
		map.put("value", mufp_n2_combst1);
		pmap.put("mufp_n2_combst1", mufp_n2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "mufp_o2_combst1");
		map.put("value", mufp_o2_combst1);
		pmap.put("mufp_o2_combst1", mufp_o2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "mufp_h2o_combst1");
		map.put("value", mufp_h2o_combst1);
		pmap.put("mufp_h2o_combst1", mufp_h2o_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "mufp_so2_combst1");
		map.put("value", mufp_so2_combst1);
		pmap.put("mufp_so2_combst1", mufp_so2_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "mufp_hcl_combst1");
		map.put("value", mufp_hcl_combst1);
		pmap.put("mufp_hcl_combst1", mufp_hcl_combst1);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vflow_air_combst12");
		map.put("value", vflow_air_combst12);
		pmap.put("vflow_air_combst12", vflow_air_combst12);
		optMapper.updatePipeoutValue(map);

	    map.put("fieldnm", "vflow_gas_combst12");
		map.put("value", vflow_gas_combst12);
		pmap.put("vflow_gas_combst12", vflow_gas_combst12);
		optMapper.updatePipeoutValue(map);
	    
		return pmap;
	}


}
