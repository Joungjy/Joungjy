package com.kii.potal.opt.combusition.dto;



import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class CombusitionCpDTO {
    private Long idx; 
    private Long wpid;
    private String cptype;
    private Long cpindex;
    private String statecd;
    private Long temp;
    private double o2;
    private double n2;
    private double co2;
    private double co;
    private double no;
    private double so2;
    private double h2o;
    private double hcl;
    private double airlo;
    private double mixgas;
    private double slope;
    private String createddate; 
    private String updateddate;
   


    @Builder
    public CombusitionCpDTO(Long idx, Long wpid, String cptype, Long cpindex, Long temp) {
        this.idx = idx;
        this.wpid = wpid;
        this.cptype = cptype;
        this.cpindex = cpindex;
        this.temp = temp;
    }
}
