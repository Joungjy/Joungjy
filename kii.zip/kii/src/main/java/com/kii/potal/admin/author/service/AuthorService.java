package com.kii.potal.admin.author.service;

import com.kii.potal.admin.author.dto.AuthorDTO;

import java.util.List;

public interface AuthorService {

    //권한 관리 리스트 조회
    List<AuthorDTO> getAuthortList( AuthorDTO authorDTO) throws  Exception;

    //권한 관리 상세 조회
    AuthorDTO getAuthorItem( AuthorDTO authorDTO) throws  Exception;
    
    //권한 관리 정보 등록
    void insertAuthorItem( AuthorDTO authorDTO) throws  Exception;
    
    //권한 관리 정보 수정
    void updateAuthorItem( AuthorDTO authorDTO) throws  Exception;
    
    //권한 관리 정보 삭제
    void deleteAuthorItem( AuthorDTO authorDTO) throws  Exception;



}
