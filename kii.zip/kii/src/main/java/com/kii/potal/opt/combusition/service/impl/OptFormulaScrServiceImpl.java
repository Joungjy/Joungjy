package com.kii.potal.opt.combusition.service.impl;



import java.util.HashMap;
import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaScrService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaScrServiceImpl extends EgovAbstractServiceImpl implements OptFormulaScrService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    double mflow_totalnh3_inSCR = 0;
    double mflow_cctnh3_inSCR = 0;
	@Override
	public HashMap mb_1_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		
		map.put("fieldnm", "vppm_no2_outBF");
		List<CombusitionPipeOutDTO> vppm_no2_inSCR_list = optMapper.getPipeoutByField(map);
		double vppm_no2_inSCR = vppm_no2_inSCR_list.get(0).getValue();
		pmap.put("vppm_no2_inSCR", vppm_no2_inSCR);
		
	    map.put("fieldnm", "vflow_h2o_outBF");
		List<CombusitionPipeOutDTO> vflow_h2o_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_h2o_inSCR = vflow_h2o_inSCR_list.get(0).getValue();
		pmap.put("vflow_h2o_inSCR", vflow_h2o_inSCR);
		
	    map.put("fieldnm", "vflow_o2_outBF");
		List<CombusitionPipeOutDTO> vflow_o2_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_o2_inSCR = vflow_o2_inSCR_list.get(0).getValue();
		pmap.put("vflow_o2_inSCR", vflow_o2_inSCR);
		
	    map.put("fieldnm", "vflow_gas_outBF");
		List<CombusitionPipeOutDTO> vflow_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inSCR = vflow_gas_inSCR_list.get(0).getValue();
		pmap.put("vflow_gas_inSCR", vflow_gas_inSCR);
		
		map.put("fieldnm", "k11_elno2_SCR");
		List<CombusitionConsTantDTO> k11_elno2_SCR_list =  optMapper.getConstantByField(map);
		double k11_elno2_SCR = k11_elno2_SCR_list.get(0).getValue();
		pmap.put("k11_elno2_SCR", k11_elno2_SCR);
		
	    map.put("fieldnm", "k5_no2_SCR");
		List<CombusitionConsTantDTO> k5_no2_SCR_list =  optMapper.getConstantByField(map);
		double k5_no2_SCR = k5_no2_SCR_list.get(0).getValue();
		pmap.put("k5_no2_SCR", k5_no2_SCR);
		
	    map.put("fieldnm", "molm_nh3");
		List<CombusitionConsTantDTO> molm_nh3_list =  optMapper.getConstantByField(map);
		double molm_nh3 = molm_nh3_list.get(0).getValue();
		pmap.put("molm_nh3", molm_nh3);
		
	    map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		pmap.put("molv_igas", molv_igas);
		
	    map.put("fieldnm", "unit_mega");
		List<CombusitionConsTantDTO> unit_mega_list =  optMapper.getConstantByField(map);
		double unit_mega = unit_mega_list.get(0).getValue();
		pmap.put("unit_mega", unit_mega);
		
	    // formula
		double vflow_drygas_inSCR = vflow_gas_inSCR - vflow_h2o_inSCR;
		double vpercent_o2_inSCR = vflow_o2_inSCR / vflow_gas_inSCR;
		double vflow_drygas_o2cal_inSCR = ((21 - vpercent_o2_inSCR) / (21 - 12)) * vflow_drygas_inSCR;
	    //
		double vppm_nox_outSCR = vppm_no2_inSCR * (1 - k11_elno2_SCR);
		double dvppm_nox_SCR = vppm_no2_inSCR - vppm_nox_outSCR;
	    
		pmap.put("vflow_drygas_inSCR", vflow_drygas_inSCR);
		pmap.put("vpercent_o2_inSCR", vpercent_o2_inSCR);
		pmap.put("vflow_drygas_o2cal_inSCR", vflow_drygas_o2cal_inSCR);
		pmap.put("vppm_nox_outSCR", vppm_nox_outSCR);
		pmap.put("dvppm_nox_SCR", dvppm_nox_SCR);
		
	    
		return pmap;
	}

	@Override
	public HashMap mb_2_1_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "vflow_n2_outBF");
		List<CombusitionPipeOutDTO>vflow_n2_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_n2_inSCR = vflow_n2_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_o2_outBF");
		List<CombusitionPipeOutDTO> vflow_o2_outBF_list = optMapper.getPipeoutByField(map);
		double vflow_o2_outBF = vflow_o2_outBF_list.get(0).getValue();
		
		
	    map.put("fieldnm", "k2_nonnh3_SCR");
		List<CombusitionConsTantDTO> k2_nonnh3_SCR_list =  optMapper.getConstantByField(map);
		double k2_nonnh3_SCR = k2_nonnh3_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k3_no2nnh3_SCR");
		List<CombusitionConsTantDTO> k3_no2nnh3_SCR_list =  optMapper.getConstantByField(map);
		double k3_no2nnh3_SCR = k3_no2nnh3_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k4_no_SCR");
		List<CombusitionConsTantDTO> k4_no_SCR_list =  optMapper.getConstantByField(map);
		double k4_no_SCR = k4_no_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k5_no2_SCR");
		List<CombusitionConsTantDTO> k5_no2_SCR_list =  optMapper.getConstantByField(map);
		double k5_no2_SCR = k5_no2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k7_nonnh3nn2_SCR");
		List<CombusitionConsTantDTO> k7_nonnh3nn2_SCR_list =  optMapper.getConstantByField(map);
		double k7_nonnh3nn2_SCR = k7_nonnh3nn2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k8_no2nnh3nn2_SCR");
		List<CombusitionConsTantDTO> k8_no2nnh3nn2_SCR_list =  optMapper.getConstantByField(map);
		double k8_no2nnh3nn2_SCR = k8_no2nnh3nn2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k9_nonnh3no2_SCR");
		List<CombusitionConsTantDTO> k9_nonnh3no2_SCR_list =  optMapper.getConstantByField(map);
		double k9_nonnh3no2_SCR = k9_nonnh3no2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k10_no2nnh3no2_SCR");
		List<CombusitionConsTantDTO> k10_no2nnh3no2_SCR_list =  optMapper.getConstantByField(map);
		double k10_no2nnh3no2_SCR = k10_no2nnh3no2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "min2hr");
		List<CombusitionConsTantDTO> min2hr_list =  optMapper.getConstantByField(map);
		double min2hr = min2hr_list.get(0).getValue();
		
	    map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		
	    map.put("fieldnm", "molm_nh3");
		List<CombusitionConsTantDTO> molm_nh3_list =  optMapper.getConstantByField(map);
		double molm_nh3 = molm_nh3_list.get(0).getValue();
		
	    map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
	
	    map.put("fieldnm", "rt_n2inair");
		List<CombusitionConsTantDTO> rt_n2inair_list =  optMapper.getConstantByField(map);
		double rt_n2inair = rt_n2inair_list.get(0).getValue();
		
	    map.put("fieldnm", "rt_o2inair");
		List<CombusitionConsTantDTO> rt_o2inair_list =  optMapper.getConstantByField(map);
		double rt_o2inair = rt_o2inair_list.get(0).getValue();
		
	    // pipe add (func: return value)
		map.put("fieldnm", "ea_nozzle_SCR");
		List<CombusitionPipeAddDTO> ea_nozzle_SCR_list = optMapper.getPipeaddByname(map);
		double ea_nozzle_SCR = ea_nozzle_SCR_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_airpea_inSCR");
		List<CombusitionPipeAddDTO> vflow_airpea_inSCR_list = optMapper.getPipeaddByname(map);
		double vflow_airpea_inSCR = vflow_airpea_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "t_air_inSCR");
		List<CombusitionPipeAddDTO> t_air_inSCR_list = optMapper.getPipeaddByname(map);
		double t_air_inSCR = t_air_inSCR_list.get(0).getValue();
	    // formula
	    double vflow_air_inSCR = vflow_airpea_inSCR * ea_nozzle_SCR * min2hr;
	   
	    double vflow1_n2_SCR =
	      ((((mflow_totalnh3_inSCR * molv_igas) / molm_nh3) * k7_nonnh3nn2_SCR) / k2_nonnh3_SCR) * k4_no_SCR;
	    double vflow2_n2_SCR =
	      ((((mflow_totalnh3_inSCR * molv_igas) / molm_nh3) * k8_no2nnh3nn2_SCR) / k3_no2nnh3_SCR) *
	      k5_no2_SCR;
	    double vflow3_n2_inSCR = vflow_air_inSCR * (ktemp / (ktemp + t_air_inSCR)) * rt_n2inair;
	    double vflow1_o2_SCR =
	      ((((mflow_totalnh3_inSCR * molv_igas) / molm_nh3) * k9_nonnh3no2_SCR) / k2_nonnh3_SCR) *
	      k4_no_SCR *
	      -1;
	    double vflow2_o2_SCR =
	      ((((mflow_totalnh3_inSCR * molv_igas) / molm_nh3) * k10_no2nnh3no2_SCR) / k3_no2nnh3_SCR) *
	      k5_no2_SCR *
	      -1;
	    double vflow3_o2_inSCR = vflow_air_inSCR * (ktemp / (ktemp + t_air_inSCR)) * rt_o2inair;

	    double vflow_totaln2_SCR =
	      vflow1_n2_SCR + vflow2_n2_SCR + vflow3_n2_inSCR;
	    
	    pmap.put("vflow_totaln2_SCR", vflow_totaln2_SCR);
	    
	    double vflow_totalo2_SCR =
	      vflow1_o2_SCR + vflow2_o2_SCR + vflow3_o2_inSCR;
	    pmap.put("vflow_totalo2_SCR", vflow_totalo2_SCR);
	    double vflow_n2_outSCR = vflow_n2_inSCR + vflow_totaln2_SCR;
	    double vflow_o2_inSCR = (double)pmap.get("vflow_o2_inSCR");
	    double vflow_o2_outSCR = vflow_o2_inSCR + vflow_totalo2_SCR;

	    // store to db
		map.put("fieldnm", "vflow_air_inSCR");
		map.put("value", vflow_air_inSCR);
		pmap.put("qo_total_SDR", vflow_air_inSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_n2_outSCR");
		map.put("value", vflow_n2_outSCR);
		pmap.put("vflow_n2_outSCR", vflow_n2_outSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_o2_outSCR");
		map.put("value", vflow_o2_outSCR);
		pmap.put("vflow_o2_outSCR", vflow_o2_outSCR);
		optMapper.updatePipeoutValue(map);
		
	    
		return pmap;
	}

	@Override
	public HashMap mb_2_2_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    // const vflow_h2o_inSCR = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_h2o_inSCR');
	    
	    map.put("fieldnm", "vflow_h2o_outBF");
		List<CombusitionPipeOutDTO> vflow_h2o_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_h2o_inSCR = vflow_h2o_inSCR_list.get(0).getValue();
		
	    // constant in sdr (func: return float value)\
	    map.put("fieldnm", "k2_nonnh3_SCR");
		List<CombusitionConsTantDTO> k2_nonnh3_SCR_list =  optMapper.getConstantByField(map);
		double k2_nonnh3_SCR = k2_nonnh3_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k3_no2nnh3_SCR");
		List<CombusitionConsTantDTO> k3_no2nnh3_SCR_list =  optMapper.getConstantByField(map);
		double k3_no2nnh3_SCR = k3_no2nnh3_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k4_no_SCR");
		List<CombusitionConsTantDTO> k4_no_SCR_list =  optMapper.getConstantByField(map);
		double k4_no_SCR = k4_no_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k5_no2_SCR");
		List<CombusitionConsTantDTO> k5_no2_SCR_list =  optMapper.getConstantByField(map);
		double k5_no2_SCR = k5_no2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k7_nonnh3nn2_SCR");
		List<CombusitionConsTantDTO> k7_nonnh3nn2_SCR_list =  optMapper.getConstantByField(map);
		double k7_nonnh3nn2_SCR = k7_nonnh3nn2_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "k6_no2nnh3nh2o_SCR");
		List<CombusitionConsTantDTO> k6_no2nnh3nh2o_SCR_list =  optMapper.getConstantByField(map);
		double k6_no2nnh3nh2o_SCR = k6_no2nnh3nh2o_SCR_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    map.put("fieldnm", "molm_no");
		List<CombusitionConsTantDTO> molm_no_list =  optMapper.getConstantByField(map);
		double molm_no = molm_no_list.get(0).getValue();
		
	    map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		
		map.put("fieldnm", "molm_h2o");
		List<CombusitionConsTantDTO> molm_h2o_list =  optMapper.getConstantByField(map);
		double molm_h2o = molm_h2o_list.get(0).getValue();
		
	    // formula
	    double vflow1_h2o_SCR =
	      ((((mflow_totalnh3_inSCR * molv_igas) / molm_no) * k7_nonnh3nn2_SCR) / k2_nonnh3_SCR) * k4_no_SCR;

	    double vflow2_h2o_SCR =
	      ((((mflow_totalnh3_inSCR * molv_igas) / molm_no) * k6_no2nnh3nh2o_SCR) / k3_no2nnh3_SCR) *
	      k5_no2_SCR;

	    double vflow3_h2o_SCR =
	      ((mflow_cctnh3_inSCR - mflow_totalnh3_inSCR) * molv_igas) / molm_h2o;

	    double mflow_wtr_inSCR = mflow_cctnh3_inSCR - mflow_totalnh3_inSCR;
	    pmap.put("mflow_wtr_inSCR", mflow_wtr_inSCR);
	    double vflow4_h2o_SCR = (mflow_wtr_inSCR * molv_igas) / molm_h2o;

	    double vflow_totalh2o_SCR =
	      vflow1_h2o_SCR +
	      vflow2_h2o_SCR +
	      vflow3_h2o_SCR +
	      vflow4_h2o_SCR;

	    double vflow_h2o_outSCR = vflow_h2o_inSCR + vflow_totalh2o_SCR;

	    
	    // store to db
	    pmap.put("vflow_totalh2o_SCR", vflow_totalh2o_SCR);
		map.put("fieldnm", "vflow_h2o_outSCR");
		map.put("value", vflow_h2o_outSCR);
		pmap.put("vflow_h2o_outSCR", vflow_h2o_outSCR);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_2_3_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		
		map.put("fieldnm", "vflow_co2_outBF");
		List<CombusitionPipeOutDTO> vflow_co2_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_co2_inSCR = vflow_co2_inSCR_list.get(0).getValue();
		
		
		map.put("fieldnm", "vflow_so2_outBF");
		List<CombusitionPipeOutDTO> vflow_so2_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_so2_inSCR = vflow_so2_inSCR_list.get(0).getValue();
		
		
		map.put("fieldnm", "vflow_hcl_outBF");
		List<CombusitionPipeOutDTO> vflow_hcl_outBF_list = optMapper.getPipeoutByField(map);
		double vflow_hcl_outBF = vflow_hcl_outBF_list.get(0).getValue();
		
		double vflow_hcl_inSCR = 0;
	    // formula
	   double vflow_co2_outSCR = vflow_co2_inSCR;
	   double vflow_so2_outSCR = vflow_so2_inSCR;
	   double vflow_hcl_outSCR = vflow_hcl_inSCR;

	    // store to db
		map.put("fieldnm", "vflow_co2_outSCR");
		map.put("value", vflow_co2_outSCR);
		pmap.put("vflow_co2_outSCR", vflow_co2_outSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_so2_outSCR");
		map.put("value", vflow_so2_outSCR);
		pmap.put("vflow_so2_outSCR", vflow_so2_outSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_hcl_outSCR");
		map.put("value", vflow_hcl_outSCR);
		pmap.put("vflow_hcl_outSCR", vflow_hcl_outSCR);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_3_1_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe add (func: return desval)
	    
		map.put("fieldnm", "comp_cfuel_SCR");
		List<CombusitionPipeAddDTO> comp_cfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_cfuel_SCR = comp_cfuel_SCR_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "comp_hfuel_SCR");
		List<CombusitionPipeAddDTO> comp_hfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_hfuel_SCR = comp_hfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_ofuel_SCR");
		List<CombusitionPipeAddDTO> comp_ofuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_ofuel_SCR = comp_ofuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_sfuel_SCR");
		List<CombusitionPipeAddDTO> comp_sfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_sfuel_SCR = comp_sfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_wfuel_SCR");
		List<CombusitionPipeAddDTO> comp_wfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_wfuel_SCR = comp_wfuel_SCR_list.get(0).getValue();
		
	    // formula
	    double hhv_fuel_SCR =
	      8100 * comp_cfuel_SCR + 34000 * (comp_hfuel_SCR - comp_ofuel_SCR / 8) + 2500 * comp_sfuel_SCR;

	    double lhv_fuel_SCR = hhv_fuel_SCR - 600 * (9 * comp_hfuel_SCR + comp_wfuel_SCR);
	    
	    pmap.put("hhv_fuel_SCR", hhv_fuel_SCR);
	    pmap.put("lhv_fuel_SCR", lhv_fuel_SCR);
	    
		return pmap;
	}

	@Override
	public HashMap mb_3_2_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		 // pipe add (func: return desval)
	    map.put("fieldnm", "comp_cfuel_SCR");
		List<CombusitionPipeAddDTO> comp_cfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_cfuel_SCR = comp_cfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_hfuel_SCR");
		List<CombusitionPipeAddDTO> comp_hfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_hfuel_SCR = comp_hfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_ofuel_SCR");
		List<CombusitionPipeAddDTO> comp_ofuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_ofuel_SCR = comp_ofuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_sfuel_SCR");
		List<CombusitionPipeAddDTO> comp_sfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_sfuel_SCR = comp_sfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_wfuel_SCR");
		List<CombusitionPipeAddDTO> comp_wfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_wfuel_SCR = comp_wfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "comp_nfuel_SCR");
		List<CombusitionPipeAddDTO> comp_nfuel_SCR_list = optMapper.getPipeaddByname(map);
		double comp_nfuel_SCR = comp_nfuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "rt_exairfuel_SCR");
		List<CombusitionPipeAddDTO> rt_exairfuel_SCR_list = optMapper.getPipeaddByname(map);
		double rt_exairfuel_SCR = rt_exairfuel_SCR_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		
	    map.put("fieldnm", "molm_c");
		List<CombusitionConsTantDTO> molm_c_list =  optMapper.getConstantByField(map);
		double molm_c = molm_c_list.get(0).getValue();
		
	    map.put("fieldnm", "molm_s");
		List<CombusitionConsTantDTO> molm_s_list =  optMapper.getConstantByField(map);
		double molm_s = molm_s_list.get(0).getValue();
		
	    map.put("fieldnm", "molm_h");
		List<CombusitionConsTantDTO> molm_h_list =  optMapper.getConstantByField(map);
		double molm_h = molm_h_list.get(0).getValue();
		
	    map.put("fieldnm", "molm_n2");
		List<CombusitionConsTantDTO> molm_n2_list =  optMapper.getConstantByField(map);
		double molm_n2 = molm_n2_list.get(0).getValue();
		
	    map.put("fieldnm", "coeff_h2no2");
		List<CombusitionConsTantDTO> coeff_h2no2_list =  optMapper.getConstantByField(map);
		double coeff_h2no2 = coeff_h2no2_list.get(0).getValue();
		
	    map.put("fieldnm", "rt_o2inair");
		List<CombusitionConsTantDTO> rt_o2inair_list =  optMapper.getConstantByField(map);
		double rt_o2inair = rt_o2inair_list.get(0).getValue();
		
	    map.put("fieldnm", "rt_n2inair");
		List<CombusitionConsTantDTO> rt_n2inair_list =  optMapper.getConstantByField(map);
		double rt_n2inair = rt_n2inair_list.get(0).getValue();
		
	    map.put("fieldnm", "vpm_w2s");
		List<CombusitionConsTantDTO> vpm_w2s_list =  optMapper.getConstantByField(map);
		double vpm_w2s = vpm_w2s_list.get(0).getValue();
		
	    // formula
	    double vpm_iairfuel_inSCR =
	      ((molv_igas / molm_c) * comp_cfuel_SCR +
	        (molv_igas / molm_h) * coeff_h2no2 * (comp_hfuel_SCR - comp_ofuel_SCR / 8) +
	        (molv_igas / molm_s) * comp_sfuel_SCR) /
	      rt_o2inair;

	    double vpm_aairfuel_inSCR = rt_exairfuel_SCR * vpm_iairfuel_inSCR;
	    double wt_co2fuel_SCR = (molv_igas / molm_c) * comp_cfuel_SCR;
	    double wt_o2fuel_SCR = rt_o2inair * (rt_exairfuel_SCR - 1.0) * vpm_iairfuel_inSCR;
	    double wt_n2fuel_SCR =
	      rt_n2inair * vpm_aairfuel_inSCR + (molv_igas / molm_n2) * comp_nfuel_SCR;
	    double wt_h2ofuel_SCR = (molv_igas / molm_h) * comp_hfuel_SCR + vpm_w2s * comp_wfuel_SCR;
	    double wt_so2fuel_SCR = (molv_igas / molm_s) * comp_sfuel_SCR;
	    double wt_totalgasfuel_SCR =
	      wt_co2fuel_SCR +
	      wt_o2fuel_SCR +
	      wt_n2fuel_SCR +
	      wt_h2ofuel_SCR +
	      wt_so2fuel_SCR;
	    
	    pmap.put("vpm_iairfuel_inSCR", vpm_iairfuel_inSCR);
	    pmap.put("vpm_aairfuel_inSCR", vpm_aairfuel_inSCR);
	    pmap.put("wt_co2fuel_SCR", wt_co2fuel_SCR);
	    pmap.put("wt_o2fuel_SCR", wt_o2fuel_SCR);
	    pmap.put("wt_n2fuel_SCR", wt_n2fuel_SCR);
	    pmap.put("wt_h2ofuel_SCR", wt_h2ofuel_SCR);
	    pmap.put("wt_so2fuel_SCR", wt_so2fuel_SCR);
	    pmap.put("wt_totalgasfuel_SCR", wt_totalgasfuel_SCR);

	    
	    
		return pmap;
	}

	@Override
	public HashMap hb_1_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "q_gas_outBF");
		List<CombusitionPipeOutDTO> q_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double q_gas_inSCR = q_gas_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_gas_outBF");
		List<CombusitionPipeOutDTO>vflow_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inSCR = vflow_gas_inSCR_list.get(0).getValue();
		
	    // pipe add (func: return desval)
		map.put("fieldnm", "cp_dgngas_outSCR");
		List<CombusitionPipeAddDTO> cp_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double cp_dgngas_outSCR = cp_dgngas_outSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "t_dgngas_outSCR");
		List<CombusitionPipeAddDTO> t_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outSCR = t_dgngas_outSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "sg_fuel_SCR");
		List<CombusitionPipeAddDTO> sg_fuel_SCR_list = optMapper.getPipeaddByname(map);
		double sg_fuel_SCR = sg_fuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_fuel_outSCR");
		List<CombusitionPipeAddDTO> cp_fuel_outSCR_list = optMapper.getPipeaddByname(map);
		double cp_fuel_outSCR = cp_fuel_outSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "t_wtr_inSCR");
		List<CombusitionPipeAddDTO> t_wtr_inSCR_list = optMapper.getPipeaddByname(map);
		double t_wtr_inSCR = t_wtr_inSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "t_air_inSCR");
		List<CombusitionPipeAddDTO> t_air_inSCR_list = optMapper.getPipeaddByname(map);
		double t_air_inSCR = t_air_inSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_air_inSCR");
		List<CombusitionPipeAddDTO> cp_air_inSCR_list = optMapper.getPipeaddByname(map);
		double cp_air_inSCR = cp_air_inSCR_list.get(0).getValue();
		
	    // constant in sdr (func: return float value)
		map.put("fieldnm", "k1_hloss_SCR");
		List<CombusitionConsTantDTO> k1_hloss_SCR_list =  optMapper.getConstantByField(map);
		double k1_hloss_SCR = k1_hloss_SCR_list.get(0).getValue();
		
		double lhv_fuel_SCR = (double)pmap.get("lhv_fuel_SCR");
		double vflow_totalh2o_SCR = (double)pmap.get("vflow_totalh2o_SCR");
		double vflow_totaln2_SCR = (double)pmap.get("vflow_totaln2_SCR");
		double vflow_totalo2_SCR = (double)pmap.get("vflow_totalo2_SCR");
		double wt_totalgasfuel_SCR = (double)pmap.get("wt_totalgasfuel_SCR");
		double mflow_wtr_inSCR = (double)pmap.get("mflow_wtr_inSCR");
		double vflow_air_inSCR = (double)pmap.get("vflow_air_inSCR");
		
		pmap.put("lhv_fuel_SCR", lhv_fuel_SCR);
		pmap.put("vflow_totalh2o_SCR", vflow_totalh2o_SCR);
		pmap.put("vflow_totaln2_SCR", vflow_totaln2_SCR);
		pmap.put("vflow_totaln2_SCR", vflow_totaln2_SCR);
		pmap.put("vflow_totalo2_SCR", vflow_totalo2_SCR);
		pmap.put("wt_totalgasfuel_SCR", wt_totalgasfuel_SCR);
		pmap.put("mflow_wtr_inSCR", mflow_wtr_inSCR);
		pmap.put("vflow_air_inSCR", vflow_air_inSCR);
		
	    // formula
	    double t1 = q_gas_inSCR * k1_hloss_SCR;
	    double t2 = lhv_fuel_SCR * k1_hloss_SCR;
	    double t3 =
	      (vflow_gas_inSCR +
	        vflow_totalh2o_SCR +
	        vflow_totaln2_SCR +
	        vflow_totalo2_SCR) *
	      cp_dgngas_outSCR *
	      t_dgngas_outSCR;
	    double t4 = (wt_totalgasfuel_SCR / sg_fuel_SCR) * cp_fuel_outSCR * t_dgngas_outSCR;

	    double qi_wtr_SCR = mflow_wtr_inSCR * t_wtr_inSCR;
	    pmap.put("qi_wtr_SCR", qi_wtr_SCR);
	    double qi_air_SCR = vflow_air_inSCR * t_air_inSCR * cp_air_inSCR;
	    pmap.put("qi_air_SCR", qi_air_SCR);
	    
	    double mflow_fuel_inSCR =
	      (t1 + t3 - (q_gas_inSCR + qi_wtr_SCR + qi_air_SCR)) /
	      (lhv_fuel_SCR - (t2 + t4));

	    // store to db
	    map.put("fieldnm", "mflow_fuel_inSCR");
		map.put("value", mflow_fuel_inSCR);
		pmap.put("mflow_fuel_inSCR", mflow_fuel_inSCR);
		optMapper.updatePipeoutValue(map);
		return pmap;
	}

	@Override
	public HashMap mb_4_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)

		map.put("fieldnm", "vflow_gas_outBF");
		List<CombusitionPipeOutDTO>vflow_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inSCR = vflow_gas_inSCR_list.get(0).getValue();
		
	    // pipe add (func: return value)
		map.put("fieldnm", "t_dgngas_outSCR");
		List<CombusitionPipeAddDTO> t_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outSCR = t_dgngas_outSCR_list.get(0).getValue();
		
		map.put("fieldnm", "sg_fuel_SCR");
		List<CombusitionPipeAddDTO> sg_fuel_SCR_list = optMapper.getPipeaddByname(map);
		double sg_fuel_SCR = sg_fuel_SCR_list.get(0).getValue();
		
	    // constant in global (func: return value)
		map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    // formula
		double vflow_totalh2o_SCR = (double)pmap.get("vflow_totalh2o_SCR");
	    double vflow_totaln2_SCR = (double)pmap.get("vflow_totaln2_SCR");
		
	    double vflow_totalo2_SCR = (double)pmap.get("vflow_totalo2_SCR");
	    double wt_totalgasfuel_SCR = (double)pmap.get("wt_totalgasfuel_SCR");
	    double mflow_fuel_inSCR = (double)pmap.get("mflow_fuel_inSCR");
	    pmap.put("vflow_totalh2o_SCR", vflow_totalh2o_SCR);
	    pmap.put("vflow_totaln2_SCR", vflow_totaln2_SCR);
	    pmap.put("vflow_totalo2_SCR", vflow_totalo2_SCR);
	    pmap.put("wt_totalgasfuel_SCR", wt_totalgasfuel_SCR);
	    pmap.put("mflow_fuel_inSCR", mflow_fuel_inSCR);
		    
	    double vflow_gas_outSCR =
	      vflow_gas_inSCR +
	      (vflow_totalh2o_SCR + vflow_totaln2_SCR + vflow_totalo2_SCR) +
	      (wt_totalgasfuel_SCR * mflow_fuel_inSCR) / sg_fuel_SCR;

	   
	    
	    double vflowa_gas_outSCR = (vflow_gas_outSCR * (ktemp + t_dgngas_outSCR)) / ktemp;

	    // store to db
		map.put("fieldnm", "vflow_gas_outSCR");
		map.put("value", vflow_gas_outSCR);
		pmap.put("vflow_gas_outSCR", vflow_gas_outSCR);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "vflowa_gas_outSCR");
		map.put("value", vflowa_gas_outSCR);
		pmap.put("vflowa_gas_outSCR", vflowa_gas_outSCR);
		optMapper.updatePipeoutValue(map);
		
	    
		return pmap;
	}

	@Override
	public HashMap hb_2_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    // const q_gas_inSCR = helper.plm.PIPEIN_NM_DB(data.wpid, 'q_gas_inSCR');
	    // const vflow_gas_inSCR = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_gas_inSCR');
	    
		map.put("fieldnm", "q_gas_outBF");
		List<CombusitionPipeOutDTO>q_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double q_gas_inSCR = q_gas_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_gas_outBF");
		List<CombusitionPipeOutDTO>vflow_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inSCR = vflow_gas_inSCR_list.get(0).getValue();
		
	    // constant in sdr (func: return float value)
		map.put("fieldnm", "k1_hloss_SCR");
		List<CombusitionConsTantDTO> k1_hloss_SCR_list =  optMapper.getConstantByField(map);
		double k1_hloss_SCR = k1_hloss_SCR_list.get(0).getValue();
		
	    // pipe add (func: return value)
		map.put("fieldnm", "t_dgngas_outSCR");
		List<CombusitionPipeAddDTO> t_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outSCR = t_dgngas_outSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_dgngas_outSCR");
		List<CombusitionPipeAddDTO> cp_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double cp_dgngas_outSCR = cp_dgngas_outSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "sg_fuel_SCR");
		List<CombusitionPipeAddDTO> sg_fuel_SCR_list = optMapper.getPipeaddByname(map);
		double sg_fuel_SCR = sg_fuel_SCR_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_fuel_outSCR");
		List<CombusitionPipeAddDTO> cp_fuel_outSCR_list = optMapper.getPipeaddByname(map);
		double cp_fuel_outSCR = cp_fuel_outSCR_list.get(0).getValue();
		
		double lhv_fuel_SCR = (double)pmap.get("lhv_fuel_SCR");
		double mflow_fuel_inSCR = (double)pmap.get("mflow_fuel_inSCR");
		double qi_wtr_SCR = (double)pmap.get("qi_wtr_SCR");
		double qi_air_SCR = (double)pmap.get("qi_air_SCR");
		double vflow_totalh2o_SCR = (double)pmap.get("vflow_totalh2o_SCR");
		double vflow_totaln2_SCR = (double)pmap.get("vflow_totaln2_SCR");
		double vflow_totalo2_SCR = (double)pmap.get("vflow_totalo2_SCR");
		double wt_totalgasfuel_SCR = (double)pmap.get("wt_totalgasfuel_SCR");
		
	    // formula
	    double qi_fuel_SCR = lhv_fuel_SCR * mflow_fuel_inSCR;
	    double qi_total_SCR =
	      q_gas_inSCR + qi_fuel_SCR + qi_wtr_SCR + qi_air_SCR;
	    double qo_hloss_SCR = qi_total_SCR * k1_hloss_SCR;
	    double q_gas_outSCR =
	      ((vflow_gas_inSCR +
	        vflow_totalh2o_SCR +
	        vflow_totaln2_SCR +
	        vflow_totalo2_SCR) *
	        cp_dgngas_outSCR +
	        (wt_totalgasfuel_SCR / sg_fuel_SCR) * mflow_fuel_inSCR * cp_fuel_outSCR) *
	      t_dgngas_outSCR;
	    double qo_total_SCR = qo_hloss_SCR + q_gas_outSCR;

	    // store to db
		map.put("fieldnm", "qi_fuel_SCR");
		map.put("value", qi_fuel_SCR);
		pmap.put("qi_fuel_SCR", qi_fuel_SCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qi_total_SCR");
		map.put("value", qi_total_SCR);
		pmap.put("qi_total_SCR", qi_total_SCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_hloss_SCR");
		map.put("value", qo_hloss_SCR);
		pmap.put("qo_hloss_SCR", qo_hloss_SCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "q_gas_outSCR");
		map.put("value", q_gas_outSCR);
		pmap.put("q_gas_outSCR", q_gas_outSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_total_SCR");
		map.put("value", qo_total_SCR);
		pmap.put("qo_total_SCR", qo_total_SCR);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_5_1_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "vppm_no2_outBF");
		List<CombusitionPipeOutDTO>vppm_no2_inSCR_list = optMapper.getPipeoutByField(map);
		double vppm_no2_inSCR = vppm_no2_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_gas_outBF");
		List<CombusitionPipeOutDTO>vflow_gas_inSCR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inSCR = vflow_gas_inSCR_list.get(0).getValue();
		pmap.put("vflow_gas_inSCR", vflow_gas_inSCR);
	    // constant in sdr (func: return float value)
		map.put("fieldnm", "k11_elno2_SCR");
		List<CombusitionConsTantDTO> k11_elno2_SCR_list =  optMapper.getConstantByField(map);
		double k11_elno2_SCR = k11_elno2_SCR_list.get(0).getValue();
	    // formula
	    double vflow_gas_outSCR = (double)pmap.get("vflow_gas_outSCR");
		double vppm_no2_outSCR =
	      (vppm_no2_inSCR * (1.0 - k11_elno2_SCR) * vflow_gas_inSCR) / vflow_gas_outSCR;

	    // store to db
	    
		map.put("fieldnm", "vppm_no2_outSCR");
		map.put("value", vppm_no2_outSCR);
		pmap.put("vppm_no2_outSCR", vppm_no2_outSCR);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_5_2_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "mpv_dioxin_outBF");
		List<CombusitionPipeOutDTO> mpv_dioxin_outBF_list = optMapper.getPipeoutByField(map);
		double mpv_dioxin_inSCR = mpv_dioxin_outBF_list.get(0).getValue();
		
	    // constant in sdr (func: return float value)
		map.put("fieldnm", "k12_eldioxin_SCR");
		List<CombusitionConsTantDTO> k12_eldioxin_SCR_list =  optMapper.getConstantByField(map);
		double k12_eldioxin_SCR = k12_eldioxin_SCR_list.get(0).getValue();
		
	    // formula
	    double mpv_dioxin_outSCR = mpv_dioxin_inSCR * (1.0 - k12_eldioxin_SCR);

	    // store to db
		map.put("fieldnm", "mpv_dioxin_outSCR");
		map.put("value", mpv_dioxin_outSCR);
		pmap.put("mpv_dioxin_outSCR", mpv_dioxin_outSCR);
		optMapper.updatePipeoutValue(map);
		return pmap;
	}

	@Override
	public HashMap mb_5_3_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "vppm_co_outBF");
		List<CombusitionPipeOutDTO>vppm_co_inSCR_list = optMapper.getPipeoutByField(map);
		double vppm_co_inSCR = vppm_co_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_so2_outBF");
		List<CombusitionPipeOutDTO>vppm_so2_inSCR_list = optMapper.getPipeoutByField(map);
		double vppm_so2_inSCR = vppm_so2_inSCR_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_hcl_outBF");
		List<CombusitionPipeOutDTO>vppm_hcl_outBF_list = optMapper.getPipeoutByField(map);
		double vppm_hcl_inSCR = vppm_hcl_outBF_list.get(0).getValue();
		
		map.put("fieldnm", "mpv_dust_outBF");
		List<CombusitionPipeOutDTO>mpv_dust_inSCR_list = optMapper.getPipeoutByField(map);
		double mpv_dust_inSCR = mpv_dust_inSCR_list.get(0).getValue();
		
	    // store to db
		map.put("fieldnm", "vppm_co_outSCR");
		map.put("value", vppm_co_inSCR);
		pmap.put("vppm_co_inSCR", vppm_co_inSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_so2_outSCR");
		map.put("value", vppm_so2_inSCR);
		pmap.put("vppm_so2_inSCR", vppm_so2_inSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_hcl_outSCR");
		map.put("value", vppm_hcl_inSCR);
		pmap.put("vppm_hcl_inSCR", vppm_hcl_inSCR);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mpv_dust_outSCR");
		map.put("value", mpv_dust_inSCR);
		pmap.put("mpv_dust_inSCR", mpv_dust_inSCR);
		optMapper.updatePipeoutValue(map);
		
	    
		return pmap;
	}

	@Override
	public HashMap etc_scr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		 // pipe add (func: return desval)
	    map.put("fieldnm", "t_dgngas_outSCR");
		List<CombusitionPipeAddDTO> t_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outSCR = t_dgngas_outSCR_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_dgngas_outSCR");
		List<CombusitionPipeAddDTO> cp_dgngas_outSCR_list = optMapper.getPipeaddByname(map);
		double cp_dgngas_outSCR = cp_dgngas_outSCR_list.get(0).getValue();
		
		
	    // store to db
		map.put("fieldnm", "t_gas_outSCR");
		map.put("value", t_dgngas_outSCR);
		pmap.put("t_dgngas_outSCR", t_dgngas_outSCR);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "cp_gas_outSCR");
		map.put("value", cp_dgngas_outSCR);
		pmap.put("cp_dgngas_outSCR", cp_dgngas_outSCR);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap scr_design(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    // const t_gas_inSCR = helper.plm.PIPEIN_NM_DB(data.wpid, 't_gas_inSCR');
	    // const vflow_gas_inSCR = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_gas_inSCR');
	    
		map.put("fieldnm", "t_gas_outBF");
		List<CombusitionPipeOutDTO>t_gas_outBF_list = optMapper.getPipeoutByField(map);
		double t_gas_inSCR = t_gas_outBF_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_gas_outBF");
		List<CombusitionPipeOutDTO>vflow_gas_outBF_list = optMapper.getPipeoutByField(map);
		double vflow_gas_outBF = vflow_gas_outBF_list.get(0).getValue();
		
	    // constant in global (func: return value)
		map.put("fieldnm", "min2sec");
		List<CombusitionConsTantDTO> min2sec_list =  optMapper.getConstantByField(map);
		double min2sec = min2sec_list.get(0).getValue();
		
	    map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    map.put("fieldnm", "min2hr");
		List<CombusitionConsTantDTO> min2hr_list =  optMapper.getConstantByField(map);
		double min2hr = min2hr_list.get(0).getValue();
		
	    // pipe add (func: return desval)
		map.put("fieldnm", "mps_gasvel_SCR");
		List<CombusitionPipeAddDTO> mps_gasvel_SCR_list = optMapper.getPipeaddByname(map);
		double mps_gasvel_SCR = mps_gasvel_SCR_list.get(0).getValue();
		
		map.put("fieldnm", "sec_mrt_SCR");
		List<CombusitionPipeAddDTO> sec_mrt_SCR_list = optMapper.getPipeaddByname(map);
		double sec_mrt_SCR = sec_mrt_SCR_list.get(0).getValue();
		
		double vflow_gas_inSCR = (double)pmap.get("vflow_gas_inSCR");
	    // formula
	    // CMM_volume_SCR = (vflow_gas_inSCR * (ktemp + t_gas_inSCR)) / ktemp / min2hr;
	    // m2_area_SCR= CMM_volume_SCR / mps_gasvel_SCR
	    // m_dim_SCR= (4 * m2_area_SCR / 3.14 ) ^ (0.5)
	    // m_height_SCR= mps_gasvel_SCR * sec_mrt_SCR / 3.14 * (m_dim_SCR / 2)^2
	    double CMM_volume_SCR = (vflow_gas_inSCR * (ktemp + t_gas_inSCR)) / ktemp / min2hr;
	    double m2_area_SCR = (CMM_volume_SCR * mps_gasvel_SCR) / min2sec;
	    double m_dim_SCR = Math.pow((4 * m2_area_SCR) / 3.14, 0.5) ;
	    double m_height_SCR = Math.pow((((CMM_volume_SCR / min2sec) * sec_mrt_SCR) / 3.14) * (m_dim_SCR / 2), 2);

	    // store to db
		map.put("fieldnm", "m2_area_SCR");
		map.put("value", m2_area_SCR);
		pmap.put("m2_area_SCR", m2_area_SCR);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "m_dim_SCR");
		map.put("value", m_dim_SCR);
		pmap.put("m_dim_SCR", m_dim_SCR);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "m_height_SCR");
		map.put("value", m_height_SCR);
		pmap.put("m_height_SCR", m_height_SCR);
		optMapper.updatePipeoutValue(map);
		return pmap;
	}


}
