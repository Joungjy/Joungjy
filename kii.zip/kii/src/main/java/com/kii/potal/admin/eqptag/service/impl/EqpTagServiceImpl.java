package com.kii.potal.admin.eqptag.service.impl;

import com.kii.potal.admin.eqptag.dto.EqpTagDTO;
import com.kii.potal.admin.eqptag.service.EqpTagService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EqpTagServiceImpl extends EgovAbstractServiceImpl implements EqpTagService {

    @Autowired
    EqpTagMapper eqpTagMapper;
    @Override
    public List<EqpTagDTO> getEqpTagList(EqpTagDTO eqpTagDTO) throws Exception {
        return null;
    }

    @Override
    public void insertEqpTagItem(EqpTagDTO eqpTagDTO) throws Exception {

    }

    @Override
    public void updateEqpTagItem(EqpTagDTO eqpTagDTO) throws Exception {

    }

    @Override
    public void deleteEqpTagItem(EqpTagDTO eqpTagDTO) throws Exception {

    }
}
