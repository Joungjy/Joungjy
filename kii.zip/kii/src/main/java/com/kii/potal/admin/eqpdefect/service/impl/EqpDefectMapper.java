package com.kii.potal.admin.eqpdefect.service.impl;

import com.kii.potal.admin.eqpdefect.dto.EqpDefectDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface EqpDefectMapper {

    //고장 이력 관리 리스트 조회
    List<EqpDefectDTO> getEqpDefectList(EqpDefectDTO eqpDefectDTO) throws Exception;

    //고장이력관리 상세 정보 조회
    EqpDefectDTO getEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception;

    //고장 이력 관리 정보 등록
    void insertEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception;

    //고장 이력 관리 정보 수정
    void updateEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception;

    //고장 이력 관리 정보 삭제
    void deleteEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception;
}
