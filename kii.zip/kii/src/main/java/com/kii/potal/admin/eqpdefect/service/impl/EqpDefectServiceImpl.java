package com.kii.potal.admin.eqpdefect.service.impl;

import com.kii.potal.admin.eqpdefect.dto.EqpDefectDTO;
import com.kii.potal.admin.eqpdefect.service.EqpDefectService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EqpDefectServiceImpl extends EgovAbstractServiceImpl implements EqpDefectService {

    @Autowired
    EqpDefectMapper eqpDefectMapper;
    @Override
    public List<EqpDefectDTO> getEqpDefectList(EqpDefectDTO eqpDefectDTO) throws Exception {
        return null;
    }

    @Override
    public EqpDefectDTO getEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception {
        return null;
    }

    @Override
    public void insertEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception {

    }

    @Override
    public void updateEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception {

    }

    @Override
    public void deleteEqpDefectItem(EqpDefectDTO eqpDefectDTO) throws Exception {

    }
}
