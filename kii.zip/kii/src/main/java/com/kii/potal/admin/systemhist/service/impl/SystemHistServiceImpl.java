package com.kii.potal.admin.systemhist.service.impl;

import com.kii.potal.admin.systemhist.dto.SystemHistDTO;
import com.kii.potal.admin.systemhist.service.SystemHistService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SystemHistServiceImpl extends EgovAbstractServiceImpl implements SystemHistService {

    @Autowired
    SystemHistMapper systemHistMapper;
    @Override
    public List<SystemHistDTO> getSysHistList(SystemHistDTO systemHistDTO)throws Exception {
        return systemHistMapper.getSysHistList(systemHistDTO);
    }

    @Override
    public void insertSysHistItem(SystemHistDTO systemHistDTO)throws Exception {
        systemHistMapper.insertSysHistItem(systemHistDTO);
    }
}
