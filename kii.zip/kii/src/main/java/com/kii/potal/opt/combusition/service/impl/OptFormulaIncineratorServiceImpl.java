package com.kii.potal.opt.combusition.service.impl;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaIncineratorService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaIncineratorServiceImpl extends EgovAbstractServiceImpl implements OptFormulaIncineratorService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap hb_10_inci(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "wp_h2o_waste");
		List<CombusitionElementInDTO> wp_h2o_waste_list = optMapper.getElementinByname(map);
		double wp_h2o_waste = wp_h2o_waste_list.get(0).getValue();
		
		map.put("fieldnm", "wp_c_drywaste");
		List<CombusitionPipeOutDTO> wp_c_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_c_drywaste = wp_c_drywaste_list.get(0).getValue();
		
		
	    map.put("fieldnm", "wp_h_drywaste");
		List<CombusitionPipeOutDTO> wp_h_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_h_drywaste = wp_h_drywaste_list.get(0).getValue();
		
	    map.put("fieldnm", "wp_o_drywaste");
		List<CombusitionPipeOutDTO>wp_o_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_o_drywaste = wp_o_drywaste_list.get(0).getValue();
		
	    map.put("fieldnm", "wp_n_drywaste");
		List<CombusitionPipeOutDTO> wp_n_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_n_drywaste = wp_n_drywaste_list.get(0).getValue();
		
	    map.put("fieldnm", "wp_s_drywaste");
		List<CombusitionPipeOutDTO> wp_s_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_s_drywaste = wp_s_drywaste_list.get(0).getValue();
		
	    map.put("fieldnm", "wp_cl_drywaste");
		List<CombusitionPipeOutDTO> wp_cl_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_cl_drywaste = wp_cl_drywaste_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "wp_ash_drywaste");
		List<CombusitionPipeOutDTO> wp_ash_drywaste_list = optMapper.getPipeoutByField(map);
		double wp_ash_drywaste = wp_ash_drywaste_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "lhv_waste");
		List<CombusitionPipeOutDTO> lhv_waste_list = optMapper.getPipeoutByField(map);
		double lhv_waste = lhv_waste_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "vuflow_air_combst12");
		List<CombusitionPipeOutDTO> vuflow_air_combst12_list = optMapper.getPipeoutByField(map);
		double vuflow_air_combst12 = vuflow_air_combst12_list.get(0).getValue();
		
	    // pipe add (func: return value)
	    map.put("fieldnm", "t1_waste");
		List<CombusitionPipeOutDTO> t1_waste_list = optMapper.getPipeoutByField(map);
		double t1_waste = t1_waste_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "t1_air_combst1");
		List<CombusitionPipeOutDTO> t1_air_combst1_list = optMapper.getPipeoutByField(map);
		double t1_air_combst1 = t1_air_combst1_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "vfp_air_combst1");
		List<CombusitionPipeOutDTO> vfp_air_combst1_list = optMapper.getPipeoutByField(map);
		double vfp_air_combst1 = vfp_air_combst1_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    map.put("fieldnm", "ktemp");
		List<CombusitionPipeOutDTO> ktemp_list = optMapper.getPipeoutByField(map);
		double ktemp =ktemp_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "cpt1_h2o_waste");
		List<CombusitionPipeOutDTO> cpt1_h2o_waste_list = optMapper.getPipeoutByField(map);
		double cpt1_h2o_waste = cpt1_h2o_waste_list.get(0).getValue();
		pmap.put("cpt1_h2o_waste", cpt1_h2o_waste);
	    
	    map.put("fieldnm", "wp_ash_waste");
		List<CombusitionElementInDTO> wp_ash_waste_list =  optMapper.getElementinByname(map);
		double wp_ash_waste = wp_ash_waste_list.get(0).getValue();
	    
	    map.put("fieldnm", "mflow_waste");
		List<CombusitionElementInDTO> mflow_waste_list =  optMapper.getElementinByname(map);
		double mflow_waste = mflow_waste_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "k5_flyash_combst1");
		List<CombusitionElementInDTO> k5_flyash_combst1_list =  optMapper.getElementinByname(map);
		double k5_flyash_combst1 = k5_flyash_combst1_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "k6_flyubc_combst1");
		List<CombusitionElementInDTO> k6_flyubc_combst1_list =  optMapper.getElementinByname(map);
		double k6_flyubc_combst1 = k6_flyubc_combst1_list.get(0).getValue();
		
	    map.put("fieldnm", "k7_lossign_combst1");
		List<CombusitionElementInDTO> k7_lossign_combst1_list =  optMapper.getElementinByname(map);
		double k7_lossign_combst1 = k7_lossign_combst1_list.get(0).getValue();
		
	    // *)불연물질에의한분진(flyash)/볼완전연소에의한분진(flyubc)/분진(dust) 발생량
	    // mflow_dust1_outcombst1 = wp_ash_waste * mflow_waste * k5_flyash_combst1
	    // mflow_dust2_outcombst1 = wp_c_waste * mflow_waste * k7_lossign_combst1 * k6_flyubc_combst1
	    // mflow_dust_outcombst1 = mflow_dust1_outcombst1 + mflow_dust2_outcombst2
	    // mpv_dust_outcombst1 = ( mflow_dust1_outcombst1 + mflow_dust2_outcombst1 ) * unit_mega / vflow_gas_outcombst1
	    //
	    // change ash's eqn by Jaeil eng. excel sheet
	    // incinerator out : fly ash (Tspw1) --> fly ash from waste
	    // incinerator out : bottom ash (Sw1) --> ash in waste
	    // incinerator out : bottom ash-loss of ignition (Sw2) --> unburned waste
	    // incinerator out : fly ash-loss of ignition (Tspw2) --> flyash from unburned waste
	    double mflow_tspw1_outcombst1 = (wp_ash_waste / 100) * mflow_waste * (k5_flyash_combst1 / 100);
	    double mflow_sw1_outcombst1 = (wp_ash_waste / 100) * mflow_waste;
	    // 남부땅끄랑 수ㄱ
	    // data.hb_10_inci.mflow_sw2_outcombst1 =
	    //  (data.hb_10_inci.mflow_sw1_outcombst1 - data.hb_10_inci.mflow_tspw1_outcombst1) *
	    //  (k7_lossign_combst1 / 100 / (1 - k7_lossign_combst1 / 100));
	    // 금산용 한종 수식
	    double mflow_sw2_outcombst1 =
	      mflow_sw1_outcombst1 / (1 - k7_lossign_combst1 / 100) - mflow_sw1_outcombst1;
	    
	    pmap.put("mflow_sw1_outcombst1", mflow_sw1_outcombst1);
	    pmap.put("mflow_sw2_outcombst1", mflow_sw2_outcombst1);
	    
	    double mflow_sw_outcombst1 = mflow_sw1_outcombst1 + mflow_sw2_outcombst1;
	    pmap.put("mflow_sw_outcombst1", mflow_sw_outcombst1);
	    double mflow_tspw2_outcombst1 = mflow_sw2_outcombst1 * (k6_flyubc_combst1 / 100);
	    // Define input & output variables for mass balance in incinerator
	    double mflow_flyash_waste_outcombst1 = mflow_tspw1_outcombst1;
	    double mflow_flyash_ubw_outcombst1 = mflow_tspw2_outcombst1;
	    double mflow_flyash_outcombst1 =
	      mflow_flyash_waste_outcombst1 + mflow_flyash_ubw_outcombst1;
	    double mflow_bottomash_waste_outcombst1 =
	      mflow_sw_outcombst1 - mflow_flyash_outcombst1;
	    double mflow_bottomash_ubw_outcombst1 =
	      mflow_sw2_outcombst1 - mflow_flyash_ubw_outcombst1;

	    // formula
	    // *) qin1_combst1 : 폐기물 보유열량 (현열)
	    // *) qin2_combst1 : 폐기물 연소 발열량
	    // *) qin3_combst1 : 1차 연소공기 보유 열량(현열)
	    // *) cpt1_waste : ambient(t1) 상태에서 폐기물(가연분+ash)의 cp 값
	    // *) cpt1_air_combst1 = 연소실에 공급되는 공기의 비열 (ambient 온도에서)

	    double cpt1_waste = returnCpWaste(
	      t1_waste,
	      ktemp,
	      wp_c_drywaste,
	      wp_h_drywaste,
	      wp_o_drywaste,
	      wp_n_drywaste,
	      wp_s_drywaste,
	      wp_cl_drywaste,
	      wp_ash_drywaste
	    );
	    pmap.put("ktemp", ktemp);
	    pmap.put("wp_c_drywaste", wp_c_drywaste);
	    pmap.put("wp_h_drywaste", wp_h_drywaste);
	    pmap.put("wp_o_drywaste", wp_o_drywaste);
	    pmap.put("wp_n_drywaste", wp_n_drywaste);
	    pmap.put("wp_s_drywaste", wp_s_drywaste);
	    pmap.put("wp_cl_drywaste", wp_cl_drywaste);
	    pmap.put("wp_ash_drywaste", wp_ash_drywaste);
	    
	    double cpt1_air_combst1 = returnCP_AIR( t1_air_combst1);
	    //
	    double qin1_combst1 =
	      (cpt1_h2o_waste * (wp_h2o_waste / 100) +
	        cpt1_waste * (1 - wp_h2o_waste / 100)) *
	      t1_waste;
	    double qin2_combst1 = lhv_waste;
	    double qin3_combst1 =
	      (vfp_air_combst1 / 100) *
	      vuflow_air_combst12 *
	      cpt1_air_combst1 *
	      t1_air_combst1;

	    // only K-BEST plant
	    // data.hb_10_inci.qin1_combst1 = 0; // K-BEST
	    // data.hb_10_inci.qin3_combst1 = 0; // K-BEST
	    //
	    //
	    double qin_combst1 =
	      qin1_combst1 + qin2_combst1 + qin3_combst1;

	    // store to db
	    map.put("qin1_combst1", "qin1_combst1");
		map.put("value", qin1_combst1);
		pmap.put("qin1_combst1", qin1_combst1);
		optMapper.updatePipeoutValue(map);
		
		
	
	    map.put("qin2_combst1", "qin2_combst1");
		map.put("value", qin2_combst1);
		pmap.put("qin2_combst1", qin2_combst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("qin3_combst1", "qin3_combst1");
		map.put("value", qin3_combst1);
		pmap.put("qin3_combst1", qin3_combst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("qin_combst1", "qin_combst1");
		map.put("value", qin_combst1);
		pmap.put("qin_combst1", qin_combst1);
		optMapper.updatePipeoutValue(map);
		

	    map.put("mflow_flyash_outcombst1", "mflow_flyash_outcombst1");
		map.put("value", mflow_flyash_outcombst1);
		pmap.put("qin1_combst1", mflow_flyash_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("mflow_flyash_waste_outcombst1", "mflow_flyash_waste_outcombst1");
		map.put("value", mflow_flyash_waste_outcombst1);
		pmap.put("mflow_flyash_waste_outcombst1", mflow_flyash_waste_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("mflow_flyash_ubw_outcombst1", "mflow_flyash_ubw_outcombst1");
		map.put("value", mflow_flyash_ubw_outcombst1);
		pmap.put("qin1_combst1", mflow_flyash_ubw_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("mflow_bottomash_waste_outcombst1", "mflow_bottomash_waste_outcombst1");
		map.put("value", mflow_bottomash_waste_outcombst1);
		pmap.put("mflow_bottomash_waste_outcombst1", mflow_bottomash_waste_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("mflow_bottomash_ubw_outcombst1", "mflow_bottomash_ubw_outcombst1");
		map.put("value", mflow_bottomash_ubw_outcombst1);
		pmap.put("mflow_bottomash_ubw_outcombst1", mflow_bottomash_ubw_outcombst1);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}
	private double returnCP_AIR(double t_air) throws Exception {

		double n1 = Math.round(t_air * 0.01);
		double t1 = n1 * 100;
		double cp_air = 0;
		HashMap map = new HashMap();
		
		if (t1 == t_air) {
			map.put("temp", t_air);
			List<CombusitionCpDTO> cpdtolist = optMapper.getCpBytemp(map);
		    cp_air = cpdtolist.get(0).getAirlo();
		} else {
		    if (t_air < 100) {
		      cp_air = 0.31;
		    } else {
		      // const n2 = n1 + 1;
		      double t2 = t1 + 100;
		      // const c1 = gas_cptbl(n1, 11);
		      map.put("temp", t1);
			  List<CombusitionCpDTO> cpdtolist = optMapper.getCpBytemp(map);
		      double c1 = cpdtolist.get(0).getAirlo();
		      // const c2 = gas_cptbl(n2, 11);
		      map.put("temp", t2);
			  cpdtolist = optMapper.getCpBytemp(map);
		      double c2 = cpdtolist.get(0).getAirlo();
		      cp_air = ((t_air - t1) * (c1 - c2)) / (t1 - t2) + c1;

		    }
		}
		return cp_air;
	}
	private double returnCpWaste(
			double t_waste,
		      double ktemp,
		      double wp_c_drywaste,
		      double wp_h_drywaste,
		      double wp_o_drywaste,
		      double wp_n_drywaste,
		      double wp_s_drywaste,
		      double wp_cl_drywaste,
		      double wp_ash_drywaste
			) {
		double wcp_c =
			    ((Math.pow(Math.pow(Math.pow(11.18 + 1.095 * 10, -2) * (ktemp + t_waste) + -4.891 * 10, 5) * (ktemp + t_waste), -2) ) * 0.239) / 12;

		double wcp_h = (Math.pow(Math.pow(Math.pow(Math.pow(Math.pow(28.84 + 7.65 * 10,-5)* t_waste + 3.288 * 10, -6)  * t_waste, 2 ) + -8.698 * 10, -10)  * t_waste, 3) * 0.239)/2 ;
			    
			
		double wcp_o = (Math.pow(Math.pow(Math.pow(Math.pow(Math.pow(29.1 + 1.158 * 10, -2)* t_waste + -6.076 * 10, -6)* t_waste, 2) + 1.311 * 10, -9)* t_waste, 3) * 0.239 ) / 32 ;

		double wcp_n = (Math.pow(Math.pow(Math.pow(Math.pow(Math.pow(29 + 2.199 * 10, -3)* t_waste + 5.723 * 10, -6) * t_waste, 2) + -2.871 * 10 , -9) * t_waste, 3) * 0.239) / 28  ;
			  
		double wcp_s = ((Math.pow(15.2 + 2.68 * 10, -2)* (ktemp + t_waste)) * 0.239 )/32 ;
		
		double wcp_cl =  (Math.pow(Math.pow(Math.pow(Math.pow(Math.pow(33.6 + 1.367 * 10, -2)* t_waste + -1.607 * 10, -5) * t_waste, 2) + 6.473 * 10, -9)  * t_waste, 3) * 0.239) / 71 ;

		double wcp_ash = 0.2;

		double cp_waste =
			    wcp_c * (wp_c_drywaste / 100) +
			    wcp_h * (wp_h_drywaste / 100) +
			    wcp_o * (wp_o_drywaste / 100) +
			    wcp_n * (wp_n_drywaste / 100) +
			    wcp_s * (wp_s_drywaste / 100) +
			    wcp_cl * (wp_cl_drywaste / 100) +
			    wcp_ash * (wp_ash_drywaste / 100);

	   return cp_waste;
	}
	
	@Override
	public HashMap hb_20_inci(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		// pipe in (func: return value)
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
	    map.put("fieldnm", "vuflow_gas_combst1");
		List<CombusitionPipeOutDTO>vuflow_gas_combst1_list = optMapper.getPipeoutByField(map);
		double vuflow_gas_combst1 = vuflow_gas_combst1_list.get(0).getValue();
		
	    
		map.put("fieldnm", "mflow_waste");
		List<CombusitionElementInDTO> mflow_waste_list = optMapper.getElementinByname(map);
		double  mflow_waste = mflow_waste_list.get(0).getValue();
		
	    // pipe add (func: return value)
		map.put("fieldnm", "t2_waste");
		List<CombusitionPipeAddDTO> t2_waste_list = optMapper.getPipeaddByname(map);
		double t2_waste = t2_waste_list.get(0).getValue();
		
	    //  const vp1_air_combst1 = helper.plm.PIPEADD_NM_DB(data.wpid, 'vp1_air_combst1');
		map.put("fieldnm", "vp1_air_combst1");
		List<CombusitionPipeAddDTO> vp1_air_combst1_list = optMapper.getPipeaddByname(map);
		double vp1_air_combst1 =  vp1_air_combst1_list.get(0).getValue();
		pmap.put("vp1_air_combst1", vp1_air_combst1);
		
		map.put("fieldnm", "vfp_air_combst1");
		List<CombusitionPipeAddDTO> vfp_air_combst1_list = optMapper.getPipeaddByname(map);
		double vfp_air_combst1 =  vfp_air_combst1_list.get(0).getValue();
		
	   
	    map.put("fieldnm", "vuflow_air_combst12");
		List<CombusitionPipeOutDTO>vuflow_air_combst12_list = optMapper.getPipeoutByField(map);
		double vuflow_air_combst12 = vuflow_air_combst12_list.get(0).getValue();
	    
	    
	    
	    
	    
	    map.put("fieldnm", "vuflow_air1_combst12");
		List<CombusitionPipeOutDTO> vuflow_air1_combst12_list = optMapper.getPipeoutByField(map);
		double vuflow_air1_combst12 = vuflow_air1_combst12_list.get(0).getValue();
	    
	    map.put("fieldnm", "vuflow_iair_combst12");
		List<CombusitionPipeOutDTO> vuflow_iair_combst12_list = optMapper.getPipeoutByField(map);
		double vuflow_iair_combst12 = vuflow_iair_combst12_list.get(0).getValue();
		
	    
	    // constant in global (func: return value)
	    map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		
	    // element in (func: return value)
		map.put("code", 1102);
		List<CombusitionElementInDTO> wp_c_waste_list = optMapper.getElementin(map);
		double wp_c_waste = wp_c_waste_list.get(0).getValue();
		
	    map.put("code", 1103);
		List<CombusitionElementInDTO> wp_h_waste_list = optMapper.getElementin(map);
		double wp_h_waste = wp_h_waste_list.get(0).getValue();
		
	    map.put("code", 1105);
		List<CombusitionElementInDTO> wp_n_waste_list = optMapper.getElementin(map);
		double wp_n_waste = wp_n_waste_list.get(0).getValue();
		
		
	    
	    map.put("code", 1106);
		List<CombusitionElementInDTO> wp_s_waste_list = optMapper.getElementin(map);
		double wp_s_waste = wp_s_waste_list.get(0).getValue();
		
		
	    map.put("code", 1107);
		List<CombusitionElementInDTO> wp_cl_waste_list = optMapper.getElementin(map);
		double wp_cl_waste = wp_cl_waste_list.get(0).getValue();
		
		
	    map.put("code", 1100);
		List<CombusitionElementInDTO> wp_h2o_waste_list = optMapper.getElementin(map);
		double wp_h2o_waste = wp_h2o_waste_list.get(0).getValue();
		
	    map.put("code", 1201);
		List<CombusitionElementInDTO> ratio_exair_waste_list = optMapper.getElementin(map);
		double ratio_exair_waste = ratio_exair_waste_list.get(0).getValue();
		
		
	    // constant in facility (func: return value)
	    map.put("fieldnm", "k1_hlossubw_combst1");
		List<CombusitionConsTantDTO> k1_hlossubw_combst1_list =  optMapper.getConstantByField(map);
		double k1_hlossubw_combst1 = k1_hlossubw_combst1_list.get(0).getValue();
		
		
	    map.put("fieldnm", "k2_hlossbash_combst1");
		List<CombusitionConsTantDTO> k2_hlossbash_combst1_list =  optMapper.getConstantByField(map);
		double k2_hlossbash_combst1 = k2_hlossbash_combst1_list.get(0).getValue();
		
		
	    map.put("fieldnm", "k3_hlosswr_combst1");
		List<CombusitionConsTantDTO> k3_hlosswr_combst1_list =  optMapper.getConstantByField(map);
		double k3_hlosswr_combst1 = k3_hlosswr_combst1_list.get(0).getValue();
		
		
	    
	    map.put("fieldnm", "t_flyash_combst1");
		List<CombusitionPipeAddDTO> t_flyash_combst1_list = optMapper.getPipeaddByname(map);
		double t_flyash_combst1 = t_flyash_combst1_list.get(0).getValue();
		
		
	    map.put("fieldnm", "t_btmash_combst1");
		List<CombusitionPipeAddDTO> t_btmash_combst1_list = optMapper.getPipeaddByname(map);
		double t_btmash_combst1 = t_btmash_combst1_list.get(0).getValue();
		
		
	    map.put("fieldnm", "cp_ash_combst1");
		List<CombusitionPipeAddDTO> cp_ash_combst1_list = optMapper.getPipeaddByname(map);
		double cp_ash_combst1 = cp_ash_combst1_list.get(0).getValue();
		
		
	    map.put("fieldnm", "q_ubw_combst1");
		List<CombusitionPipeAddDTO> q_ubw_combst1_list = optMapper.getPipeaddByname(map);
		double q_ubw_combst1 = q_ubw_combst1_list.get(0).getValue();
		
		
	    //
	    // 1차연소공기 비율을 고려한 연소생성가스량 계산 : n2, o2
	    // 습도보정
	    double ah_kg = 0.01469; // 질량) kg-H2O/kg-DA
	    double ah_nm3 = (ah_kg * (0.21 * 32 + 0.79 * 28)) / 18; //부피) Nm3-H2O/Nm3-DA

	    double vuflow_co2a1_combst1 = ((molv_igas / 12) * wp_c_waste) / 100.0;
	    pmap.put("vuflow_co2a1_combst1", vuflow_co2a1_combst1);
	    // n2a1
	    double vuflow_n2a1_combst1 =
	      0.7905 * vuflow_air_combst12 * (vfp_air_combst1 / 100) +
	      ((molv_igas / 28) * wp_n_waste) / 100.0;
	    pmap.put("vuflow_n2a1_combst1", vuflow_n2a1_combst1);
	    // o2a1
	    double vuflow_o2a1_combst1 =
	      0.2095 *
	      (ratio_exair_waste - 1.0) *
	      vuflow_iair_combst12 *
	      (vfp_air_combst1 / 100);
	    pmap.put("vuflow_o2a1_combst1", vuflow_o2a1_combst1);
	    // 금산소각시설용
	    double vuflow_h2oa1_combst1 =
	      ((molv_igas / 18) * wp_h2o_waste) / 100 +
	      ((molv_igas / 2) * (wp_h_waste - (0 * wp_cl_waste) / 35.5)) / 100 +
	      0 * ah_nm3 * vuflow_air_combst12;
	    pmap.put("vuflow_h2oa1_combst1", vuflow_h2oa1_combst1);
	    double vuflow_so2a1_combst1 = ((molv_igas / 32) * wp_s_waste) / 100.0;
	    pmap.put("vuflow_h2oa1_combst1", vuflow_h2oa1_combst1);
	    
	    double vuflow_hcla1_combst1 = ((molv_igas / 35.5) * wp_cl_waste) / 100.0;
	    pmap.put("vuflow_hcla1_combst1", vuflow_hcla1_combst1);
	    double vuflow_gasa1_combst1 =
	      vuflow_co2a1_combst1 +
	      vuflow_n2a1_combst1 +
	      vuflow_o2a1_combst1 +
	      vuflow_h2oa1_combst1 +
	      vuflow_so2a1_combst1 +
	      vuflow_hcla1_combst1;
	    pmap.put("vuflow_gasa1_combst1", vuflow_gasa1_combst1);
	    // formula
	    // *) qout1_combst1 : 폐기물 착화온도 도달시까지 필요한 열량
	    // *) qout2_combst1 : 연소로내 불완전 연소손실 열량
	    // *) qout3_combst1 : 연소로 바닥재 + 비산재 보유열량
	    // *) qout4_combst1 : 연소로 외부방출 손실(로벽 방산) 열량
	    // *) qout5_combst1 : 연소로 배출가스 보유 열량 (현열) – 1차연소공기만큼
	    double ktemp = (double)pmap.get("ktemp");
	    double wp_c_drywaste = (double)pmap.get("wp_c_drywaste");
	    double wp_h_drywaste = (double)pmap.get("wp_h_drywaste");
	    double wp_o_drywaste = (double)pmap.get("wp_o_drywaste");
	    double wp_n_drywaste = (double)pmap.get("wp_n_drywaste");
	    double wp_s_drywaste = (double)pmap.get("wp_s_drywaste");
	    double wp_cl_drywaste = (double)pmap.get("wp_cl_drywaste");
	    double wp_ash_drywaste = (double)pmap.get("wp_ash_drywaste");
	    
	    
	    
	    double cpt2_waste = returnCpWaste(
	      t2_waste,
	      ktemp,
	      wp_c_drywaste,
	      wp_h_drywaste,
	      wp_o_drywaste,
	      wp_n_drywaste,
	      wp_s_drywaste,
	      wp_cl_drywaste,
	      wp_ash_drywaste
	    );
	    double cpt1_h2o_waste = (double)pmap.get("cpt1_h2o_waste");
	    double qout1_combst1 =
	      (cpt1_h2o_waste * (wp_h2o_waste / 100) +
	        cpt2_waste * (1 - wp_h2o_waste / 100)) *
	      t2_waste;
	    //
	    qout1_combst1 = 0; //only K-BEST Plant (연소로 착화열) and 금산군 한종
	    //
	    double qin_combst1 = (double)pmap.get("qin_combst1");
	    double qout2_combst1 = (qin_combst1 * k1_hlossubw_combst1) / 100;
	    //data.hb_20_inci.qout3_combst1 = (data.hb_10_inci.lhv_waste * data.hb_20_inci.k2_hlossbash_combst1) / 100;
	    // ash 열량계산을 위한 상수들
	    /*
	    let t_flyash_combst1 = 1049.793434; // degC
	    let t_btmash_combst1 = 500; // degC
	    let cp_ash_combst1 = 0.2; // kcal/(kg*degC)
	    let q_ubw_combst1 = 8100; // kcal/kg
	    */
	    double mflow_flyash_waste_outcombst1 = (double)pmap.get("mflow_flyash_waste_outcombst1");
	    double mflow_flyash_ubw_outcombst1 = (double)pmap.get("mflow_flyash_ubw_outcombst1");
	    double mflow_bottomash_waste_outcombst1 = (double)pmap.get("mflow_bottomash_waste_outcombst1");
	    double mflow_bottomash_ubw_outcombst1 = (double)pmap.get("mflow_bottomash_ubw_outcombst1");
	    
	    double  Q31_flyash_waste = cp_ash_combst1 * mflow_flyash_waste_outcombst1 * t_flyash_combst1;
	    double  Q32_flyash_hbw = q_ubw_combst1 * mflow_flyash_ubw_outcombst1;
	    double  Q33_bottomash_waste = cp_ash_combst1 * mflow_bottomash_waste_outcombst1 * t_btmash_combst1;
	    double  Q34_bottomash_hbw = q_ubw_combst1 * mflow_bottomash_ubw_outcombst1;
	    double qout3_combst1 =
	      (Q31_flyash_waste + Q32_flyash_hbw + Q33_bottomash_waste + Q34_bottomash_hbw) / mflow_waste;
	    //
	    // 금산군 한종 수식 : 바닥재, 비산재 계산
	    double Q33_bottomash = 0.3 * t_btmash_combst1 * mflow_bottomash_waste_outcombst1;
	    double mflow_flyash_outcombst1 = (double)pmap.get("mflow_flyash_outcombst1");
	    pmap.put("mflow_flyash_outcombst1", mflow_flyash_outcombst1);
	    double Q31_flyash = (cp_ash_combst1 + 0.015) * t_flyash_combst1 * mflow_flyash_outcombst1;

	    double qout31_combst1 = (Q31_flyash_waste + Q32_flyash_hbw) / mflow_waste;
	    //
	    //
	    qout3_combst1 = qin_combst1 * 0.0276; //only K-BEST Plant (바닥재)
	    qout3_combst1 = (Q31_flyash + Q33_bottomash) / mflow_waste;
	    //
	    //
	    double qout4_combst1 = (qin_combst1 * k3_hlosswr_combst1) / 100;
	    //
	    // # qout5_combst1 = cp_comp_outcombst1 * t_comp_outcombst1 * vuflow_gas_combst1
	    // cpxt = (qin_combst1 – (qout1_combst1 + qout2_combst1 + qout3_combst1+ qout4_combst1)) / (vp1_air_combst1 * vuflow_gas_combst1)
	    //
	    //
	    //
	    double cpxt =
	      (qin_combst1 -
	        (qout1_combst1 +
	          qout2_combst1 +
	          qout3_combst1 +
	          qout4_combst1)) /
	      vuflow_gasa1_combst1;
	    //
	    // store to db
	    pmap.put("cpxt", cpxt);
	    
	    map.put("fieldnm", "qout1_combst1");
		map.put("value", qout1_combst1);
		pmap.put("qout1_combst1", qout1_combst1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("fieldnm", "qout2_combst1");
		map.put("value", qout2_combst1);
		pmap.put("qin1_combst1", qout2_combst1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("fieldnm", "qout3_combst1");
		map.put("value", qout3_combst1);
		pmap.put("qin1_combst1", qout3_combst1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("fieldnm", "qout31_combst1");
		map.put("value", qout31_combst1);
		pmap.put("qin1_combst1", qout31_combst1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("fieldnm", "qout4_combst1");
		map.put("value", qout4_combst1);
		pmap.put("qin1_combst1", qout4_combst1);
		optMapper.updatePipeoutValue(map);
		
		return null;
	}

	@Override
	public HashMap hb_30_inci(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		double vuflow_co2a1_combst1 = (double)pmap.get("vuflow_hcla1_combst1");
		double vuflow_o2a1_combst1 = (double)pmap.get("vuflow_o2a1_combst1");
		pmap.put("vuflow_o2a1_combst1", vuflow_o2a1_combst1);
		double vuflow_n2a1_combst1 = (double)pmap.get("vuflow_n2a1_combst1");
		pmap.put("vuflow_n2a1_combst1", vuflow_n2a1_combst1);
		double vuflow_h2oa1_combst1 = (double)pmap.get("vuflow_h2oa1_combst1");
		pmap.put("vuflow_h2oa1_combst1", vuflow_h2oa1_combst1);
		double vuflow_so2a1_combst1 = (double)pmap.get("vuflow_so2a1_combst1");
		pmap.put("vuflow_so2a1_combst1", vuflow_so2a1_combst1);
		double vuflow_hcla1_combst1 = (double)pmap.get("vuflow_hcla1_combst1");
		pmap.put("vuflow_hcla1_combst1", vuflow_hcla1_combst1);
		double vuflow_gasa1_combst1 = (double)pmap.get("vuflow_gasa1_combst1");
		pmap.put("vuflow_gasa1_combst1", vuflow_gasa1_combst1);
		
		double vfp_co2a1_hb30 = (vuflow_co2a1_combst1 / vuflow_gasa1_combst1) * 100;
		pmap.put("vuflow_co2a1_combst1", vuflow_co2a1_combst1);
		double vfp_o2a1_hb30 = (vuflow_o2a1_combst1 / vuflow_gasa1_combst1) * 100;
		
		double vfp_n2a1_hb30 = (vuflow_n2a1_combst1 / vuflow_gasa1_combst1) * 100;
		
		double vfp_h2oa1_hb30 = (vuflow_h2oa1_combst1 / vuflow_gasa1_combst1) * 100;
		double vfp_so2a1_hb30 = (vuflow_so2a1_combst1 / vuflow_gasa1_combst1) * 100;
		double vfp_hcla1_hb30 = (vuflow_hcla1_combst1 / vuflow_gasa1_combst1) * 100;
		double vfp_coa1_hb30 = 0;
		double vfp_noa1_hb30 = 0;
		double[] vfgas2tbl_hb30 = new double[8];
		vfgas2tbl_hb30[0] = vfp_o2a1_hb30;
		vfgas2tbl_hb30[1] = vfp_n2a1_hb30;
		vfgas2tbl_hb30[2] = vfp_co2a1_hb30;
		vfgas2tbl_hb30[3] = vfp_coa1_hb30;
		vfgas2tbl_hb30[4] = vfp_noa1_hb30;
		vfgas2tbl_hb30[5] = vfp_so2a1_hb30;
		vfgas2tbl_hb30[6] = vfp_h2oa1_hb30;
		vfgas2tbl_hb30[7] = vfp_hcla1_hb30;
		
	    
	    double qout1_combst1 = (double)pmap.get("qout1_combst1");
	    double qout2_combst1 = (double)pmap.get("qout2_combst1");
	    double qout3_combst1 = (double)pmap.get("qout3_combst1");
	    double qout4_combst1 = (double)pmap.get("qout4_combst1");
	    
	    double vp1_air_combst1 = (double)pmap.get("vp1_air_combst1");
	    
	    double cpxt = (double)pmap.get("cpxt");
	    double timsi = tgasfcpxt(cpxt, vfgas2tbl_hb30);
	    //
	    double cp_gas_outcombst1 = returnCP_WGAS2(timsi, vfgas2tbl_hb30);
	    pmap.put("cp_gas_outcombst1", cp_gas_outcombst1);
	    double t_gas_outcombst1 = timsi;

	    double qout5_combst1 =
	      cp_gas_outcombst1 *
	      t_gas_outcombst1 *
	      // 2023.03.02, SHKim ; 단위(%)를 고려하여 / 100을 추가
	      (vp1_air_combst1 / 100) *
	      vuflow_gasa1_combst1;
	    
	    double qout_combst1 =
	      qout1_combst1 +
	      qout2_combst1 +
	      qout3_combst1 +
	      qout4_combst1 +
	      qout5_combst1;

	    // store to db
	    map.put("fieldnm", "t_gas_outcombst1");
		map.put("value", t_gas_outcombst1);
		pmap.put("t_gas_outcombst1", t_gas_outcombst1);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "qout5_combst1");
		map.put("value", qout5_combst1);
		pmap.put("qout5_combst1", qout5_combst1);
		optMapper.updatePipeoutValue(map);
			
		map.put("fieldnm", "qout_combst1");
		map.put("value", qout_combst1);
		pmap.put("qout_combst1", qout_combst1);
		optMapper.updatePipeoutValue(map);
	   
		return pmap;
	}

	private double tgasfcpxt(double cpxt, double[] vfgas2tbl) throws Exception {
	  // vfgas2tbl : [o2, n2, co2, co, no, so2, h2o, hcl]
	  double tmin = 100;
	  double  tmax = 1500;
	  double  timsi = 0.0;
	  double cp_tmin = returnCP_WGAS2(tmin, vfgas2tbl);
	  double cp_tmax = returnCP_WGAS2(tmax, vfgas2tbl);
	  double loopcnt = 0;

	  //
	  while (loopcnt < 20) {
	    if (cp_tmin * tmin < cpxt && cpxt < cp_tmax * tmax) {
	      timsi = (tmax + tmin) / 2;

	      if (0.00001 < Math.abs(cpxt - timsi * returnCP_WGAS2(timsi, vfgas2tbl))) {
	        if (cpxt > timsi * returnCP_WGAS2(timsi, vfgas2tbl)) {
	          tmin = timsi;
	          cp_tmin = returnCP_WGAS2(tmin, vfgas2tbl);
	        } else {
	          tmax = timsi;
	          cp_tmax = returnCP_WGAS2(tmax, vfgas2tbl);
	        }
	      } else {
	      
	        break;
	      }
	    } else {
	      
	      break;
	    }

	    loopcnt = loopcnt + 1; // avoid for infinite loop
	  }
	  return timsi;
	};
private double returnCP_WGAS2(double t_gas, double[] vfgas2tbl) throws Exception {
	  // vfgas2tbl : [o2, n2, co2, co, no, so2, h2o, hcl]
	  List<Map> CP_DB_DATA = new ArrayList();
	  Map cpmap = new HashMap();
	  
	  cpmap.put("temp", 100);
      cpmap.put("o2", 0.315);
      cpmap.put("n2", 0.311);
      cpmap.put("co2", 0.409);
      cpmap.put("co", 0.312);
      cpmap.put("no", 0.319);
      cpmap.put("so2", 0.435);
      cpmap.put("h2o", 0.36);
      cpmap.put("hcl", 0.311);
      cpmap.put("airlo", 0.311);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(0, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 200);
      cpmap.put("o2", 0.32);
      cpmap.put("n2", 0.312);
      cpmap.put("co2", 0.429);
      cpmap.put("co", 0.313);
      cpmap.put("no", 0.321);
      cpmap.put("so2", 0.454);
      cpmap.put("h2o", 0.364);
      cpmap.put("hcl", 0.311);
      cpmap.put("airlo", 0.313);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(1, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 300);
      cpmap.put("o2", 0.325);
      cpmap.put("n2", 0.313);
      cpmap.put("co2", 0.447);
      cpmap.put("co", 0.316);
      cpmap.put("no", 0.323);
      cpmap.put("so2", 0.47);
      cpmap.put("h2o", 0.369);
      cpmap.put("hcl", 0.313);
      cpmap.put("airlo", 0.315);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(2, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 400);
      cpmap.put("o2", 0.33);
      cpmap.put("n2", 0.316);
      cpmap.put("co2", 0.463);
      cpmap.put("co", 0.319);
      cpmap.put("no", 0.327);
      cpmap.put("so2", 0.483);
      cpmap.put("h2o", 0.374);
      cpmap.put("hcl", 0.315);
      cpmap.put("airlo", 0.318);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(3, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 500);
      cpmap.put("o2", 0.334);
      cpmap.put("n2", 0.319);
      cpmap.put("co2", 0.477);
      cpmap.put("co", 0.322);
      cpmap.put("no", 0.33);
      cpmap.put("so2", 0.495);
      cpmap.put("h2o", 0.38);
      cpmap.put("hcl", 0.317);
      cpmap.put("airlo", 0.321);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(4, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 600);
      cpmap.put("o2", 0.339);
      cpmap.put("n2", 0.321);
      cpmap.put("co2", 0.49);
      cpmap.put("co", 0.326);
      cpmap.put("no", 0.334);
      cpmap.put("so2", 0.506);
      cpmap.put("h2o", 0.386);
      cpmap.put("hcl", 0.32);
      cpmap.put("airlo", 0.325);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(5, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 700);
      cpmap.put("o2", 0.343);
      cpmap.put("n2", 0.325);
      cpmap.put("co2", 0.501);
      cpmap.put("co", 0.329);
      cpmap.put("no", 0.337);
      cpmap.put("so2", 0.515);
      cpmap.put("h2o", 0.392);
      cpmap.put("hcl", 0.322);
      cpmap.put("airlo", 0.328);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(6, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 800);
      cpmap.put("o2", 0.347);
      cpmap.put("n2", 0.329);
      cpmap.put("co2", 0.512);
      cpmap.put("co", 0.332);
      cpmap.put("no", 0.34);
      cpmap.put("so2", 0.523);
      cpmap.put("h2o", 0.399);
      cpmap.put("hcl", 0.324);
      cpmap.put("airlo", 0.331);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(7, cpmap);
	  
	  cpmap = new HashMap();
	  cpmap.put("temp", 900);
      cpmap.put("o2", 0.35);
      cpmap.put("n2", 0.331);
      cpmap.put("co2", 0.52);
      cpmap.put("co", 0.335);
      cpmap.put("no", 0.344);
      cpmap.put("so2", 0.53);
      cpmap.put("h2o", 0.405);
      cpmap.put("hcl", 0.327);
      cpmap.put("airlo", 0.334);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(8, cpmap);
	  
	  cpmap = new HashMap();
	  cpmap.put("temp", 1000);
      cpmap.put("o2", 0.354);
      cpmap.put("n2", 0.334);
      cpmap.put("co2", 0.529);
      cpmap.put("co", 0.338);
      cpmap.put("no", 0.346);
      cpmap.put("so2", 0.536);
      cpmap.put("h2o", 0.412);
      cpmap.put("hcl", 0.329);
      cpmap.put("airlo", 0.338);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(9, cpmap);
	  
	  cpmap = new HashMap();
	  cpmap.put("temp", 1100);
      cpmap.put("o2", 0.356);
      cpmap.put("n2", 0.338);
      cpmap.put("co2", 0.537);
      cpmap.put("co", 0.341);
      cpmap.put("no", 0.349);
      cpmap.put("so2", 0.542);
      cpmap.put("h2o", 0.418);
      cpmap.put("hcl", 0.331);
      cpmap.put("airlo", 0.34);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(10, cpmap);
 
	  cpmap = new HashMap();
      cpmap.put("temp", 1200);
      cpmap.put("o2", 0.359);
      cpmap.put("n2", 0.34);
      cpmap.put("co2", 0.544);
      cpmap.put("co", 0.344);
      cpmap.put("no", 0.351);
      cpmap.put("so2", 0.546);
      cpmap.put("h2o", 0.425);
      cpmap.put("hcl", 0.333);
      cpmap.put("airlo", 0.343);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(11, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 1300);
      cpmap.put("o2", 0.362);
      cpmap.put("n2", 0.342);
      cpmap.put("co2", 0.55);
      cpmap.put("co", 0.346);
      cpmap.put("no", 0.354);
      cpmap.put("so2", 0.55);
      cpmap.put("h2o", 0.43);
      cpmap.put("hcl", 0);
      cpmap.put("airlo", 0.345);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(12, cpmap);
	  
	  cpmap.put("temp", 1500);
	  cpmap.put("o2", 0.366);
	  cpmap.put("n2", 0.347);
      cpmap.put("co2", 0.561);
      cpmap.put("co", 0.351);
      cpmap.put("no", 0.358);
      cpmap.put("so2", 0.557);
      cpmap.put("h2o", 0.442);
      cpmap.put("hcl", 0);
      cpmap.put("airlo", 0.35);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(13, cpmap);
	  
	  cpmap = new HashMap();
      cpmap.put("temp", 1400);
      cpmap.put("o2", 0.364);
      cpmap.put("n2", 0.345);
      cpmap.put("co2", 0.556);
      cpmap.put("co", 0.348);
      cpmap.put("no", 0.356);
      cpmap.put("so2", 0.554);
      cpmap.put("h2o", 0.437);
      cpmap.put("hcl", 0);
      cpmap.put("airlo", 0.348);
      cpmap.put("mixgas", 0);
      cpmap.put("slope", 0);
      CP_DB_DATA.add(14,cpmap);
      
      Map lo = new HashMap();
      lo.put("1500", 0);
	  lo.put("1400", 0);
	  lo.put("1300", 0);
	  lo.put("1200", 0.371);
	  lo.put("1100", 0.368);
	  lo.put("1000", 0.364);
	  lo.put("900", 0.361);
	  lo.put("800", 0.357);
	  lo.put("700", 0.352);
	  lo.put("600", 0.348);
	  lo.put("500", 0.344);
	  lo.put("400", 0.339);
	  lo.put("300", 0.335);
	  lo.put("200", 0.331);
	  lo.put("100", 0.327);
	  lo.put("0", 0.323);
	  
	  for(int i=0; i < CP_DB_DATA.size(); i++) {
		  //Map cpmap = (Map)CP_DB_DATA.get(i);
		  double o2 = (double)CP_DB_DATA.get(i).get("o2");
		  CP_DB_DATA.get(i).put("o2", BigDecimal.valueOf((vfgas2tbl[0] * o2)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double n2 = (double)CP_DB_DATA.get(i).get("n2");
		  CP_DB_DATA.get(i).put("n2", BigDecimal.valueOf((vfgas2tbl[1] * n2)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double co2 = (double)CP_DB_DATA.get(i).get("co2");
		  CP_DB_DATA.get(i).put("co2", BigDecimal.valueOf((vfgas2tbl[2] * co2)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double co = (double)CP_DB_DATA.get(i).get("co");
		  CP_DB_DATA.get(i).put("co", BigDecimal.valueOf((vfgas2tbl[3] * co)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double no = (double)CP_DB_DATA.get(i).get("no");
		  CP_DB_DATA.get(i).put("no", BigDecimal.valueOf((vfgas2tbl[4] * no)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double so2 = (double)CP_DB_DATA.get(i).get("so2");
		  CP_DB_DATA.get(i).put("so2", BigDecimal.valueOf((vfgas2tbl[5] * so2)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double h2o = (double)CP_DB_DATA.get(i).get("h2o");
		  CP_DB_DATA.get(i).put("h2o", BigDecimal.valueOf((vfgas2tbl[6] * h2o)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double hcl = (double)CP_DB_DATA.get(i).get("hcl");
		  CP_DB_DATA.get(i).put("hcl", BigDecimal.valueOf((vfgas2tbl[7] * hcl)).setScale(12, RoundingMode.HALF_UP)
	    		    .doubleValue()) ;
		  
		  double temp = (double)CP_DB_DATA.get(i).get("temp");
		  CP_DB_DATA.get(i).put("temp", lo.get(temp));
		  
	  }
	  double temp200mixgas = 0;
	  double temp1200mixgas = 0;
	  double temp200slope = 0;
	  double temp1200slope = 0;
	  double temp1300mixgas = 0;
	  double temp1400mixgas = 0;
	  double temp1500mixgas = 0;
	  
	  for(int i=0; i < CP_DB_DATA.size(); i++) {
		  double temp = (double)CP_DB_DATA.get(i).get("temp");
		  if (temp < 1300 && temp > 100) {
			  
			  if(temp == 200) {
				  Map tempmap = new HashMap();
				  tempmap.put("wpid", OptConstant.WPID);
				  tempmap.put("temp", temp);
				  List<CombusitionCpDTO> o = optMapper.getCpBytemp(tempmap);
				  temp200mixgas = o.get(0).getMixgas();
			  } else if(temp == 1200) {
				  Map tempmap = new HashMap();
				  tempmap.put("wpid", OptConstant.WPID);
				  tempmap.put("temp", temp);
				  List<CombusitionCpDTO> o = optMapper.getCpBytemp(tempmap);
				  temp1200mixgas = o.get(0).getMixgas();				  
				  
			  }
			  Map tempmap = new HashMap();
			  tempmap.put("wpid", OptConstant.WPID);
			  tempmap.put("temp", temp - 100);
			  List<CombusitionCpDTO> o = optMapper.getCpBytemp(tempmap);
			
			
			  CP_DB_DATA.get(i).put("slope",BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
			  		     .doubleValue());
			  if(temp == 200) {
				  temp200slope = BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
				  		     .doubleValue();
				  CP_DB_DATA.get(0).put("slope",BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
				  		     .doubleValue());
			  } else if(temp == 1200) {
				  temp1200slope = BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
				  		     .doubleValue();				  
			  }
		  } else {
			 
			  if(temp == 1300) {
				  CP_DB_DATA.get(i).put("slope",temp1200slope);
				  CP_DB_DATA.get(i).put("mixgas",temp1200slope * temp200mixgas * 100 + temp200mixgas);
				  temp1300mixgas = temp1200slope * temp200mixgas * 100 + temp200mixgas;
			  } else if(temp == 1400) {
				  CP_DB_DATA.get(i).put("slope",temp1200slope);
				  CP_DB_DATA.get(i).put("mixgas",temp1200slope * temp1300mixgas * 100 + temp1300mixgas);
				  temp1400mixgas = temp1200slope * temp1300mixgas * 100 + temp1300mixgas;
				  
			  } else if(temp == 1500) {
				  CP_DB_DATA.get(i).put("slope",temp1200slope);
				  CP_DB_DATA.get(i).put("mixgas",temp1200slope * temp1400mixgas * 100 + temp1400mixgas);
			  } else if(temp == 100) {
				  
			  }
			  
		      
		  }
	  }
	 

	  // 1) t_gas :폐기물연소 배가스 온도 입력
	  // 2) 연산
	  // n1 = roundoff ( t_gas x 0.01 ) : n1 정수
	  // t1 = n1 x 100,0

	  double n1 = Math.round(t_gas * 0.01);
	  double t1 = n1 * 100;
	  double cp_wgas = 0;
	  int index = 0;
	  if(t1 == 100) {
		  index = 0;
	  } else if(t1 == 200) {
		  index = 1;
	  } else if(t1 == 300) {
		  index = 2;
	  } else if(t1 == 400) {
		  index = 3;
	  } else if(t1 == 500) {
		  index = 4;
	  } else if(t1 == 600) {
		  index = 5;
	  } else if(t1 == 700) {
		  index = 6;
	  } else if(t1 == 800) {
		  index = 7;
	  } else if(t1 == 900) {
		  index = 8;
	  } else if(t1 == 1000) {
		  index = 9;
	  } else if(t1 == 1100) {
		  index = 10;
	  } else if(t1 == 1200) {
		  index = 11;
	  } else if(t1 == 1300) {
		  index = 12;
	  } else if(t1 == 1400) {
		  index = 13;
	  } else if(t1 == 1500) {
		  index = 14;
	  }
	  if (t1 == t_gas) {
	    cp_wgas = (double)CP_DB_DATA.get(index).get("mixgas");;
	  } else {
	    // const n2 = n1 + 1;
	    // const t2 = t1 + 100; change (+) to (-)
	    double t2 = t1 + 100;
	    // const c1 = w2gas_cptbl(n1, 11);
	    double c1 = (double)CP_DB_DATA.get(index).get("mixgas");
	    // const c2 = w2gas_cptbl(n2, 11);
	    double c2 = (double)CP_DB_DATA.get(index+1).get("mixgas");;;
	    // cp_wgas = ((t_gas - t1) * (c1 - c2)) / (t1 - t2) + c1;
	    cp_wgas = c1 - ((c1 - c2) * (t1 - t_gas)) / (t1 - t2);
	  }
	  return cp_wgas;
}
//		helper.CP_WGAS2 = function (t_gas, vfgas2tbl) {

//			};
			
	@Override
	public HashMap hb_40_inci(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "mflow_waste");
		List<CombusitionElementInDTO> mflow_waste_list = optMapper.getElementinByname(map);
		double  mflow_waste =mflow_waste_list.get(0).getValue();
		
		
	    // const wp_c_waste = helper.plm.ELEMENTIN_NM_DB(data.wpid, 'wp_c_waste');
	    // pipe add (func: return desval)
		map.put("fieldnm", "vp1_air_combst1");
		List<CombusitionPipeAddDTO> vp1_air_combst1_list = optMapper.getPipeaddByname(map);
		double vp1_air_combst1 = vp1_air_combst1_list.get(0).getValue();
		
		map.put("fieldnm", "mpv_dioxin_combst1");
		List<CombusitionPipeAddDTO> mpv_dioxin_combst1_list = optMapper.getPipeaddByname(map);
		double mpv_dioxin_combst1 = mpv_dioxin_combst1_list.get(0).getValue();
		// pipe in (func: return value)
	    // const vuflow_gas_combst1 = helper.plm.PIPEOUT_NM_DB(data.wpid, 'vuflow_gas_combst1');
	    // constant in global (func: return value)
		 map.put("fieldnm", "ktemp");
		 List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		 double ktemp = ktemp_list.get(0).getValue();
		
		 map.put("fieldnm", "unit_mega");
		 List<CombusitionConsTantDTO> unit_mega_list =  optMapper.getConstantByField(map);
		 double unit_mega = unit_mega_list.get(0).getValue();
		
		 map.put("fieldnm", "unit_kilo");
		 List<CombusitionConsTantDTO> unit_kilo_list =  optMapper.getConstantByField(map);
		 double unit_kilo = unit_kilo_list.get(0).getValue();
		 
		 map.put("fieldnm", "molm_no2");
		 List<CombusitionConsTantDTO> molm_no2_list =  optMapper.getConstantByField(map);
		 double molm_no2 = molm_no2_list.get(0).getValue();
		 
		 map.put("fieldnm", "molv_igas");
		 List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		 double molv_igas = molv_igas_list.get(0).getValue();
		 
	    // const gas_constant = helper.plm.get_constantin_from_name('gas_constant').value;
	    // const molm_dioxin = helper.plm.get_constantin_from_name('molm_dioxin').value;
	    // constant in facility (func: return value)
		 map.put("fieldnm", "k1_hlossubw_combst1");
		 List<CombusitionConsTantDTO> k1_hlossubw_combst1_list =  optMapper.getConstantByField(map);
		 double k1_hlossubw_combst1 = k1_hlossubw_combst1_list.get(0).getValue();
		 
		 map.put("fieldnm", "k4_no2_EPA");
		 List<CombusitionConsTantDTO> k4_no2_EPA_list =  optMapper.getConstantByField(map);
		 double k4_no2_EPA = k4_no2_EPA_list.get(0).getValue();
		 
		 
		 map.put("fieldnm", "k7_lossign_combst1");
		 List<CombusitionConsTantDTO> k7_lossign_combst1_list =  optMapper.getConstantByField(map);
		 double k7_lossign_combst1 = k7_lossign_combst1_list.get(0).getValue();
		 double vuflow_co2a1_combst1 =(double)pmap.get("vuflow_co2a1_combst1");
		 double vuflow_n2a1_combst1 =(double)pmap.get("vuflow_n2a1_combst1");
		 double vuflow_o2a1_combst1 =(double)pmap.get("vuflow_o2a1_combst1");
		 double vuflow_h2oa1_combst1 =(double)pmap.get("vuflow_h2oa1_combst1");
		 double vuflow_so2a1_combst1 =(double)pmap.get("vuflow_so2a1_combst1");
		 double vuflow_hcla1_combst1 =(double)pmap.get("vuflow_hcla1_combst1");
		 double vuflow_gasa1_combst1 =(double)pmap.get("vuflow_gasa1_combst1");
		 double t_gas_outcombst1 =(double)pmap.get("t_gas_outcombst1");
		 double cp_gas_outcombst1 =(double)pmap.get("cp_gas_outcombst1");
		 double mflow_sw_outcombst1 =(double)pmap.get("mflow_sw_outcombst1");
		 double mflow_flyash_outcombst1 =(double)pmap.get("mflow_flyash_outcombst1");
		 double mflow_sw1_outcombst1 =(double)pmap.get("mflow_sw1_outcombst1");
		 double mflow_sw2_outcombst1 =(double)pmap.get("mflow_sw2_outcombst1");
		 
	    double vflow_co2_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_co2a1_combst1;
	    double vflow_n2_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_n2a1_combst1;
	    double vflow_o2_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_o2a1_combst1;
	    double vflow_h2o_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_h2oa1_combst1;
	    double vflow_so2_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_so2a1_combst1;
	    double vflow_hcl_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_hcla1_combst1;
	    double vflow_gas_outcombst1 = (vp1_air_combst1 / 100) * mflow_waste * vuflow_gasa1_combst1;
	    
	    double vfp_co2_outcombst1 =
	      (vflow_co2_outcombst1 / vflow_gas_outcombst1) * 100;
	    double vfp_n2_outcombst1 =
	      (vflow_n2_outcombst1 / vflow_gas_outcombst1) * 100;
	    double vfp_o2_outcombst1 =
	      (vflow_o2_outcombst1 / vflow_gas_outcombst1) * 100;
	    double vfp_h2o_outcombst1 =
	      (vflow_h2o_outcombst1 / vflow_gas_outcombst1) * 100;
	    double vfp_so2_outcombst1 =
	      (vflow_so2_outcombst1 / vflow_gas_outcombst1) * 100;
	    double vfp_hcl_outcombst1 =
	      (vflow_hcl_outcombst1 / vflow_gas_outcombst1) * 100;

	    double vflowa_gas_outcombst1 =
	      ((ktemp + t_gas_outcombst1) / ktemp) * vflow_gas_outcombst1;
	    double q_gas_outcombst1 =
	      cp_gas_outcombst1 * t_gas_outcombst1 * vuflow_gasa1_combst1;

	    // *) vppm_co_outcombst1 = co 발생량(ppm)
	    double vppm_co_outcombst1 =
	      (k1_hlossubw_combst1 / 100) * (k7_lossign_combst1 / 100) * (vfp_co2_outcombst1 / 100) * unit_mega;
	    double vppm_no2_outcombst1 =
	      (k4_no2_EPA * mflow_waste * molv_igas * unit_kilo) / (vflow_gas_outcombst1 * molm_no2);
	    //
	    // 2023.03.02, SHKim ; Consideration of each units
	    double vppm_so2_outcombst1 = (vfp_so2_outcombst1 / 100) * unit_mega;
	    double vppm_hcl_outcombst1 = (vfp_hcl_outcombst1 / 100) * unit_mega;
	    double mpv_dioxin_outcombst1 = mpv_dioxin_combst1;
	    // gen bottomash in incinerator
	    double mflow_bottomash_outcombst1 =
	      mflow_sw_outcombst1 - mflow_flyash_outcombst1;
	    //
	    double vflow_drygas_outcombst1 = vflow_gas_outcombst1 - vflow_h2o_outcombst1;
	    double mpv1_flyash_outcombst1 =
	      (mflow_flyash_outcombst1 / vflow_drygas_outcombst1) * unit_mega;
	    // O2 calibration
	    double mpv_flyash_outcombst1 =
	      (mflow_flyash_outcombst1 / vflow_drygas_outcombst1) *
	      unit_mega *
	      ((21 - 12) / (21 - (vflow_o2_outcombst1 / vflow_drygas_outcombst1) * 100));

	    // mpv_flyash_outcombst1 =
	    //   (mflow_flyash_outcombst1 * unit_mega) / vflow_gas_outcombst1;
	    double mflow_ash_combst1 = mflow_sw1_outcombst1 + mflow_sw2_outcombst1;
	    // *)실제 배출되는 ash량
	    double mflowa_ash_outcombst1 = mflow_ash_combst1 - mflow_flyash_outcombst1;

	    // store to db
	    
	    map.put("fieldnm", "vflow_co2_outcombst1");
		map.put("value", vflow_co2_outcombst1);
		pmap.put("vflow_co2_outcombst1", vflow_co2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_n2_outcombst1");
		map.put("value", vflow_n2_outcombst1);
		pmap.put("vflow_n2_outcombst1", vflow_n2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_o2_outcombst1");
		map.put("value", vflow_o2_outcombst1);
		pmap.put("vflow_o2_outcombst1", vflow_o2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_h2o_outcombst1");
		map.put("value", vflow_h2o_outcombst1);
		pmap.put("vflow_h2o_outcombst1", vflow_h2o_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_so2_outcombst1");
		map.put("value", vflow_so2_outcombst1);
		pmap.put("vflow_so2_outcombst1", vflow_so2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_hcl_outcombst1");
		map.put("value", vflow_hcl_outcombst1);
		pmap.put("vflow_hcl_outcombst1", vflow_hcl_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_gas_outcombst1");
		map.put("value", vflow_gas_outcombst1);
		pmap.put("vflow_gas_outcombst1", vflow_gas_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vfp_co2_outcombst1");
		map.put("value", vfp_co2_outcombst1);
		pmap.put("vfp_co2_outcombst1", vfp_co2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vfp_n2_outcombst1");
		map.put("value", vfp_n2_outcombst1);
		pmap.put("vfp_n2_outcombst1", vfp_n2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vfp_o2_outcombst1");
		map.put("value", vfp_o2_outcombst1);
		pmap.put("vfp_o2_outcombst1", vfp_o2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vfp_h2o_outcombst1");
		map.put("value", vfp_h2o_outcombst1);
		pmap.put("vfp_h2o_outcombst1", vfp_h2o_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vfp_so2_outcombst1");
		map.put("value", vfp_so2_outcombst1);
		pmap.put("vfp_so2_outcombst1", vfp_so2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vfp_hcl_outcombst1");
		map.put("value", vfp_hcl_outcombst1);
		pmap.put("vfp_hcl_outcombst1", vfp_hcl_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("fieldnm", "mpv_dioxin_outcombst1");
		map.put("value", mpv_dioxin_outcombst1);
		pmap.put("mpv_dioxin_outcombst1", mpv_dioxin_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflowa_gas_outcombst1");
		map.put("value", vflowa_gas_outcombst1);
		pmap.put("vflowa_gas_outcombst1", vflowa_gas_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "q_gas_outcombst1");
		map.put("value", q_gas_outcombst1);
		pmap.put("q_gas_outcombst1", q_gas_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_co_outcombst1");
		map.put("value", vppm_co_outcombst1);
		pmap.put("vppm_co_outcombst1", vppm_co_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_no2_outcombst1");
		map.put("value", vppm_no2_outcombst1);
		pmap.put("vppm_no2_outcombst1", vppm_no2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_so2_outcombst1");
		map.put("value", vppm_so2_outcombst1);
		pmap.put("vppm_so2_outcombst1", vppm_so2_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_hcl_outcombst1");
		map.put("value", vppm_hcl_outcombst1);
		pmap.put("vppm_hcl_outcombst1", vppm_hcl_outcombst1);
		optMapper.updatePipeoutValue(map);
		
	    //  data.insert_data_to_db(data, 'mflow_flyash_outcombst1', data.hb_10_inci.mflow_flyash_outcombst1);
	    map.put("fieldnm", "mflow_bottomash_outcombst1");
		map.put("value", mflow_bottomash_outcombst1);
		pmap.put("mflow_bottomash_outcombst1", mflow_bottomash_outcombst1);
		optMapper.updatePipeoutValue(map);
		

	    map.put("fieldnm", "mpv_flyash_outcombst1");
		map.put("value", mpv_flyash_outcombst1);
		pmap.put("mpv_flyash_outcombst1", mpv_flyash_outcombst1);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

   
}
