package com.kii.potal.admin.code.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CodeDTO {
   private String cdGrpId;      //코드그룹아이디
   private String cdId;         //코드아이디
   private String topCdId;      //상위코드아이디
   private String cdNm;         //코드명
   private String cdVu;         //코드값
   private String registDt;     //등록일시
   private String rgstrNo;      //등록자번호
   private String updtDt;       //수정일시
   private String updusrNo;     //수정자번호
   private String delDt;        //삭제일시
   private String dltrNo;       //삭제자번호
   private String delYn;        //삭제여부
   private String viewYn;       //보기여부

}
