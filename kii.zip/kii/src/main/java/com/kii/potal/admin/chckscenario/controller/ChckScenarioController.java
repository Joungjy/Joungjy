package com.kii.potal.admin.chckscenario.controller;

import com.kii.potal.admin.chckscenario.service.ChckScenarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class ChckScenarioController {


    @Autowired
    ChckScenarioService chckScenarioService;

    /**
     * 점검 시나리오 리스트 조회
     *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오 리스트 조회 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioList.do", method = RequestMethod.GET)
    public String getChckSenarioList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "admin/chckScenario/chck_scenario_list";

    }

    /**
     * 점검 시나리오 태그 리스트 조회
     *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오 태그 리스트 조회 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioTagList.do", method = RequestMethod.GET)
    public String getChckSenarioTagList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "admin/chckScenario/chck_scenario_tag_list";

    }


    /**
     * 점검 시나리오 정보 등록
     * *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오 정보 등록 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioInsertProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String insertChckSenarioItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }

    /**
     * 점검 시나리오 태그 정보 등록
     * *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오  태그 정보 등록 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioTagInsertProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String insertChckSenarioTagItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }

    /**
     * 점검 시나리오 정보 수정
     * *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오 정보 수정 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioUpdateProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String updateChckSenarioItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }

    /**
     * 점검 시나리오 태그 정보 수정
     * *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오 태그 정보 수정 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioTagUpdateProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String updateChckSenarioTagItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }

    /**
     * 점검 시나리오  정보 삭제
     * *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오  정보 삭제 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioDeleteProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String deleteChckSenarioItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }


    /**
     * 점검 시나리오 태그 정보 삭제
     * *
     * @param model
     * @param request
     * @param response
     * @return 점검 시나리오 태그 정보 삭제 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/chckScenarioTagDeleteProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String deleteChckSenarioTagItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }
    
    







}
