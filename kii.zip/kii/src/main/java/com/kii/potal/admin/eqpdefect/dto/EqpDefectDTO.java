package com.kii.potal.admin.eqpdefect.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EqpDefectDTO {

    private String eqpDefectId;  //고장이력 등록번호
    private String title;        //고장이력 제목
    private String facility;     //설비
    private String part;         //부품
    private String parts;        //파츠
    private String status;       //상태
    private String order;        //지시자
    private String orderDt;      //지시일시
    private String repairDt;     //수리일시
    private String registDt;     //등록일
    private String regstrNo;     //등록자 번호
    private String updtDt;       //수정일
    private String updtNo;       //수정자 번호
    private String delDt;        //삭제일시
    private String dltrNo;       //삭제자번호
    private String delYn;        //삭제여부



}
