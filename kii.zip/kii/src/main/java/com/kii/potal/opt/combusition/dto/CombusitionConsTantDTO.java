package com.kii.potal.opt.combusition.dto;



import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class CombusitionConsTantDTO {
    private Long idx; 
    private Long wpid;
    private Long facilitycd; 
    private String facilitynm; 
    private Long code; 
    private String name; 
    private String fieldnm; 
    private String statecd; 
    private Float value; 
    private String unit;
    private String color;
    private String createddate; 
    private String updateddate;
    private double actval ;
   


    @Builder
    public CombusitionConsTantDTO(Long idx, Long wpid, Long facilitycd, Long code) {
        this.idx = idx;
        this.wpid = wpid;
        this.facilitycd = facilitycd;
        this.code = code;
    }
}
