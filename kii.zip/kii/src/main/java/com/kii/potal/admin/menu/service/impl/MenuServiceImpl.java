package com.kii.potal.admin.menu.service.impl;

import com.kii.potal.admin.menu.dto.MenuDTO;
import com.kii.potal.admin.menu.service.MenuService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class MenuServiceImpl extends EgovAbstractServiceImpl implements MenuService {


    @Autowired
    MenuMapper menuMapper;

    @Override
    public List<MenuDTO> getMenuList(MenuDTO menuDTO) {
        return null;
    }

    @Override
    public MenuDTO getMenuItem(MenuDTO menuDTO) {
        return null;
    }

    @Override
    public void insertMenuItem(MenuDTO menuDTO) {

    }

    @Override
    public void updateMenuItem(MenuDTO menuDTO) {

    }

    @Override
    public void deleteMenuItem(MenuDTO menuDTO) {

    }
}
