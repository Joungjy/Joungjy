package com.kii.potal.admin.eqptag.controller;


import com.kii.potal.admin.eqptag.service.EqpTagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class EqpTagController {

    @Autowired
    EqpTagService service;
    /**
     * 태그 관리 리스트 조회
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 리스트 조회 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagList.do", method = RequestMethod.GET)
    public String getEqpTagList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "admin/eqptag/eqp_tag_list";
    }

    /**
     * 태그 관리 상세 조회
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 상세 조회 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagView.do", method = RequestMethod.GET)
    public String getEqpTagItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "admin/eqptag/eqp_tag_view";
    }

    /**
     * 태그 관리 등록 
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 등록 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagInsert.do", method = RequestMethod.GET)
    public String insertEqpTagItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "admin/eqptag/eqp_tag_insert";
    }

    /**
     * 태그 관리 등록 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 등록 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagInsertProc.do", method = RequestMethod.POST)
    public String insertEqpTagItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "redirect:/admin/eqpTagInsert.do";
    }

    /**
     * 태그 관리 수정
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 수정 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagUpdate.do", method = RequestMethod.GET)
    public String updateEqpTagItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "admin/eqptag/eqp_tag_update";
    }

    /**
     * 태그 관리 수정 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 수정 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagUpdateProc.do", method = RequestMethod.GET)
    public String updateEqpTagItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "redirect:/admin/eqpTagUpdate.do";
    }

    /**
     * 태그 관리 삭제 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 태그 관리 삭제 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/eqpTagDeleteProc.do", method = RequestMethod.POST)
    @ResponseBody
    public String deleteEqpTagItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {


        return "json";
    }


}
