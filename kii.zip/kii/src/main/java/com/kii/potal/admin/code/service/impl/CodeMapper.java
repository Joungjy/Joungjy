package com.kii.potal.admin.code.service.impl;

import com.kii.potal.admin.code.dto.CodeDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface CodeMapper {
    //코드 리스트
    List<CodeDTO> getCodeList(CodeDTO codeDTO);
    //코드 상세 정보
    CodeDTO getCodeItem(CodeDTO codeDTO);
    //코드 정보 삽입
    void insertCodeItem(CodeDTO codeDTO);
    //코드 정보 수정
    void updateCodeItem(CodeDTO codeDTO);
    //코드 정보 삭제
    void deleteCodeItem(CodeDTO codeDTO);
}
