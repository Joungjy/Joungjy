package com.kii.potal.opt.combusition.service.impl;



import java.util.HashMap;
import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaWsService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaWsServiceImpl extends EgovAbstractServiceImpl implements OptFormulaWsService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap mb_1_1_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		   // pipe in (func: return value)
	    // const vflow_o2_inWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_o2_inWS');
	    // const vflow_n2_inWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_n2_inWS');
	    
		map.put("fieldnm", "vflow_o2_outSCR");
		List<CombusitionPipeOutDTO>vflow_o2_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_o2_inWS = vflow_o2_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_n2_outSCR");
		List<CombusitionPipeOutDTO>vflow_n2_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_n2_inWS = vflow_n2_inWS_list.get(0).getValue();
		
	    // pipe add (func: return value)
		map.put("fieldnm", "vflow_airpea_inWS");
		List<CombusitionPipeAddDTO> vflow_airpea_inWS_list = optMapper.getPipeaddByname(map);
		double vflow_airpea_inWS =vflow_airpea_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_nozzle_WS");
		List<CombusitionPipeAddDTO> ea_nozzle_WS_list = optMapper.getPipeaddByname(map);
		double ea_nozzle_WS = ea_nozzle_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "t_air_inWS");
		List<CombusitionPipeAddDTO> t_air_inWS_list = optMapper.getPipeaddByname(map);
		double t_air_inWS = t_air_inWS_list.get(0).getValue();
		
	    
		map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO>ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    map.put("fieldnm", "rt_o2inair");
		List<CombusitionConsTantDTO> rt_o2inair_list =  optMapper.getConstantByField(map);
		double rt_o2inair = rt_o2inair_list.get(0).getValue();
		
	    map.put("fieldnm", "rt_n2inair");
		List<CombusitionConsTantDTO> rt_n2inair_list =  optMapper.getConstantByField(map);
		double rt_n2inair = rt_n2inair_list.get(0).getValue();
		
	    // vflow_air_inWS = vflow_airpea_inWS * ea_nozzle_WS
	    // vflow_o2_outWS = vflow_o2_inWS + vflow_air_inWS * ktemp / (ktemp + t_air_inWS) * rt_o2inair
	    // vflow_n2_outWS = vflow_n2_inWS + vflow_air_inWS * ktemp / (ktemp + t_air_inWS) * rt_n2inair

	    // formula
	    double vflow_air_inWS = vflow_airpea_inWS * ea_nozzle_WS;
	    double vflow_o2_outWS =
	      vflow_o2_inWS + ((vflow_air_inWS * ktemp) / (ktemp + t_air_inWS)) * rt_o2inair;
	    double vflow_n2_outWS =
	      vflow_n2_inWS + ((vflow_air_inWS * ktemp) / (ktemp + t_air_inWS)) * rt_n2inair;

	    pmap.put("vflow_air_inWS", vflow_air_inWS);
	    pmap.put("vflow_o2_outWS", vflow_o2_outWS);
	    pmap.put("vflow_n2_outWS", vflow_n2_outWS);
	    
	    // store to db
		map.put("fieldnm", "vflow_o2_outWS");
		map.put("value", vflow_o2_outWS);
		pmap.put("vflow_o2_outWS", vflow_o2_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_n2_outWS");
		map.put("value", vflow_n2_outWS);
		pmap.put("vflow_n2_outWS", vflow_n2_outWS);
		optMapper.updatePipeoutValue(map);
		
	    
		return pmap;
	}

	@Override
	public HashMap mb_1_2_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    // data.mb_1_2_ws.vflow_co2_outWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_co2_inWS');
	    // data.mb_1_2_ws.vflow_hcl_outWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_hcl_inWS');
	    // data.mb_1_2_ws.vflow_so2_outWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_so2_inWS');
	    
	    map.put("fieldnm", "vflow_co2_outSCR");
		List<CombusitionPipeOutDTO>vflow_co2_outWS_list = optMapper.getPipeoutByField(map);
		double vflow_co2_outWS = vflow_co2_outWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_hcl_outSCR");
		List<CombusitionPipeOutDTO>vflow_hcl_outWS_list = optMapper.getPipeoutByField(map);
		double vflow_hcl_outWS = vflow_hcl_outWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_so2_outSCR");
		List<CombusitionPipeOutDTO>vflow_so2_outWS_list = optMapper.getPipeoutByField(map);
		double vflow_so2_outWS = vflow_so2_outWS_list.get(0).getValue();
		
	    // vflow_co2_outWS = vflow_co2_inWS
	    // vflow_hcl_outWS = vflow_hcl_inWS
	    // vflow_so2_outWS = vflow_so2_inWS

	    // store to db
	    map.put("fieldnm", "vflow_co2_outWS");
		map.put("value", vflow_co2_outWS);
		pmap.put("vflow_co2_outWS", vflow_co2_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_hcl_outWS");
		map.put("value", vflow_hcl_outWS);
		pmap.put("vflow_hcl_outWS", vflow_hcl_outWS);
		optMapper.updatePipeoutValue(map);

		map.put("fieldnm", "vflow_so2_outWS");
	    map.put("value", vflow_so2_outWS);
		pmap.put("vflow_so2_outWS", vflow_so2_outWS);
		optMapper.updatePipeoutValue(map);
	    
		return pmap;
	}

	@Override
	public HashMap hb_1_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		 // pipe in (func: return value)
	    // const q_gas_inWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'q_gas_inWS');
	    // const vflow_gas_inWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_gas_inWS');
	    
	    map.put("fieldnm", "q_gas_outSCR");
		List<CombusitionPipeOutDTO>q_gas_inWS_list = optMapper.getPipeoutByField(map);
		double q_gas_inWS = q_gas_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_gas_outSCR");
		List<CombusitionPipeOutDTO>vflow_gas_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inWS = vflow_gas_inWS_list.get(0).getValue();
		
	    // pipe add (func: return value)
	    map.put("fieldnm", "t_wtr_inWS");
		List<CombusitionPipeAddDTO> t_wtr_inWS_list = optMapper.getPipeaddByname(map);
		double t_wtr_inWS = t_wtr_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_wtr_inWS");
		List<CombusitionPipeAddDTO> cp_wtr_inWS_list = optMapper.getPipeaddByname(map);
		double cp_wtr_inWS = cp_wtr_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "t_dgngas_outWS");
		List<CombusitionPipeAddDTO> t_dgngas_outWS_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outWS = t_dgngas_outWS_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_dgngas_outWS");
		List<CombusitionPipeAddDTO> cp_dgngas_outWS_list = optMapper.getPipeaddByname(map);
		double cp_dgngas_outWS = cp_dgngas_outWS_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    map.put("fieldnm", "k1_hloss_WS");
		List<CombusitionConsTantDTO> k1_hloss_WS_list =  optMapper.getConstantByField(map);
		double k1_hloss_WS = k1_hloss_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "vpm_w2s");
		List<CombusitionConsTantDTO> vpm_w2s_list =  optMapper.getConstantByField(map);
		double vpm_w2s = vpm_w2s_list.get(0).getValue();
		
	    // t1 = vflow_air_inWS * t_wtr_inWS * cp_wtr_inWS
	    // t2 = q_gas_inWS * k1_hloss_WS
	    // t3 = t_wtr_inWS * k1_hloss_WS
	    // t4 = (vflow_gas_inWS + vflow_o2_outWS + vflow_n2_outWS) * t_dgngas_outWS * cp_dgngas_outWS
	    // t5 = vpm_w2s * t_dgngas_outWS * cp_dgngas_outWS

	    // mflow_wtr_inWS= (q_gas_inWS - (t2 + t4)) / ((t3 + t5 + t_dgngas_outWS) - (t_wtr_inWS + t1))


	    double vflow_air_inWS = (double)pmap.get("vflow_air_inWS" );
	    double vflow_o2_outWS = (double)pmap.get("vflow_o2_outWS" );
	    double vflow_n2_outWS = (double)pmap.get("vflow_n2_outWS" );
	    
	    pmap.put("vflow_air_inWS", vflow_air_inWS);
	    pmap.put("vflow_o2_outWS", vflow_o2_outWS);
	    pmap.put("vflow_n2_outWS", vflow_n2_outWS);
	    
	    // formula
	    double t1 = vflow_air_inWS * t_wtr_inWS * cp_wtr_inWS;
	    double t2 = q_gas_inWS * k1_hloss_WS;
	    double t3 = t_wtr_inWS * k1_hloss_WS;
	    double t4 =
	      (vflow_gas_inWS + vflow_o2_outWS + vflow_n2_outWS) *
	      t_dgngas_outWS *
	      cp_dgngas_outWS;
	    double t5 = vpm_w2s * t_dgngas_outWS * cp_dgngas_outWS;

	    double mflow_wtr_inWS = (q_gas_inWS - (t2 + t4)) / (t3 + t5 + t_dgngas_outWS - (t_wtr_inWS + t1));
	    pmap.put("mflow_wtr_inWS", mflow_wtr_inWS);
		return pmap;
	}

	@Override
	public HashMap mb_1_3_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    map.put("fieldnm", "vflow_h2o_outSCR");
		List<CombusitionPipeOutDTO>vflow_h2o_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_h2o_inWS = vflow_h2o_inWS_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    map.put("fieldnm", "vpm_w2s");
		List<CombusitionConsTantDTO> vpm_w2s_list =  optMapper.getConstantByField(map);
		double vpm_w2s = vpm_w2s_list.get(0).getValue();
		
	    // vflow_h2o_outWS = vflow_h2o_inWS + vpm_w2s * mflow_wtr_inWS
	    double mflow_wtr_inWS = (double)pmap.get("mflow_wtr_inWS");
	    // formula
	   double vflow_h2o_outWS = vflow_h2o_inWS + vpm_w2s * mflow_wtr_inWS;

	    // store to db
		map.put("fieldnm", "vflow_h2o_outWS");
		map.put("value", vflow_h2o_outWS);
		pmap.put("vflow_h2o_outWS", vflow_h2o_outWS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_1_4_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe add (func: return value)\
	    map.put("fieldnm", "t_dgngas_outWS");
		List<CombusitionPipeAddDTO> t_dgngas_outWS_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outWS = t_dgngas_outWS_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    // vflow_gas_outWS= vflow_h2o_outWS + vflow_o2_outWS + vflow_n2_outWS + vflow_co2_outWS + vflow_hcl_outWS
	    // vflowa_gas_outWS= vflow_gas_outWS * (ktemp + t_dgngas_outWS) / ktemp
		double vflow_h2o_outWS = (double)pmap.get("vflow_h2o_outWS");
		double vflow_o2_outWS = (double)pmap.get("vflow_o2_outWS");
		double vflow_n2_outWS = (double)pmap.get("vflow_n2_outWS");
		double vflow_co2_outWS = (double)pmap.get("vflow_co2_outWS");
		double vflow_hcl_outWS = (double)pmap.get("vflow_hcl_outWS");
		
	    // formula
	   double vflow_gas_outWS =
	      vflow_h2o_outWS +
	      vflow_o2_outWS +
	      vflow_n2_outWS +
	      vflow_co2_outWS +
	      vflow_hcl_outWS;
	   double vflowa_gas_outWS = (vflow_gas_outWS * (ktemp + t_dgngas_outWS)) / ktemp;

	    // store to db
		map.put("fieldnm", "vflow_gas_outWS");
		map.put("value", vflow_gas_outWS);
		pmap.put("vflow_gas_outWS", vflow_gas_outWS);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "vflowa_gas_outWS");
		map.put("value", vflowa_gas_outWS);
		pmap.put("vflowa_gas_outWS", vflowa_gas_outWS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap hb_2_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    map.put("fieldnm", "q_gas_outSCR");
		List<CombusitionPipeOutDTO>q_gas_inWS_list = optMapper.getPipeoutByField(map);
		double q_gas_inWS = q_gas_inWS_list.get(0).getValue();
		
	    // pipe add (func: return value)
	    map.put("fieldnm", "t_wtr_inWS");
		List<CombusitionPipeAddDTO> t_wtr_inWS_list = optMapper.getPipeaddByname(map);
		double t_wtr_inWS = t_wtr_inWS_list.get(0).getValue();

		
	    map.put("fieldnm", "cp_wtr_inWS");
		List<CombusitionPipeAddDTO>cp_wtr_inWS_list = optMapper.getPipeaddByname(map);
		double cp_wtr_inWS =cp_wtr_inWS_list.get(0).getValue();

		
	    map.put("fieldnm", "t_air_inWS");
		List<CombusitionPipeAddDTO> t_air_inWS_list = optMapper.getPipeaddByname(map);
		double t_air_inWS = t_air_inWS_list.get(0).getValue();

		
	    map.put("fieldnm", "cp_air_inWS");
		List<CombusitionPipeAddDTO> cp_air_inWS_list = optMapper.getPipeaddByname(map);
		double cp_air_inWS = cp_air_inWS_list.get(0).getValue();

		
	    map.put("fieldnm", "t_dgngas_outWS");
		List<CombusitionPipeAddDTO> t_dgngas_outWS_list = optMapper.getPipeaddByname(map);
		double t_dgngas_outWS = t_dgngas_outWS_list.get(0).getValue();

		
	    map.put("fieldnm", "cp_dgngas_outWS");
		List<CombusitionPipeAddDTO> cp_dgngas_outWS_list = optMapper.getPipeaddByname(map);
		double cp_dgngas_outWS = cp_dgngas_outWS_list.get(0).getValue();

		
	    // constant in facility (func: return value)
	    map.put("fieldnm", "k1_hloss_WS");
		List<CombusitionConsTantDTO> k1_hloss_WS_list =  optMapper.getConstantByField(map);
		double k1_hloss_WS = k1_hloss_WS_list.get(0).getValue();

		
	    // qi_wtr_WS= t_wtr_inWS * mflow_wtr_inWS * cp_wtr_inWS
	    // qi_air_WS= vflow_air_inWS * t_air_inWS * cp_air_inWS
	    // qi_total_WS= q_gas_inWS + qi_wtr_WS + qi_air_WS
	    // qo_hloss_WS= qi_total_WS * k1_hloss_WS
	    // q_gas_outWS = vflow_gas_outWS * t_dgngas_outWS * cp_dgngas_outWS

	    // formula
		double mflow_wtr_inWS = (double)pmap.get("mflow_wtr_inWS");
		double vflow_air_inWS = (double)pmap.get("vflow_air_inWS");
		double vflow_gas_outWS = (double)pmap.get("vflow_gas_outWS");
		
	    double qi_wtr_WS = t_wtr_inWS * mflow_wtr_inWS * cp_wtr_inWS;
	    double qi_air_WS = vflow_air_inWS * t_air_inWS * cp_air_inWS;
	    double qi_total_WS = q_gas_inWS +  qi_wtr_WS +  qi_air_WS;
	    double qo_hloss_WS =  qi_total_WS * k1_hloss_WS;
	    double q_gas_outWS = vflow_gas_outWS * t_dgngas_outWS * cp_dgngas_outWS;

	    // store to db
		map.put("fieldnm", "qi_wtr_WS");
		map.put("value", qi_wtr_WS);
		pmap.put("qi_wtr_WS", qi_wtr_WS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qi_air_WS");
		map.put("value", qi_air_WS);
		pmap.put("qi_air_WS", qi_air_WS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qi_total_WS");
		map.put("value", qi_total_WS);
		pmap.put("qi_total_WS", qi_total_WS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_hloss_WS");
		map.put("value", qo_hloss_WS);
		pmap.put("qo_hloss_WS", qo_hloss_WS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "q_gas_outWS");
		map.put("value", q_gas_outWS);
		pmap.put("q_gas_outWS", q_gas_outWS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_2_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		
		map.put("fieldnm", "vppm_so2_outSCR");
		List<CombusitionPipeOutDTO>vppm_so2_inWS_list = optMapper.getPipeoutByField(map);
		double vppm_so2_inWS = vppm_so2_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_hcl_outSCR");
		List<CombusitionPipeOutDTO>vppm_hcl_inWS_list = optMapper.getPipeoutByField(map);
		double vppm_hcl_inWS = vppm_hcl_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_co_outSCR");
		List<CombusitionPipeOutDTO>vppm_co_inWS_list = optMapper.getPipeoutByField(map);
		double vppm_co_inWS = vppm_co_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_no2_outSCR");
		List<CombusitionPipeOutDTO>vppm_no2_inWS_list = optMapper.getPipeoutByField(map);
		double vppm_no2_inWS = vppm_no2_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_gas_outSCR");
		List<CombusitionPipeOutDTO>vflow_gas_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inWS = vflow_gas_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "mpv_dioxin_outSCR");
		List<CombusitionPipeOutDTO>mpv_dioxin_inWS_list = optMapper.getPipeoutByField(map);
		double mpv_dioxin_inWS = mpv_dioxin_inWS_list.get(0).getValue();
		
		map.put("fieldnm", "mpv_dust_outSCR");
		List<CombusitionPipeOutDTO>mpv_dust_inWS_list = optMapper.getPipeoutByField(map);
		double mpv_dust_inWS = mpv_dust_inWS_list.get(0).getValue();
		
		// constant in facility (func: return value)
	    map.put("fieldnm", "k3_elso2_WS");
		List<CombusitionConsTantDTO> k3_elso2_WS_list =  optMapper.getConstantByField(map);
		double k3_elso2_WS = k3_elso2_WS_list.get(0).getValue();

	    map.put("fieldnm", "k4_elhcl_WS");
		List<CombusitionConsTantDTO> k4_elhcl_WS_list =  optMapper.getConstantByField(map);
		double k4_elhcl_WS = k4_elhcl_WS_list.get(0).getValue();

	    // vppm_so2_outWS = vppm_so2_inWS * (1.0 –k3_elso2_WS) * vflow_gas_inWS / vflow_gas_outWS
	    // vppm_hcl_outWS = vppm_hcl_inWS * (1.0 –k4_elhcl_WS) * vflow_gas_inWS / vflow_gas_outWS
	    // vppm_co_outWS = vppm_co_inWS * vflow_gas_inWS / vflow_gas_outWS
	    // vppm_no2_outWS = vppm_no2_inWS * vflow_gas_inWS / vflow_gas_outWS
	    // mpv_dioxin_outWS = mpv_dioxin_inWS
	    // mpv_dust_outWS = mpv_dust_inWS
		double vflow_gas_outWS = (double)pmap.get("vflow_gas_outWS");
	    double vppm_so2_outWS =
	      (vppm_so2_inWS * (1.0 - k3_elso2_WS) * vflow_gas_inWS) / vflow_gas_outWS;
	    double vppm_hcl_outWS =
	      (vppm_hcl_inWS * (1.0 - k4_elhcl_WS) * vflow_gas_inWS) / vflow_gas_outWS;
	    double vppm_co_outWS = (vppm_co_inWS * vflow_gas_inWS) / vflow_gas_outWS;
	    double vppm_no2_outWS = (vppm_no2_inWS * vflow_gas_inWS) / vflow_gas_outWS;
	    double mpv_dioxin_outWS = mpv_dioxin_inWS;
	    double mpv_dust_outWS = mpv_dust_inWS;

	    // store to db
		map.put("fieldnm", "vppm_so2_outWS");
		map.put("value", vppm_so2_outWS);
		pmap.put("vppm_so2_outWS", vppm_so2_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_hcl_outWS");
		map.put("value", vppm_hcl_outWS);
		pmap.put("vppm_hcl_outWS", vppm_hcl_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_co_outWS");
		map.put("value", vppm_co_outWS);
		pmap.put("vppm_co_outWS", vppm_co_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_no2_outWS");
		map.put("value", vppm_no2_outWS);
		pmap.put("vppm_no2_outWS", vppm_no2_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mpv_dioxin_outWS");
		map.put("value", mpv_dioxin_outWS);
		pmap.put("mpv_dioxin_outWS", mpv_dioxin_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mpv_dust_outWS");
		map.put("value", mpv_dust_outWS);
		pmap.put("mpv_dust_outWS", mpv_dust_outWS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_3_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		
		// pipe in (func: return value)
	    map.put("fieldnm", "vppm_so2_outSCR");
		List<CombusitionPipeOutDTO>vppm_so2_inWS_list = optMapper.getPipeoutByField(map);
		double vppm_so2_inWS = vppm_so2_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vppm_hcl_outSCR");
		List<CombusitionPipeOutDTO>vppm_hcl_inWS_list = optMapper.getPipeoutByField(map);
		double vppm_hcl_inWS = vppm_hcl_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_gas_outSCR");
		List<CombusitionPipeOutDTO>vflow_gas_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inWS = vflow_gas_inWS_list.get(0).getValue();
		
	    // pipe add (func: return value)
	    map.put("fieldnm", "cct_naoh_inWS");
		List<CombusitionPipeAddDTO> cct_naoh_inWS_list = optMapper.getPipeaddByname(map);
		double cct_naoh_inWS = cct_naoh_inWS_list.get(0).getValue();

		
	    // constant in global (func: return value)
	    map.put("fieldnm", "molm_so2");
		List<CombusitionConsTantDTO> molm_so2_list =  optMapper.getConstantByField(map);
		double molm_so2 =molm_so2_list.get(0).getValue();


	    map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();

		map.put("fieldnm", "unit_mega");
		List<CombusitionConsTantDTO> unit_mega_list =  optMapper.getConstantByField(map);
		double unit_mega = unit_mega_list.get(0).getValue();

		map.put("fieldnm", "molm_hcl");
		List<CombusitionConsTantDTO> molm_hcl_list =  optMapper.getConstantByField(map);
		double molm_hcl = molm_hcl_list.get(0).getValue();

		map.put("fieldnm", "molm_naoh");
		List<CombusitionConsTantDTO> molm_naoh_list =  optMapper.getConstantByField(map);
		double molm_naoh = molm_naoh_list.get(0).getValue();

		// constant in facility (func: return value)
		map.put("fieldnm", "k2_so2nnaoh_WS");
		List<CombusitionConsTantDTO> k2_so2nnaoh_WS_list =  optMapper.getConstantByField(map);
		double k2_so2nnaoh_WS = k2_so2nnaoh_WS_list.get(0).getValue();

	    // mflow_so2_inWS= vppm_so2_inWS * molm_so2 / molv_igas * vflow_gas_inWS / unit_mega
	    // mflow1_naoh_inWS= (k2_so2nnaoh_WS * molm_naoh) * mflow_so2_inWS / molm_so2
	    // mflow_hcl_inWS= vppm_hcl_inWS * molm_hcl / molv_igas * vflow_gas_inWS / unit_mega
	    // mflow2_naoh_inWS= molm_naoh * mflow_hcl_inWS / molm_hcl

	    // mflow_totalnaoh_inWS= mflow1_naoh_inWS + mflow2_naoh_inWS
	    // mflow_cctnaoh_inWS= mflow_totalnaoh_inWS / cct_naoh_inWS

	    // formula
	    double mflow_so2_inWS = (((vppm_so2_inWS * molm_so2) / molv_igas) * vflow_gas_inWS) / unit_mega;
	    double mflow1_naoh_inWS = (k2_so2nnaoh_WS * molm_naoh * mflow_so2_inWS) / molm_so2;
	    double mflow_hcl_inWS = (((vppm_hcl_inWS * molm_hcl) / molv_igas) * vflow_gas_inWS) / unit_mega;
	    double mflow2_naoh_inWS = (molm_naoh * mflow_hcl_inWS) / molm_hcl;
	    double mflow_totalnaoh_inWS = mflow1_naoh_inWS + mflow2_naoh_inWS;
	    double mflow_cctnaoh_inWS = mflow_totalnaoh_inWS / cct_naoh_inWS;

	    // store to db
		map.put("fieldnm", "mflow_totalnaoh_inWS");
		map.put("value", mflow_totalnaoh_inWS);
		pmap.put("mflow_totalnaoh_inWS", mflow_totalnaoh_inWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mflow_cctnaoh_inWS");
		map.put("value", mflow_cctnaoh_inWS);
		pmap.put("mflow_cctnaoh_inWS", mflow_cctnaoh_inWS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap etc_ws(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe add (func: return desval)
	    map.put("fieldnm", "t_dgngas_outWS");
		List<CombusitionPipeAddDTO> t_gas_outWS_list = optMapper.getPipeaddByname(map);
		double t_gas_outWS = t_gas_outWS_list.get(0).getValue();
		
	    map.put("fieldnm", "cp_dgngas_outWS");
		List<CombusitionPipeAddDTO> cp_gas_outWS_list = optMapper.getPipeaddByname(map);
		double cp_gas_outWS = cp_gas_outWS_list.get(0).getValue();
		
	    // t_gas_outWS = t_dgngas_outWS
	    // cp_gas_outWS = cp_dgngas_outWS

	    // formula
	    t_gas_outWS = t_gas_outWS;
	    cp_gas_outWS = cp_gas_outWS;

	    // store to db
		map.put("fieldnm", "t_gas_outWS");
		map.put("value", t_gas_outWS);
		pmap.put("t_gas_outWS", t_gas_outWS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "cp_gas_outWS");
		map.put("value", cp_gas_outWS);
		pmap.put("cp_gas_outWS", cp_gas_outWS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap ws_design1(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe in (func: return value)
	    // const t_gas_inWS = helper.plm.PIPEIN_NM_DB(data.wpid, 't_gas_inWS');
	    // const vflow_gas_inWS = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_gas_inWS');
	    
	    map.put("fieldnm", "t_gas_outSCR");
		List<CombusitionPipeOutDTO>t_gas_inWS_list = optMapper.getPipeoutByField(map);
		double t_gas_inWS = t_gas_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_gas_outSCR");
		List<CombusitionPipeOutDTO>vflow_gas_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inWS = vflow_gas_inWS_list.get(0).getValue();
		
	    // constant in global (func: return value)
		map.put("fieldnm", "min2sec");
		List<CombusitionConsTantDTO> min2sec_list =  optMapper.getConstantByField(map);
		double min2sec = min2sec_list.get(0).getValue();
		
	    map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    map.put("fieldnm", "min2hr");
		List<CombusitionConsTantDTO> min2hr_list =  optMapper.getConstantByField(map);
		double min2hr = min2hr_list.get(0).getValue();
		
	    map.put("fieldnm", "k5_dimmargin_WS");
		List<CombusitionConsTantDTO> k5_dimmargin_WS_list =  optMapper.getConstantByField(map);
		double k5_dimmargin_WS = k5_dimmargin_WS_list.get(0).getValue();
		
	    // pipe add (func: return desval)
		map.put("fieldnm", "mps_gasvel_WS");
		List<CombusitionPipeAddDTO> mps_gasvel_WS_list = optMapper.getPipeaddByname(map);
		double mps_gasvel_WS = mps_gasvel_WS_list.get(0).getValue();
		
	    // formula
	    // m2_area_WS= vflow_gas_inWS * (ktemp + t_gas_inWS) / ktemp / (min2hr * min2sec) / mps_gasvel_WS
	    // m_dim_WS= (m2_area_WS * 4 / 3.14 )^(0.5) * (100 + k5_dimmargin_WS) / 100
	    double m2_area_WS =
	      (vflow_gas_inWS * (ktemp + t_gas_inWS)) / ktemp / (min2hr * min2sec) / mps_gasvel_WS;
	    double m_dim_WS = Double.parseDouble(String.valueOf(Integer.parseInt(String.valueOf((m2_area_WS * 4) / 3.14))  ^  Integer.parseInt(String.valueOf(((0.5 * (100 + k5_dimmargin_WS)) / 100)))) ) ;

	    // store to db
	    map.put("fieldnm", "m2_area_WS");
		map.put("value", m2_area_WS);
		pmap.put("m2_area_WS", m2_area_WS);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "m_dim_WS");
		map.put("value", m_dim_WS);
		pmap.put("m_dim_WS", m_dim_WS);
		optMapper.updatePipeoutValue(map);
		
	    
		return pmap;
	}

	@Override
	public HashMap ws_design2(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		// pipe add (func: return desval)
	    map.put("fieldnm", "mm_perheight1_WS");
		List<CombusitionPipeAddDTO> mm_perheight1_WS_list = optMapper.getPipeaddByname(map);
		double mm_perheight1_WS = mm_perheight1_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_cntheight1_WS");
		List<CombusitionPipeAddDTO> ea_cntheight1_WS_list = optMapper.getPipeaddByname(map);
		double ea_cntheight1_WS = ea_cntheight1_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_perheight2_WS");
		List<CombusitionPipeAddDTO> mm_perheight2_WS_list = optMapper.getPipeaddByname(map);
		double mm_perheight2_WS = mm_perheight2_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_cntheight2_WS");
		List<CombusitionPipeAddDTO> ea_cntheight2_WS_list = optMapper.getPipeaddByname(map);
		double ea_cntheight2_WS = ea_cntheight2_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_height3_WS");
		List<CombusitionPipeAddDTO> mm_height3_WS_list = optMapper.getPipeaddByname(map);
		double mm_height3_WS = mm_height3_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_height4_WS");
		List<CombusitionPipeAddDTO> mm_height4_WS_list = optMapper.getPipeaddByname(map);
		double mm_height4_WS = mm_height4_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_height5_WS");
		List<CombusitionPipeAddDTO> mm_height5_WS_list = optMapper.getPipeaddByname(map);
		double mm_height5_WS = mm_height5_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_height6_WS");
		List<CombusitionPipeAddDTO> mm_height6_WS_list = optMapper.getPipeaddByname(map);
		double mm_height6_WS = mm_height6_WS_list.get(0).getValue();
		
		
	    // formula
	    // mm_height1_WS = mm_perheight1_WS * ea_cntheight1_WS
	    // mm_height2_WS = mm_perheight2_WS * ea_cntheight2_WS
	    // mm_height_WS= mm_height1_WS + mm_height2_WS + mm_height3_WS + mm_height4_WS + mm_height5_WS + mm_height6_WS
	    double mm_height1_WS =  mm_perheight1_WS *  ea_cntheight1_WS;
	    double mm_height2_WS =  mm_perheight2_WS *  ea_cntheight2_WS;
	    double mm_height_WS =
	       mm_height1_WS +
	       mm_height2_WS +
	       mm_height3_WS +
	       mm_height4_WS +
	       mm_height5_WS +
	       mm_height6_WS;

	    // store to db
	    
	    map.put("fieldnm", "mm_height_WS");
		map.put("value", mm_height_WS);
		pmap.put("mm_height_WS", mm_height_WS);
		optMapper.updatePipeoutValue(map);
		
		
		return pmap;
	}

	@Override
	public HashMap ws_design3(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		
		 // pipe in (func: return value)
	    map.put("fieldnm", "t_gas_outSCR");
		List<CombusitionPipeOutDTO>t_gas_inWS_list = optMapper.getPipeoutByField(map);
		double t_gas_inWS = t_gas_inWS_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_gas_outSCR");
		List<CombusitionPipeOutDTO>vflow_gas_inWS_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inWS = vflow_gas_inWS_list.get(0).getValue();
		
	    // constant in global (func: return value)
		map.put("fieldnm", "k6_spray1margin_WS");
		List<CombusitionConsTantDTO> k6_spray1margin_WS_list =  optMapper.getConstantByField(map);
		double k6_spray1margin_WS = k6_spray1margin_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    map.put("fieldnm", "k7_spray2margin_WS");
		List<CombusitionConsTantDTO> k7_spray2margin_WS_list =  optMapper.getConstantByField(map);
		double k7_spray2margin_WS = k7_spray2margin_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "k8_liqngas1_WS");
		List<CombusitionConsTantDTO> k8_liqngas1_WS_list =  optMapper.getConstantByField(map);
		double k8_liqngas1_WS =k8_liqngas1_WS_list.get(0).getValue();
		
	    map.put("fieldnm", "k9_liqngas2_WS");
		List<CombusitionConsTantDTO> k9_liqngas2_WS_list =  optMapper.getConstantByField(map);
		double k9_liqngas2_WS = k9_liqngas2_WS_list.get(0).getValue();
		
	    // formula
	    // lphr_spray1_WS= vflow_gas_inWS * (ktemp + t_gas_inWS) / ktemp * ((100 + k6_spray1margin_WS) / 100) * k8_liqngas1_WS
	    // vflow_gas2_inWS= vflow_gas_inWS + (lphr_spray1_WS / 1000)
	    // lphr_spray2_WS= vflow_gas2_inWS * (ktemp + t_gas_inWS) / ktemp * ((100 + k7_spray2margin_WS) / 100) * k9_liqngas2_WS
	    // lphr_totalspray_WS= lphr_spray1_WS + lphr_spray2_WS
	    double lphr_spray1_WS =
	      ((vflow_gas_inWS * (ktemp + t_gas_inWS)) / ktemp) * ((100 + k6_spray1margin_WS) / 100) * k8_liqngas1_WS;
	    double vflow_gas2_inWS = vflow_gas_inWS +  lphr_spray1_WS / 1000;
	    double lphr_spray2_WS =
	      (( vflow_gas2_inWS * (ktemp + t_gas_inWS)) / ktemp) *
	      ((100 + k7_spray2margin_WS) / 100) *
	      k9_liqngas2_WS;
	    double lphr_totalspray_WS =  lphr_spray1_WS +  lphr_spray2_WS;

	    // store to db
	    map.put("fieldnm", "lphr_totalspray_WS");
		map.put("value", lphr_totalspray_WS);
		pmap.put("lphr_totalspray_WS", lphr_totalspray_WS);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}


}
