package com.kii.potal.admin.author.service.impl;

import com.kii.potal.admin.author.dto.AuthorDTO;
import com.kii.potal.admin.author.service.AuthorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthorServiceImpl extends EgovAbstractServiceImpl implements AuthorService {

    @Autowired
    AuthorMapper authorMapper;

    @Override
    public List<AuthorDTO> getAuthortList(AuthorDTO authorDTO) throws Exception {
        return authorMapper.getAuthortList(authorDTO);
    }

    @Override
    public AuthorDTO getAuthorItem(AuthorDTO authorDTO) throws Exception {
        return null;
    }

    @Override
    public void insertAuthorItem(AuthorDTO authorDTO) throws Exception {

    }

    @Override
    public void updateAuthorItem(AuthorDTO authorDTO) throws Exception {

    }

    @Override
    public void deleteAuthorItem(AuthorDTO authorDTO) throws Exception {

    }

}
