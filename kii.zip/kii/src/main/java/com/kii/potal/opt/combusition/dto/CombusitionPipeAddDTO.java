package com.kii.potal.opt.combusition.dto;



import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class CombusitionPipeAddDTO {
    private Long idx ;
    private Long wpid ;
    private Long groupcd ; 
    private Long code ;
    private String name ;
    private String fieldnm ; 
    private String statecd ;
    private double value ;
    private String unit ;
    private String color ; 
    private String createddate ; 
    private String updateddate ;
    private Float actval ;


    @Builder
    public CombusitionPipeAddDTO(Long idx, Long wpid, Long groupcd, Long code) {
        this.idx = idx;
        this.wpid = wpid;
        this.groupcd = groupcd;
        this.code = code;
    }
}
