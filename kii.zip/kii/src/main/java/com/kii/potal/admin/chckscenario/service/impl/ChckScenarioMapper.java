package com.kii.potal.admin.chckscenario.service.impl;

import com.kii.potal.admin.chckscenario.dto.ChckScenarioDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface ChckScenarioMapper {
    //점검 시나리오 리스트 조회
    List<ChckScenarioDTO> getChckSenarioList(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 태그 리스트 조회
    List<ChckScenarioDTO> getChckSenarioTagList(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 정보 등록
    void insertChckSenarioItem(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 태그 정보 등록
    void insertChckSenarioTagItem(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 정보 수정
    void updateChckSenarioItem(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 태그 정보 수정
    void updateChckSenarioTagItem(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 정보 삭제
    void deleteChckSenarioItem(ChckScenarioDTO chckScenarioDTO) throws Exception;

    //점검 시나리오 태그 정보 삭제
    void deleteChckSenarioTagItem(ChckScenarioDTO chckScenarioDTO) throws Exception;
}
