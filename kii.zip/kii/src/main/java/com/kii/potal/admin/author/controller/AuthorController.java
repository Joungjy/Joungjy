package com.kii.potal.admin.author.controller;


import com.kii.potal.admin.author.dto.AuthorDTO;
import com.kii.potal.admin.author.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class AuthorController {

    @Autowired
    AuthorService authorService;

    /**
     * 권한 관리 리스트 정보 조회
     *
     * @param model
     * @param request
     * @param response
     * @return 권한 관리 리스트 정보 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/authorList.do", method = RequestMethod.GET)
    public String getAuthorList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        AuthorDTO authorDTO =new AuthorDTO();
        authorService.getAuthortList(authorDTO);
        return "admin/author/author_list";

    }

    /**
     * 권한 관리 정보 등록     *
     * @param model
     * @param request
     * @param response
     * @return 권한 관리 정보 등록 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/authorInsert.do", method = RequestMethod.GET)
    public String insertAuthorItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "admin/author/author_insert";

    }

    /**
     * 권한 관리 정보 등록 프로세스    *
     * @param model
     * @param request
     * @param response
     * @return 권한 관리 정보 등록 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/authorInsertProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String insertAuthorItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }



    /**
     * 권한 관리 정보 수정     *
     * @param model
     * @param request
     * @param response
     * @return 권한 관리 정보 수정 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/authorUpdate.do", method = RequestMethod.GET)
    public String updateAuthorItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "admin/author/author_update";

    }


    /**
     * 권한 관리 정보 수정 프로세스    *
     * @param model
     * @param request
     * @param response
     * @return 권한 관리 정보 수정 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/authorUpdateProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String updateAuthorItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        return "json";

    }



}
