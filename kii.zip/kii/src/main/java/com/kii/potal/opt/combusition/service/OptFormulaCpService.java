package com.kii.potal.opt.combusition.service;

import java.util.HashMap;
import java.util.List;

import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;

public interface OptFormulaCpService {
	
	List<CombusitionCpDTO> calc_mix_gas(List<CombusitionCpDTO> list)throws Exception;
	List<CombusitionCpDTO> calc_slope(List<CombusitionCpDTO> list)throws Exception;
	void insert_to_queue(List<CombusitionCpDTO> list);

}
