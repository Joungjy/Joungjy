package com.kii.potal.core.jwt;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import com.kii.potal.admin.user.dto.UserDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JwtUtil {

    @Value("${jwt.secretKey}")
    private String SECRET_KEY;

    @Value("${jwt.expmin}")
    private Long EXPIRE_MIN;

    public String createAuthToken(UserDTO userVo) {
        return create(userVo, "authToken", EXPIRE_MIN);
    }

    /**
     * 로그인 성공 시 사용자 정보를 기반으로 JWTToken을 생성해서 반환한다.
     * JWT Token = Header + Payload + Signature
     * @param UserDTO
     * @param subject
     * @param expireMin
     * @return
     */
    private String create(UserDTO userVo, String subject, long expireMin) {
        final JwtBuilder builder = Jwts.builder();

        // Header 설정
        builder.setHeaderParam("typ", "JWT"); // 토큰의 타입으로 고정 값
        // Payload 설정 - claim 정보 포함
        builder.setSubject(subject).setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * expireMin)); // 유효기간 설정

        // 담고 싶은 정보 설정
        if (userVo != null) {
            Map<String, Object> map = new HashMap<>();
            map.put("userId", userVo.getUsrId());
            map.put("userNo", userVo.getUsrNo());
            map.put("fcltyCd", userVo.getFcltyCd());
            map.put("athrCd", userVo.getAthrCd());
            try {
                map.put("userNm", URLEncoder.encode(userVo.getUsrNm(), "utf-8"));
            } catch(UnsupportedEncodingException e) {
                map.put("userNm", userVo.getUsrNm());
            }
            map.put("athrList", userVo.getAthrList());
            builder.setClaims(map);
        }

        // signature - secret key 를 이용한 암호화
        builder.signWith(SignatureAlgorithm.HS256, DatatypeConverter.parseBase64Binary(SECRET_KEY));

        // 마지막 직렬화 처리
        final String jwt = builder.compact();
        log.info("jwt token : {}", jwt);
        return jwt;
    }

    /**
     * jwt 토큰을 분석해서 필요한 정보를 반환한다.
     * 토큰에 문제가 있다면 Runtime 예외를 발생시킨다.
     * @param jwt
     * @return
     */
    public Map<String, Object> checkAndGetClaims(String jwt) {

        Jws<Claims> claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(SECRET_KEY)).parseClaimsJws(jwt);
        log.info("claims: {}", claims);
        // Claims는 Map의 구현체
        return claims.getBody();
    }

    /**
     * 토큰 해독
     * @param token
     * @return
     */
    public String getSubject(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(DatatypeConverter.parseBase64Binary(SECRET_KEY))
                .parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

    /**
     * 유효한 토큰인지 확인
     * @param jwt
     * @return
     */
    public boolean isUsable(String jwt) {
        try {
           // Claims claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(SECRET_KEY))
           //         .parseClaimsJws(jwt).getBody();
            return true;
        } catch (Exception e) {
            throw new RuntimeException("인증 정보 오류가 발생했습니다.");
        }
    }

    /**
     * Refresh token 생성
     * @return
     */
    public String createRefreshToken() {
        return create(null, "refreshToken", EXPIRE_MIN * 5);
    }

    /**
     * Request의 Header에서 token 값을 가져온다.
     * x-auth-token: 'token값'
     * @param request
     * @return
     */
    public String resolveToken(HttpServletRequest request) {
        return request.getHeader("x-auth-token");
    }

    /**
     * 토큰의 유효성 + 만료일자 확인
     * @param jwt
     * @return
     */
    public boolean validateToken(String jwt) {
        try {
            Jws<Claims> claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(SECRET_KEY)).parseClaimsJws(jwt);
            log.info("expiration : {}", claims.getBody().getExpiration());
            return !claims.getBody().getExpiration().before(new Date());
        } catch (ExpiredJwtException e) {
            // e.printStackTrace();
            return false;
        } catch (Exception e) {
            // e.printStackTrace();
            return false;
        }
    }
}
