package com.kii.potal;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
* Spring boot Application
*
* @packageName  : com.kii.potal
* @fileName     : KiiPotalApplication.java
* @author       : kisub
* @since        : 2023.09.20
* @version      : 1.0
*
*
* ===========================================================
* 수정일               수정자           수정내용
* -----------------------------------------------------------
* 2023.09.20        kisub           최초 생성
*/

@EnableAutoConfiguration(exclude = { WebMvcAutoConfiguration.class })
@SpringBootApplication(scanBasePackages = { "com.kii.potal" })
@MapperScan(basePackages = { "com.kii.potal.**.impl" })
public class KiiPotalApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication springApplication = new SpringApplication(KiiPotalApplication.class);
        springApplication.setBannerMode(Banner.Mode.OFF);
        springApplication.setLogStartupInfo(true);
        springApplication.run(args);
    }

    @PostConstruct
    void started() {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Seoul"));
    }

    /**
     * SpringBootServletInitializer를 상속받아 configure()를 재정의
     * WAS에 war 파일을 배포할 때 Spring Boot 의 내용을 Servlet으로 초기화 해주는 파일
     * @param builder a builder for the application context
     * @return SpringApplicationBuilder
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(KiiPotalApplication.class);
    }
}
