package com.kii.potal.opt.combusition.service;

import java.util.HashMap;

public interface OptFormulaSdrService {
	HashMap module_sdr(HashMap map)throws Exception;
}
