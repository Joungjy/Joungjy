package com.kii.potal.admin.systemhist.service;

import com.kii.potal.admin.systemhist.dto.SystemHistDTO;

import java.util.List;

public interface SystemHistService {

    
    //시스템 이력 리스트 조회
    List<SystemHistDTO> getSysHistList(SystemHistDTO systemHistDTO)throws Exception;
    //시스템 이력 정보 등록
    void insertSysHistItem(SystemHistDTO systemHistDTO)throws Exception;


}
