package com.kii.potal.core.util;

import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

public class DateUtil {
    public static Date addMonths(Date date, int amount){
        return DateUtils.addMonths(date, amount);
    }

    public static Date addDays(Date date, int amount){
        return DateUtils.addDays(date, amount);
    }

    public static Date addHours(Date date, int amount){
        return DateUtils.addHours(date, amount);
    }

    public static Date addYears(Date date, int amount){
        return DateUtils.addYears(date, amount);
    }
}
