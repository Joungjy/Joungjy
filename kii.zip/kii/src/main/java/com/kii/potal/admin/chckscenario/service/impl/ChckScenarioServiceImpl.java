package com.kii.potal.admin.chckscenario.service.impl;

import com.kii.potal.admin.chckscenario.dto.ChckScenarioDTO;
import com.kii.potal.admin.chckscenario.service.ChckScenarioService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ChckScenarioServiceImpl extends EgovAbstractServiceImpl implements ChckScenarioService {

    @Autowired
    ChckScenarioMapper chckScenarioMapper;

    @Override
    public List<ChckScenarioDTO> getChckSenarioList(ChckScenarioDTO chckScenarioDTO) throws Exception {
        return null;
    }

    @Override
    public List<ChckScenarioDTO> getChckSenarioTagList(ChckScenarioDTO chckScenarioDTO) throws Exception {
        return null;
    }

    @Override
    public void insertChckSenarioItem(ChckScenarioDTO chckScenarioDTO) throws Exception {

    }

    @Override
    public void insertChckSenarioTagItem(ChckScenarioDTO chckScenarioDTO) throws Exception {

    }

    @Override
    public void updateChckSenarioItem(ChckScenarioDTO chckScenarioDTO) throws Exception {

    }

    @Override
    public void updateChckSenarioTagItem(ChckScenarioDTO chckScenarioDTO) throws Exception {

    }

    @Override
    public void deleteChckSenarioItem(ChckScenarioDTO chckScenarioDTO) throws Exception {

    }

    @Override
    public void deleteChckSenarioTagItem(ChckScenarioDTO chckScenarioDTO) throws Exception {

    }
}
