package com.kii.potal.core.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

public class MapUtil {
    public static boolean isValueEmpty(Map map, String key){

        if(MapUtils.getObject(map, key) == null || DataStringUtil.isEmpty(MapUtils.getString(map, key))){
            return true;
        }

        return false;
    }

    public static boolean isValueNotEmpty(Map map, String key){
        return !isValueEmpty(map, key);
    }

    public static boolean isArrayEmpty(Map map, String key){
        Object[] arr = map == null ? null : (Object[]) map.get(key);

        return ArrayUtils.isEmpty(arr);
    }

    public static boolean isEmpty(Map map){
        return MapUtils.isEmpty(map);
    }

    public static boolean isNotEmpty(Map map){
        return MapUtils.isNotEmpty(map);
    }

    public static String getString(Map map, String key){
        return MapUtils.getString(map, key);
    }

    public static String getDefaultString(Map map, String key){
        return DataStringUtil.defaultString(getString(map, key));
    }

    public static String getDefaultString(Map map, String key, String defaultStr){
        return DataStringUtil.defaultString(getString(map, key), defaultStr);
    }

    public static Integer getInteger(Map map, String key){
        return MapUtils.getInteger(map, key);
    }

    public static int getIntValue(Map map, String key){
        return MapUtils.getIntValue(map, key);
    }

    public static int getIntValue(Map map, String key, int defaultValue){
        return MapUtils.getIntValue(map, key, defaultValue);
    }

    public static double getDoubleValue(Map map, String key){
        return MapUtils.getDoubleValue(map, key);
    }

    public static Integer getInteger(Map map, String key, Integer defaultValue){
        return MapUtils.getInteger(map, key, defaultValue);
    }


    public static Boolean getBoolean(Map map, String key, Boolean defaultValue){
        return MapUtils.getBoolean(map, key, defaultValue);
    }

    public static <K, V> Map<K, V> copyMap(Map<K, V> source){
        Map<K, V> copyMap = new HashMap<K, V>();

        copyMap.putAll(source);

        return copyMap;
    }

    public static <K, V> void copyMap(Map<K, V> source, Map<K, V> destination){
        destination.clear();

        destination.putAll(source);
    }

}
