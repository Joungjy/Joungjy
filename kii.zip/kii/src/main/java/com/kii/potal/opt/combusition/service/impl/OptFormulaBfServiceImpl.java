package com.kii.potal.opt.combusition.service.impl;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaBfService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaBfServiceImpl extends EgovAbstractServiceImpl implements OptFormulaBfService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap mb_1_1_bf(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		// pipe in (func: return value)
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
	    map.put("fieldnm", "vflow_gas_outSDR");
		List<CombusitionPipeOutDTO>vflow_gas_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inBF = vflow_gas_outSDR_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_h2o_outSDR");
		List<CombusitionPipeOutDTO>vflow_h2o_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_h2o_inBF = vflow_h2o_outSDR_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_o2_outSDR");
		List<CombusitionPipeOutDTO>vflow_o2_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_o2_inBF = vflow_o2_outSDR_list.get(0).getValue();
		
	    // pipe add (func: return desval)
	    // 분말 활성탄 단위공급량(농도, 체적유량당 질량)
	    
	    map.put("fieldnm", "mpv_ac_inBF");
		List<CombusitionPipeOutDTO>mpv_ac_inBF_list = optMapper.getPipeoutByField(map);
		double mpv_ac_inBF = mpv_ac_inBF_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    
		map.put("fieldnm", "unit_mega");
		List<CombusitionConsTantDTO> unit_mega_list =  optMapper.getConstantByField(map);
		double unit_mega = unit_mega_list.get(0).getValue();
		
	    // formula
	    // formula 0
	    double vflow_drygas_inBF = vflow_gas_inBF - vflow_h2o_inBF;
	    double vpercent_o2_inBF = (vflow_o2_inBF / vflow_drygas_inBF) * 100;
	    double vflow_drygas_o2cal_inBF = ((21 - vpercent_o2_inBF) / (21 - 12)) * vflow_drygas_inBF;
	    // 분말 활성탄 공급량 (kg/hr)
	    double mflow_ac_inBF = (vflow_drygas_inBF * mpv_ac_inBF) / unit_mega;
	    // 분말 소석회 단위 공급량(mg/Nm3)
	    double mpv_cao2h2_inBF = 150;
	    // 분말 소석회 공급량 (kg/hr, 불필요할 경우 zero))
	    double mflow_cao2h_inBF = (vflow_drygas_inBF * mpv_cao2h2_inBF) / unit_mega;
	    vflow_drygas_inBF = vflow_drygas_inBF;
	    vpercent_o2_inBF = vpercent_o2_inBF;

	    pmap.put("vflow_drygas_inBF", vflow_drygas_inBF);
	    pmap.put("vpercent_o2_inBF", vpercent_o2_inBF);
	    
	    // store to db
	    
	    map.put("fieldnm", "mflow_ac_inBF");
		map.put("value", mflow_ac_inBF);
		pmap.put("mflow_ac_inBF", mflow_ac_inBF);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_2_1_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		// pipe in (func: return value)
	    // const vflow_o2_inBF = helper.plm.PIPEIN_NM_DB(data.wpid, 'vflow_o2_inBF');
	    
		map.put("fieldnm", "vflow_gas_outSDR");
		List<CombusitionPipeOutDTO>vflow_gas_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inBF = vflow_gas_outSDR_list.get(0).getValue();
		
	    
		map.put("fieldnm", "vflow_h2o_outSDR");
		List<CombusitionPipeOutDTO>vflow_h2o_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_h2o_inBF = vflow_h2o_outSDR_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "vflow_n2_outSDR");
		List<CombusitionPipeOutDTO>vflow_n2_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_n2_inBF = vflow_n2_outSDR_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "vflow_o2_outSDR");
		List<CombusitionPipeOutDTO> vflow_o2_outSDR_list = optMapper.getPipeoutByField(map);
		double vflow_o2_inBF = vflow_o2_outSDR_list.get(0).getValue();
		
	    
	    map.put("fieldnm", "t_gas_outSDR");
		List<CombusitionPipeOutDTO> t_gas_outSDR_list = optMapper.getPipeoutByField(map);
		double t_gas_inBF = t_gas_outSDR_list.get(0).getValue();
		pmap.put("t_gas_inBF", t_gas_inBF);
	    
	    map.put("fieldnm", "mflow_flyash_outSDR");
		List<CombusitionPipeOutDTO>mflow_flyash_outSDR_list = optMapper.getPipeoutByField(map);
		double mflow_flyash_inBF = mflow_flyash_outSDR_list.get(0).getValue();
		pmap.put("mflow_flyash_inBF", mflow_flyash_inBF);
	    // pipe add (func: return value)
	    // 금산군
	    // const vflow_airpea_inBF = helper.plm.PIPEADD_NM_DB(data.wpid, 'vflow_airpea_inBF');
	    // const ea_nozzle_BF = helper.plm.PIPEADD_NM_DB(data.wpid, 'ea_nozzle_BF');
	    // const t_air_inBF = helper.plm.PIPEADD_NM_DB(data.wpid, 't_air_inBF');
	    // constant in global (func: return value)
	    // const min2hr = helper.plm.get_constantin_from_name('min2hr').value;
	    
		map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
	    // 금산군
	    // const rt_o2inair = helper.plm.get_constantin_from_name('rt_o2inair').value;
	    // const rt_n2inair = helper.plm.get_constantin_from_name('rt_n2inair').value;
	    //
	    //
	    // formula
	    // vflow_air_inBF = vflow_airpea_inBF * ea_nozzle_BF * min2hr
	    // vflow_o2_outBF = vflow_o2_inBF + vflow_air_inBF * (ktemp / (ktemp +  t_air_inBF)) * rt_o2inair
	    // vflow_n2_outBF = vflow_n2_inBF + vflow_air_inBF * (ktemp / (ktemp + t_air_inBF)) * rt_n2inair
	    // data.mb_2_1_bf.vflow_air_inBF = vflow_airpea_inBF * ea_nozzle_BF * min2hr;
		double vel_filter_BF = 0.65; // 0.8 m/min
		double pass_filter = 5; // litter/m2
	    // 금산군, 고질 기준으로 기준질*1.1566
		double area_filter_BF = (1.1566 * (vflow_gas_inBF * (ktemp + t_gas_inBF))) / ktemp / 60 / vel_filter_BF;
	    // 탈진용 압축공기량
		double vflow_compair_inBF = ((area_filter_BF * pass_filter) / 1000) * 60;
		pmap.put("vflow_compair_inBF", vflow_compair_inBF);
		double mflow_ac_inBF = (double)pmap.get("mflow_ac_inBF");
		
	    // 백필터 입구 비산재량 + 활성탄
		double mflow_total_flyash_inBF = mflow_flyash_inBF + mflow_ac_inBF;
		double eff_filter_BF = 0.9995; // 백필터 포집율 99%
	    // 백필터에서 포집된 바닥재
		double mflow_btmash_outBF = eff_filter_BF * mflow_total_flyash_inBF;
		pmap.put("mflow_btmash_outBF", mflow_btmash_outBF);
	    // 백필터를 지나가는 비산재
		double mflow_flyash_outBF = mflow_total_flyash_inBF - mflow_btmash_outBF;
	    //
	    mflow_btmash_outBF = mflow_btmash_outBF;
	    mflow_flyash_outBF = mflow_flyash_outBF;
	    double vflow_drygas_inBF = (double)pmap.get("vflow_drygas_inBF");
	    double vpercent_o2_inBF = (double)pmap.get("vpercent_o2_inBF");
	    
	    double mpv_flyash_outBF =
	      (mflow_flyash_outBF / vflow_drygas_inBF) *
	      1000000 *
	      ((21 - 12) / (21 - vpercent_o2_inBF));
	    // 활성탄 및 소석회 공급용 공기량
	    double vflow_acncao2h2_air_inBF = 75; // Nm3/helper
	    //
	    // humidity calibration (absolute/relative)
	    double  ah_kg = 0.01469;
	    double  ah_nm3 = (ah_kg * (0.21 * 32 + 0.79 * 28)) / 18;
	    // 금산군의 경우, 습윤가스 아님
	    double  vflow_h2o_outBF =
	      vflow_h2o_inBF + 0 * ah_nm3 * (vflow_compair_inBF + vflow_acncao2h2_air_inBF);
	    double  vflow_o2_outBF =
	      vflow_o2_inBF + 0.2095 * (vflow_compair_inBF + vflow_acncao2h2_air_inBF);
	    double  vflow_n2_outBF =
	      vflow_n2_inBF + 0.7905 * (vflow_compair_inBF + vflow_acncao2h2_air_inBF);

	    vflow_h2o_outBF = vflow_h2o_outBF;
	    vflow_o2_outBF = vflow_o2_outBF;
	    vflow_n2_outBF = vflow_n2_outBF;

	    // store to db
	    
	    map.put("fieldnm", "vflow_air_inBF");
		map.put("value", vflow_acncao2h2_air_inBF);
		pmap.put("vflow_acncao2h2_air_inBF", vflow_acncao2h2_air_inBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_h2o_outBF");
		map.put("value", vflow_h2o_outBF);
		pmap.put("vflow_h2o_outBF", vflow_h2o_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_o2_outBF");
		map.put("value", vflow_o2_outBF);
		pmap.put("vflow_o2_outBF", vflow_o2_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_n2_outBF");
		map.put("value", vflow_n2_outBF);
		pmap.put("vflow_n2_outBF", vflow_n2_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mflow_flyash_outBF");
		map.put("value", mflow_flyash_outBF);
		pmap.put("mflow_flyash_outBF", mflow_flyash_outBF);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_2_3_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "vflow_so2_outSDR");
		List<CombusitionPipeOutDTO>vflow_so2_outBF_list = optMapper.getPipeoutByField(map);
		double vflow_so2_outBF = vflow_so2_outBF_list.get(0).getValue();
		
	    
		map.put("fieldnm", "vflow_hcl_outSDR");
		List<CombusitionPipeOutDTO> vflow_hcl_outBF_list = optMapper.getPipeoutByField(map);
		double vflow_hcl_outBF = vflow_hcl_outBF_list.get(0).getValue();
		
		map.put("fieldnm", "vflow_co2_outSDR");
		List<CombusitionPipeOutDTO> vflow_co2_outBF_list = optMapper.getPipeoutByField(map);
		double vflow_co2_outBF = vflow_co2_outBF_list.get(0).getValue();
		
	    // store to db
	    map.put("fieldnm", "vflow_so2_outBF");
		map.put("value", vflow_so2_outBF);
		pmap.put("vflow_so2_outBF", vflow_so2_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_hcl_outBF");
		map.put("value", vflow_hcl_outBF);
		pmap.put("vflow_hcl_outBF", vflow_hcl_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_co2_outBF");
		map.put("value", vflow_co2_outBF);
		pmap.put("vflow_co2_outBF", vflow_co2_outBF);
		optMapper.updatePipeoutValue(map);
		
	    // data.insert_data_to_db(data, 'vflow_h2o_outBF', data.mb_2_3_bf.vflow_h2o_outBF);
		return pmap;
	}

	@Override
	public HashMap mb_2_4_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		 
			map.put("fieldnm", "vppm_co_outSDR");
			List<CombusitionPipeOutDTO> vppm_co_inBF_list = optMapper.getPipeoutByField(map);
			double vppm_co_inBF = vppm_co_inBF_list.get(0).getValue();
			
			map.put("fieldnm", "vppm_no2_outSDR");
			List<CombusitionPipeOutDTO> vppm_no2_inBF_list = optMapper.getPipeoutByField(map);
			double vppm_no2_inBF = vppm_no2_inBF_list.get(0).getValue();
			
			map.put("fieldnm", "vflow_gas_outSDR");
			List<CombusitionPipeOutDTO> vflow_gas_inBF_list = optMapper.getPipeoutByField(map);
			double vflow_gas_inBF = vflow_gas_inBF_list.get(0).getValue();
			
		    //
		    //
			double vflow_co_outBF = (vppm_co_inBF * vflow_gas_inBF) / 1000000;
			double vflow_no2_outBF = (vppm_no2_inBF * vflow_gas_inBF) / 1000000;

			double vflow_o2_outBF = (double)pmap.get("vflow_o2_outBF");
			double vflow_n2_outBF = (double)pmap.get("vflow_n2_outBF");
			double vflow_so2_outBF = (double)pmap.get("vflow_so2_outBF");
			double vflow_hcl_outBF = (double)pmap.get("vflow_hcl_outBF");
			double vflow_co2_outBF = (double)pmap.get("vflow_co2_outBF");
			double vflow_h2o_outBF = (double)pmap.get("vflow_h2o_outBF");
			
			pmap.put("vflow_co_outBF", vflow_co_outBF);
			pmap.put("vflow_no2_outBF", vflow_no2_outBF);
			
			pmap.put("vflow_o2_outBF", vflow_o2_outBF);
			pmap.put("vflow_n2_outBF", vflow_n2_outBF);
			pmap.put("vflow_so2_outBF", vflow_so2_outBF);
			pmap.put("vflow_hcl_outBF", vflow_hcl_outBF);
			pmap.put("vflow_co2_outBF", vflow_co2_outBF);
			pmap.put("vflow_h2o_outBF", vflow_h2o_outBF);

			
		    // formula
		    // vflow_gas_outBF = vflow_o2_outBF + vflow_n2_outBF + vflow_h2o_outBF + vflow_so2_outBF + vflow_hcl_outBF + vflow_co2_outBF
			double vflow_gas_outBF =
		      vflow_o2_outBF +
		      vflow_n2_outBF +
		      vflow_so2_outBF +
		      vflow_hcl_outBF +
		      vflow_co2_outBF +
		      vflow_h2o_outBF +
		      vflow_no2_outBF +
		      vflow_co_outBF;
			
			pmap.put("vflow_gas_outBF", vflow_gas_outBF);

		return pmap;
	}
	private double returnCP_AIR(double t_air) throws Exception {

		double n1 = Math.round(t_air * 0.01);
		double t1 = n1 * 100;
		double cp_air = 0;
		HashMap map = new HashMap();
		
		if (t1 == t_air) {
			map.put("temp", t_air);
			List<CombusitionCpDTO> cpdtolist = optMapper.getCpBytemp(map);
		    cp_air = cpdtolist.get(0).getAirlo();
		} else {
		    if (t_air < 100) {
		      cp_air = 0.31;
		    } else {
		      // const n2 = n1 + 1;
		      double t2 = t1 + 100;
		      // const c1 = gas_cptbl(n1, 11);
		      map.put("temp", t1);
			  List<CombusitionCpDTO> cpdtolist = optMapper.getCpBytemp(map);
		      double c1 = cpdtolist.get(0).getAirlo();
		      // const c2 = gas_cptbl(n2, 11);
		      map.put("temp", t2);
			  cpdtolist = optMapper.getCpBytemp(map);
		      double c2 = cpdtolist.get(0).getAirlo();
		      cp_air = ((t_air - t1) * (c1 - c2)) / (t1 - t2) + c1;

		    }
		}
		return cp_air;
	}
	@Override
	public HashMap hb_1_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		map.put("fieldnm", "q_gas_outSDR");
		List<CombusitionPipeOutDTO> q_gas_inBF_list = optMapper.getPipeoutByField(map);
		double q_gas_inBF = q_gas_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "t_gas_outSDR");
		List<CombusitionPipeOutDTO> t_gas_outSDR_list = optMapper.getPipeoutByField(map);
		double t_gas_outSDR =  t_gas_outSDR_list.get(0).getValue();
		
	    map.put("fieldnm", "mflow_flyash_outSDR");
		List<CombusitionPipeOutDTO> mflow_flyash_outSDR_list = optMapper.getPipeoutByField(map);
		double mflow_flyash_outSDR = mflow_flyash_outSDR_list.get(0).getValue();
		
	    // pipe add (func: return value)
		map.put("fieldnm", "t_air_inBF");
		List<CombusitionPipeAddDTO> t_air_inBF_list = optMapper.getPipeaddByname(map);
		double t_air_inBF = t_air_inBF_list.get(0).getValue();
		
	    //
	    // const cp_air_inBF = helper.plm.PIPEADD_NM_DB(data.wpid, 'cp_air_inBF');
	    double cp_air_inBF = returnCP_AIR( t_air_inBF);
	    // helper.log.verbose('cp_air_inBF: ' + JSON.stringify(cp_air_inBF));
	    // constant in global (func: return value)
		map.put("fieldnm", "k1_hloss_BF");
		List<CombusitionConsTantDTO> k1_hloss_BF_list =  optMapper.getConstantByField(map);
		double k1_hloss_BF = k1_hloss_BF_list.get(0).getValue();
		double vflow_compair_inBF = (double)pmap.get("vflow_compair_inBF");
		double vflow_acncao2h2_air_inBF = (double)pmap.get("vflow_acncao2h2_air_inBF");
	    // formula inBF
	    // 금산군 탈진공기 온도 = 42
		double  q_air_inBF =
	      (vflow_compair_inBF + vflow_acncao2h2_air_inBF) *
	      t_air_inBF *
	      (cp_air_inBF + 0.0014);
		double  cp_flyash_BF = 0.3;
		double  cp_ac_BF = 0.2;
		double  t_ac_inBF = 20;
		double t_gas_inBF = (double)pmap.get("t_gas_inBF");
		double mflow_ac_inBF = (double)pmap.get("mflow_ac_inBF");
		double mflow_flyash_inBF = (double)pmap.get("mflow_flyash_inBF");
		double  q_flyash_inBF = mflow_flyash_inBF * t_gas_inBF * cp_flyash_BF;
		double  q_ac_inBF = mflow_ac_inBF * t_ac_inBF * cp_ac_BF;
		double  q_totalflyash_inBF = q_flyash_inBF + q_ac_inBF;
	    // 금산군은 비산재열량 불포함
	    double q_inBF = q_gas_inBF + q_air_inBF + 0 * q_totalflyash_inBF;

	    double mflow_flyash_outBF = (double)pmap.get("mflow_flyash_outBF");
	    double mflow_btmash_outBF = (double)pmap.get("mflow_btmash_outBF");
	    double vflow_gas_outBF = (double)pmap.get("vflow_gas_outBF");
	    pmap.put("vflow_gas_outBF", vflow_gas_outBF);
	    double vflow_o2_outBF = (double)pmap.get("vflow_o2_outBF");
	    double vflow_n2_outBF = (double)pmap.get("vflow_n2_outBF");
	    double vflow_so2_outBF = (double)pmap.get("vflow_so2_outBF");
	    double vflow_hcl_outBF = (double)pmap.get("vflow_hcl_outBF");
	    double vflow_co2_outBF = (double)pmap.get("vflow_co2_outBF");
	    double vflow_h2o_outBF = (double)pmap.get("vflow_h2o_outBF");
	    
	    double vflow_co_outBF = (double)pmap.get("vflow_co_outBF");
	    double vflow_no2_outBF = (double)pmap.get("vflow_no2_outBF");
		
	    // formula outBF
	    double t_gas_outBF = 160;
	    double q_hloss_BF = k1_hloss_BF * q_inBF;
	    double q_flyash_outBF = mflow_flyash_outBF * t_gas_outBF * cp_flyash_BF;
	    double q_btmash_outBF = mflow_btmash_outBF * t_gas_outBF * cp_flyash_BF;
	    double q_totalflyash_outBF = q_flyash_outBF + q_btmash_outBF;
	    double q_outBF = q_inBF - (q_totalflyash_outBF + q_hloss_BF);
	    //
	    double cpxtBF = q_outBF / vflow_gas_outBF;
	    //
	    double vfp_o2_outBF = (vflow_o2_outBF / vflow_gas_outBF) * 100;
	    double vfp_n2_outBF = (vflow_n2_outBF / vflow_gas_outBF) * 100;
	    double vfp_so2_outBF = (vflow_so2_outBF / vflow_gas_outBF) * 100;
	    double vfp_hcl_outBF = (vflow_hcl_outBF / vflow_gas_outBF) * 100;
	    double vfp_co2_outBF = (vflow_co2_outBF / vflow_gas_outBF) * 100;
	    double vfp_h2o_outBF = (vflow_h2o_outBF / vflow_gas_outBF) * 100;
	    double vfp_no2_outBF = (vflow_no2_outBF / vflow_gas_outBF) * 100;
	    double vfp_co_outBF = (vflow_co_outBF / vflow_gas_outBF) * 100;
	    //
	    double[] vfgas2tbl_outBF = new double[8];
	    vfgas2tbl_outBF[0] = vfp_o2_outBF;
	    vfgas2tbl_outBF[1] = vfp_n2_outBF;
	    vfgas2tbl_outBF[2] = vfp_co2_outBF;
	    vfgas2tbl_outBF[3] = vfp_co_outBF;
	    vfgas2tbl_outBF[4] = vfp_no2_outBF;
	    vfgas2tbl_outBF[5] = vfp_so2_outBF;
	    vfgas2tbl_outBF[6] = vfp_h2o_outBF;
	    vfgas2tbl_outBF[7] = vfp_hcl_outBF;
	    
	    //
	    // data.hb23_inci2.t_gas_outcombst23 = helper.tgasfcpxt(cpxtsncr, vfgas2tbl_outsncr);
	    double t1_gas_outBF = tgasfcpxt(cpxtBF, vfgas2tbl_outBF);
	    t1_gas_outBF = t1_gas_outBF;
	    double cpt_gas_outBF = returnCP_WGAS2(t1_gas_outBF, vfgas2tbl_outBF);
	    double q_gas_outBF = cpt_gas_outBF * vflow_gas_outBF * t1_gas_outBF;


		map.put("fieldnm", "t_gas_outBF");
		map.put("value", t1_gas_outBF);
		pmap.put("t1_gas_outBF", t1_gas_outBF);
		pmap.put("t_gas_outBF", t1_gas_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "cp_gas_outBF");
		map.put("value", cpt_gas_outBF);
		pmap.put("cpt_gas_outBF", cpt_gas_outBF);
		pmap.put("cp_gas_outBF", cpt_gas_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_gas_outBF");
		map.put("value", vflow_gas_outBF);
		pmap.put("qo_total_SDR", vflow_gas_outBF);
		optMapper.updatePipeoutValue(map);
		
	    // store to db
	    map.put("fieldnm", "qi_air_inBF");
		map.put("value", q_air_inBF);
		pmap.put("qo_total_SDR", q_air_inBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qi_totalflyash_inBF");
		map.put("value", q_totalflyash_inBF);
		pmap.put("q_totalflyash_inBF", q_totalflyash_inBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qi_gas_inBF");
		map.put("value", q_gas_inBF);
		pmap.put("qo_total_SDR", q_gas_inBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qi_total_inBF");
		map.put("value", q_inBF);
		pmap.put("qo_total_SDR", q_inBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_hloss_BF");
		map.put("value", q_hloss_BF);
		pmap.put("q_hloss_BF", q_hloss_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_totalflyash_outBF");
		map.put("value", q_totalflyash_outBF);
		pmap.put("q_totalflyash_outBF", q_totalflyash_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_gas_outBF");
		map.put("value", q_gas_outBF);
		pmap.put("q_gas_outBF", q_gas_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "qo_total_outBF");
		map.put("value", q_outBF);
		pmap.put("q_outBF", q_outBF);
		optMapper.updatePipeoutValue(map);
		
	    return pmap;
	}

	@Override
	public HashMap hb_2_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		// pipe in (func: return value)
	    // const q_gas_inBF = helper.plm.PIPEIN_NM_DB(data.wpid, 'q_gas_inBF');
	    
	    map.put("fieldnm", "q_gas_outSDR");
		List<CombusitionPipeOutDTO>q_gas_inBF_list = optMapper.getPipeoutByField(map);
		double q_gas_inBF = q_gas_inBF_list.get(0).getValue();
		
	    // pipe add (func: return value)
	    
		map.put("fieldnm", "cp_air_inBF");
		List<CombusitionPipeAddDTO> cp_air_inBF_list = optMapper.getPipeaddByname(map);
		double cp_air_inBF = cp_air_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "t_air_inBF");
		List<CombusitionPipeAddDTO> t_air_inBF_list = optMapper.getPipeaddByname(map);
		double t_air_inBF = t_air_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_airpea_inBF");
		List<CombusitionPipeAddDTO> vflow_airpea_inBF_list = optMapper.getPipeaddByname(map);
		double vflow_airpea_inBF = vflow_airpea_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_nozzle_BF");
		List<CombusitionPipeAddDTO> ea_nozzle_BF_list = optMapper.getPipeaddByname(map);
		double ea_nozzle_BF = ea_nozzle_BF_list.get(0).getValue();
		
	    // constant in global (func: return value)
	    
		map.put("fieldnm", "sg_airat0c");
		List<CombusitionConsTantDTO> sg_airat0c_list =  optMapper.getConstantByField(map);
		double sg_airat0c = sg_airat0c_list.get(0).getValue();
		
		map.put("fieldnm", "k1_hloss_BF");
		List<CombusitionConsTantDTO> k1_hloss_BF_list =  optMapper.getConstantByField(map);
		double k1_hloss_BF = k1_hloss_BF_list.get(0).getValue();
		
		double vflow_gas_outBF =(double)pmap.get("vflow_gas_outBF");
		double cp_gas_outBF =(double)pmap.get("cp_gas_outBF");
		double t_gas_outBF =(double)pmap.get("t_gas_outBF");
		
	    // formula
	    double qi_air_BF = vflow_airpea_inBF * ea_nozzle_BF * sg_airat0c * t_air_inBF * cp_air_inBF;
	    double qi_total_BF = q_gas_inBF + qi_air_BF;
	    double qo_hloss_BF = qi_total_BF * k1_hloss_BF;
	    double q_gas_outBF = vflow_gas_outBF * cp_gas_outBF * t_gas_outBF;
	    double qo_total_BF = qo_hloss_BF + q_gas_outBF;

	    // store to db
	    // data.insert_data_to_db(data, 'qi_air_BF', data.hb_2_bf.qi_air_BF);
	    // data.insert_data_to_db(data, 'qi_total_BF', data.hb_2_bf.qi_total_BF);
	    // data.insert_data_to_db(data, 'qo_hloss_BF', data.hb_2_bf.qo_hloss_BF);
	    // data.insert_data_to_db(data, 'q_gas_outBF', data.hb_2_bf.q_gas_outBF);
	    // data.insert_data_to_db(data, 'qo_total_BF', data.hb_2_bf.qo_total_BF);

		return pmap;
	}

	@Override
	public HashMap mb_2_5_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		
		map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
		double vflow_gas_outBF = (double) pmap.get("vflow_gas_outBF");
		pmap.put("vflow_gas_outBF", vflow_gas_outBF);
		double t1_gas_outBF = (double) pmap.get("t1_gas_outBF");
	    // formula
	    double vflowa_gas_outBF = (vflow_gas_outBF * (ktemp + t1_gas_outBF)) / ktemp;
	    
		map.put("fieldnm", "vflowa_gas_outBF");
		map.put("value", vflowa_gas_outBF);
		pmap.put("vflowa_gas_outBF", vflowa_gas_outBF);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap mb_3_1_bf(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "vppm_co_outSDR");
		List<CombusitionPipeOutDTO>vppm_co_inBF_list = optMapper.getPipeoutByField(map);
		double vppm_co_inBF = vppm_co_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "vppm_no2_outSDR");
		List<CombusitionPipeOutDTO>vppm_no2_inBF_list = optMapper.getPipeoutByField(map);
		double vppm_no2_inBF = vppm_no2_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "vppm_so2_outSDR");
		List<CombusitionPipeOutDTO>vppm_so2_inBF_list = optMapper.getPipeoutByField(map);
		double vppm_so2_inBF = vppm_so2_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "vppm_hcl_outSDR");
		List<CombusitionPipeOutDTO>vppm_hcl_inBF_list = optMapper.getPipeoutByField(map);
		double vppm_hcl_inBF = vppm_hcl_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_gas_outSDR");
		List<CombusitionPipeOutDTO> vflow_gas_inBF_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inBF = vflow_gas_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "mpv_dioxin_outSDR");
		List<CombusitionPipeOutDTO> mpv_dioxin_inBF_list = optMapper.getPipeoutByField(map);
		double mpv_dioxin_inBF = mpv_dioxin_inBF_list.get(0).getValue();
		
	    // flyash --> dust
	    map.put("fieldnm", "mpv_flyash_outSDR");
		List<CombusitionPipeOutDTO> mpv_dust_inBF_list = optMapper.getPipeoutByField(map);
		double mpv_dust_inBF = mpv_dust_inBF_list.get(0).getValue();
		
	    // constant in facility (func: return value)
	    map.put("fieldnm", "k2_eldioxin_BF");
		List<CombusitionPipeOutDTO> k2_eldioxin_BF_list = optMapper.getPipeoutByField(map);
		double k2_eldioxin_BF = k2_eldioxin_BF_list.get(0).getValue();
		
		map.put("fieldnm", "k3_eldust_BF");
		List<CombusitionConsTantDTO> k3_eldust_BF_list =  optMapper.getConstantByField(map);
		double k3_eldust_BF = k3_eldust_BF_list.get(0).getValue();
		
		double vflow_gas_outBF = (double)pmap.get("vflow_gas_outBF");
	    // formula
	    double vppm_co_outBF = (vppm_co_inBF * vflow_gas_inBF) / vflow_gas_outBF;
	    double vppm_no2_outBF = (vppm_no2_inBF * vflow_gas_inBF) / vflow_gas_outBF;
	    double vppm_so2_outBF = (vppm_so2_inBF * vflow_gas_inBF) / vflow_gas_outBF;
	    double vppm_hcl_outBF = (vppm_hcl_inBF * vflow_gas_inBF) / vflow_gas_outBF;
	    double mpv_dioxin_outBF = mpv_dioxin_inBF * (1.0 - k2_eldioxin_BF);
	    double mpv_dust_outBF = mpv_dust_inBF * (1.0 - k3_eldust_BF);

	    // store to db
		map.put("fieldnm", "vppm_co_outBF");
		map.put("value", vppm_co_outBF);
		pmap.put("vppm_co_outBF", vppm_co_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_no2_outBF");
		map.put("value", vppm_no2_outBF);
		pmap.put("vppm_no2_outBF", vppm_no2_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_so2_outBF");
		map.put("value", vppm_so2_outBF);
		pmap.put("vppm_so2_outBF", vppm_so2_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vppm_hcl_outBF");
		map.put("value", vppm_hcl_outBF);
		pmap.put("vppm_hcl_outBF", vppm_hcl_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mpv_dioxin_outBF");
		map.put("value", mpv_dioxin_outBF);
		pmap.put("mpv_dioxin_outBF", mpv_dioxin_outBF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mpv_dust_outBF");
		map.put("value", mpv_dust_outBF);
		pmap.put("mpv_dust_outBF", mpv_dust_outBF);
		optMapper.updatePipeoutValue(map);
		
		
	    return pmap;
	}

	@Override
	public HashMap bf_design(HashMap pmap) throws Exception {
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		map.put("fieldnm", "t_gas_outSDR");
		List<CombusitionPipeOutDTO>t_gas_inBF_list = optMapper.getPipeoutByField(map);
		double t_gas_inBF = t_gas_inBF_list.get(0).getValue();
		
	    map.put("fieldnm", "vflow_gas_outSDR");
		List<CombusitionPipeOutDTO>vflow_gas_inBF_list = optMapper.getPipeoutByField(map);
		double vflow_gas_inBF = vflow_gas_inBF_list.get(0).getValue();
		
	    // constant in global (func: return value)
		map.put("fieldnm", "min2sec");
		List<CombusitionConsTantDTO> min2sec_list =  optMapper.getConstantByField(map);
		double min2sec = min2sec_list.get(0).getValue();
		
	    map.put("fieldnm", "ktemp");
		List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
		double ktemp = ktemp_list.get(0).getValue();
		
	    map.put("fieldnm", "min2hr");
		List<CombusitionConsTantDTO> min2hr_list =  optMapper.getConstantByField(map);
		double min2hr = min2hr_list.get(0).getValue();
		
	    map.put("fieldnm", "mm2m");
		List<CombusitionConsTantDTO> mm2m_list =  optMapper.getConstantByField(map);
		double mm2m = mm2m_list.get(0).getValue();
		
	    map.put("fieldnm", "k4_bagcntmargin_BF");
		List<CombusitionConsTantDTO> k4_bagcntmargin_BF_list =  optMapper.getConstantByField(map);
		double k4_bagcntmargin_BF = k4_bagcntmargin_BF_list.get(0).getValue();
		
		
	    // pipe add (func: return desval)
	    map.put("fieldnm", "mpmin_gasvel_BF");
		List<CombusitionPipeAddDTO> mpmin_gasvel_BF_list = optMapper.getPipeaddByname(map);
		double mpmin_gasvel_BF = mpmin_gasvel_BF_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_bagdim_BF");
		List<CombusitionPipeAddDTO> mm_bagdim_BF_list = optMapper.getPipeaddByname(map);
		double mm_bagdim_BF = mm_bagdim_BF_list.get(0).getValue();
		
	    map.put("fieldnm", "mm_baglength_BF");
		List<CombusitionPipeAddDTO> mm_baglength_BF_list = optMapper.getPipeaddByname(map);
		double mm_baglength_BF = mm_baglength_BF_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_bagrow_BF");
		List<CombusitionPipeAddDTO> ea_bagrow_BF_list = optMapper.getPipeaddByname(map);
		double ea_bagrow_BF = ea_bagrow_BF_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_bagline_BF");
		List<CombusitionPipeAddDTO> ea_bagline_BF_list = optMapper.getPipeaddByname(map);
		double ea_bagline_BF = ea_bagline_BF_list.get(0).getValue();
		
	    map.put("fieldnm", "ea_chamber_BF");
		List<CombusitionPipeAddDTO> ea_chamber_BF_list = optMapper.getPipeaddByname(map);
		double ea_chamber_BF = ea_chamber_BF_list.get(0).getValue();
		
	    
	    double CMM_volume_BF = (vflow_gas_inBF * (ktemp + t_gas_inBF)) / ktemp / min2hr;
	    double m2_filtarea_BF = CMM_volume_BF / mpmin_gasvel_BF / min2sec;
	    double m2_bagarea_BF = Math.pow(3.14 * mm_bagdim_BF * mm_baglength_BF * mm2m, 2);
	    double ea_bagcnt_BF =
	      (m2_filtarea_BF / m2_bagarea_BF) * ((100 + k4_bagcntmargin_BF) / 100);
	    double ea_bagarroff_BF =
	      ea_bagrow_BF * ea_bagline_BF * ea_chamber_BF;
	    double ea_bagarron_BF =
	      ea_bagarroff_BF - ea_bagarroff_BF / ea_chamber_BF;
	    double mps_filtveloff_BF =
	      m2_filtarea_BF / (m2_bagarea_BF * ea_bagarroff_BF);
	    double mps_filtvelon_BF =
	      m2_filtarea_BF / (m2_bagarea_BF * ea_bagarron_BF);

	    // store to db
		map.put("fieldnm", "m2_filtarea_BF");
		map.put("value", m2_filtarea_BF);
		pmap.put("m2_filtarea_BF", m2_filtarea_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "m2_bagarea_BF");
		map.put("value", m2_bagarea_BF);
		pmap.put("m2_bagarea_BF", m2_bagarea_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "ea_bagcnt_BF");
		map.put("value", ea_bagcnt_BF);
		pmap.put("ea_bagcnt_BF", ea_bagcnt_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "ea_bagarroff_BF");
		map.put("value", ea_bagarroff_BF);
		pmap.put("ea_bagarroff_BF", ea_bagarroff_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "ea_bagarron_BF");
		map.put("value", ea_bagarron_BF);
		pmap.put("ea_bagarron_BF", ea_bagarron_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mps_filtveloff_BF");
		map.put("value", mps_filtveloff_BF);
		pmap.put("mps_filtveloff_BF", mps_filtveloff_BF);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mps_filtvelon_BF");
		map.put("value", mps_filtvelon_BF);
		pmap.put("mps_filtvelon_BF", mps_filtvelon_BF);
		optMapper.updatePipeoutValue(map);
		
	    return pmap;
	}

	private double tgasfcpxt(double cpxt, double[] vfgas2tbl) throws Exception {
		  // vfgas2tbl : [o2, n2, co2, co, no, so2, h2o, hcl]
		  double tmin = 100;
		  double  tmax = 1500;
		  double  timsi = 0.0;
		  double cp_tmin = returnCP_WGAS2(tmin, vfgas2tbl);
		  double cp_tmax = returnCP_WGAS2(tmax, vfgas2tbl);
		  double loopcnt = 0;

		  //
		  while (loopcnt < 20) {
		    if (cp_tmin * tmin < cpxt && cpxt < cp_tmax * tmax) {
		      timsi = (tmax + tmin) / 2;

		      if (0.00001 < Math.abs(cpxt - timsi * returnCP_WGAS2(timsi, vfgas2tbl))) {
		        if (cpxt > timsi * returnCP_WGAS2(timsi, vfgas2tbl)) {
		          tmin = timsi;
		          cp_tmin = returnCP_WGAS2(tmin, vfgas2tbl);
		        } else {
		          tmax = timsi;
		          cp_tmax = returnCP_WGAS2(tmax, vfgas2tbl);
		        }
		      } else {
		      
		        break;
		      }
		    } else {
		      
		      break;
		    }

		    loopcnt = loopcnt + 1; // avoid for infinite loop
		  }
		  return timsi;
		};
	private double returnCP_WGAS2(double t_gas, double[] vfgas2tbl) throws Exception {
		  // vfgas2tbl : [o2, n2, co2, co, no, so2, h2o, hcl]
		  List<Map> CP_DB_DATA = new ArrayList();
		  Map cpmap = new HashMap();
		  
		  cpmap.put("temp", 100);
	      cpmap.put("o2", 0.315);
	      cpmap.put("n2", 0.311);
	      cpmap.put("co2", 0.409);
	      cpmap.put("co", 0.312);
	      cpmap.put("no", 0.319);
	      cpmap.put("so2", 0.435);
	      cpmap.put("h2o", 0.36);
	      cpmap.put("hcl", 0.311);
	      cpmap.put("airlo", 0.311);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(0, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 200);
	      cpmap.put("o2", 0.32);
	      cpmap.put("n2", 0.312);
	      cpmap.put("co2", 0.429);
	      cpmap.put("co", 0.313);
	      cpmap.put("no", 0.321);
	      cpmap.put("so2", 0.454);
	      cpmap.put("h2o", 0.364);
	      cpmap.put("hcl", 0.311);
	      cpmap.put("airlo", 0.313);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(1, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 300);
	      cpmap.put("o2", 0.325);
	      cpmap.put("n2", 0.313);
	      cpmap.put("co2", 0.447);
	      cpmap.put("co", 0.316);
	      cpmap.put("no", 0.323);
	      cpmap.put("so2", 0.47);
	      cpmap.put("h2o", 0.369);
	      cpmap.put("hcl", 0.313);
	      cpmap.put("airlo", 0.315);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(2, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 400);
	      cpmap.put("o2", 0.33);
	      cpmap.put("n2", 0.316);
	      cpmap.put("co2", 0.463);
	      cpmap.put("co", 0.319);
	      cpmap.put("no", 0.327);
	      cpmap.put("so2", 0.483);
	      cpmap.put("h2o", 0.374);
	      cpmap.put("hcl", 0.315);
	      cpmap.put("airlo", 0.318);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(3, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 500);
	      cpmap.put("o2", 0.334);
	      cpmap.put("n2", 0.319);
	      cpmap.put("co2", 0.477);
	      cpmap.put("co", 0.322);
	      cpmap.put("no", 0.33);
	      cpmap.put("so2", 0.495);
	      cpmap.put("h2o", 0.38);
	      cpmap.put("hcl", 0.317);
	      cpmap.put("airlo", 0.321);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(4, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 600);
	      cpmap.put("o2", 0.339);
	      cpmap.put("n2", 0.321);
	      cpmap.put("co2", 0.49);
	      cpmap.put("co", 0.326);
	      cpmap.put("no", 0.334);
	      cpmap.put("so2", 0.506);
	      cpmap.put("h2o", 0.386);
	      cpmap.put("hcl", 0.32);
	      cpmap.put("airlo", 0.325);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(5, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 700);
	      cpmap.put("o2", 0.343);
	      cpmap.put("n2", 0.325);
	      cpmap.put("co2", 0.501);
	      cpmap.put("co", 0.329);
	      cpmap.put("no", 0.337);
	      cpmap.put("so2", 0.515);
	      cpmap.put("h2o", 0.392);
	      cpmap.put("hcl", 0.322);
	      cpmap.put("airlo", 0.328);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(6, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 800);
	      cpmap.put("o2", 0.347);
	      cpmap.put("n2", 0.329);
	      cpmap.put("co2", 0.512);
	      cpmap.put("co", 0.332);
	      cpmap.put("no", 0.34);
	      cpmap.put("so2", 0.523);
	      cpmap.put("h2o", 0.399);
	      cpmap.put("hcl", 0.324);
	      cpmap.put("airlo", 0.331);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(7, cpmap);
		  
		  cpmap = new HashMap();
		  cpmap.put("temp", 900);
	      cpmap.put("o2", 0.35);
	      cpmap.put("n2", 0.331);
	      cpmap.put("co2", 0.52);
	      cpmap.put("co", 0.335);
	      cpmap.put("no", 0.344);
	      cpmap.put("so2", 0.53);
	      cpmap.put("h2o", 0.405);
	      cpmap.put("hcl", 0.327);
	      cpmap.put("airlo", 0.334);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(8, cpmap);
		  
		  cpmap = new HashMap();
		  cpmap.put("temp", 1000);
	      cpmap.put("o2", 0.354);
	      cpmap.put("n2", 0.334);
	      cpmap.put("co2", 0.529);
	      cpmap.put("co", 0.338);
	      cpmap.put("no", 0.346);
	      cpmap.put("so2", 0.536);
	      cpmap.put("h2o", 0.412);
	      cpmap.put("hcl", 0.329);
	      cpmap.put("airlo", 0.338);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(9, cpmap);
		  
		  cpmap = new HashMap();
		  cpmap.put("temp", 1100);
	      cpmap.put("o2", 0.356);
	      cpmap.put("n2", 0.338);
	      cpmap.put("co2", 0.537);
	      cpmap.put("co", 0.341);
	      cpmap.put("no", 0.349);
	      cpmap.put("so2", 0.542);
	      cpmap.put("h2o", 0.418);
	      cpmap.put("hcl", 0.331);
	      cpmap.put("airlo", 0.34);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(10, cpmap);
	 
		  cpmap = new HashMap();
	      cpmap.put("temp", 1200);
	      cpmap.put("o2", 0.359);
	      cpmap.put("n2", 0.34);
	      cpmap.put("co2", 0.544);
	      cpmap.put("co", 0.344);
	      cpmap.put("no", 0.351);
	      cpmap.put("so2", 0.546);
	      cpmap.put("h2o", 0.425);
	      cpmap.put("hcl", 0.333);
	      cpmap.put("airlo", 0.343);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(11, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 1300);
	      cpmap.put("o2", 0.362);
	      cpmap.put("n2", 0.342);
	      cpmap.put("co2", 0.55);
	      cpmap.put("co", 0.346);
	      cpmap.put("no", 0.354);
	      cpmap.put("so2", 0.55);
	      cpmap.put("h2o", 0.43);
	      cpmap.put("hcl", 0);
	      cpmap.put("airlo", 0.345);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(12, cpmap);
		  
		  cpmap.put("temp", 1500);
		  cpmap.put("o2", 0.366);
		  cpmap.put("n2", 0.347);
	      cpmap.put("co2", 0.561);
	      cpmap.put("co", 0.351);
	      cpmap.put("no", 0.358);
	      cpmap.put("so2", 0.557);
	      cpmap.put("h2o", 0.442);
	      cpmap.put("hcl", 0);
	      cpmap.put("airlo", 0.35);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(13, cpmap);
		  
		  cpmap = new HashMap();
	      cpmap.put("temp", 1400);
	      cpmap.put("o2", 0.364);
	      cpmap.put("n2", 0.345);
	      cpmap.put("co2", 0.556);
	      cpmap.put("co", 0.348);
	      cpmap.put("no", 0.356);
	      cpmap.put("so2", 0.554);
	      cpmap.put("h2o", 0.437);
	      cpmap.put("hcl", 0);
	      cpmap.put("airlo", 0.348);
	      cpmap.put("mixgas", 0);
	      cpmap.put("slope", 0);
	      CP_DB_DATA.add(14,cpmap);
	      
	      Map lo = new HashMap();
	      lo.put("1500", 0);
		  lo.put("1400", 0);
		  lo.put("1300", 0);
		  lo.put("1200", 0.371);
		  lo.put("1100", 0.368);
		  lo.put("1000", 0.364);
		  lo.put("900", 0.361);
		  lo.put("800", 0.357);
		  lo.put("700", 0.352);
		  lo.put("600", 0.348);
		  lo.put("500", 0.344);
		  lo.put("400", 0.339);
		  lo.put("300", 0.335);
		  lo.put("200", 0.331);
		  lo.put("100", 0.327);
		  lo.put("0", 0.323);
		  
		  for(int i=0; i < CP_DB_DATA.size(); i++) {
			  //Map cpmap = (Map)CP_DB_DATA.get(i);
			  double o2 = (double)CP_DB_DATA.get(i).get("o2");
			  CP_DB_DATA.get(i).put("o2", BigDecimal.valueOf((vfgas2tbl[0] * o2)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double n2 = (double)CP_DB_DATA.get(i).get("n2");
			  CP_DB_DATA.get(i).put("n2", BigDecimal.valueOf((vfgas2tbl[1] * n2)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double co2 = (double)CP_DB_DATA.get(i).get("co2");
			  CP_DB_DATA.get(i).put("co2", BigDecimal.valueOf((vfgas2tbl[2] * co2)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double co = (double)CP_DB_DATA.get(i).get("co");
			  CP_DB_DATA.get(i).put("co", BigDecimal.valueOf((vfgas2tbl[3] * co)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double no = (double)CP_DB_DATA.get(i).get("no");
			  CP_DB_DATA.get(i).put("no", BigDecimal.valueOf((vfgas2tbl[4] * no)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double so2 = (double)CP_DB_DATA.get(i).get("so2");
			  CP_DB_DATA.get(i).put("so2", BigDecimal.valueOf((vfgas2tbl[5] * so2)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double h2o = (double)CP_DB_DATA.get(i).get("h2o");
			  CP_DB_DATA.get(i).put("h2o", BigDecimal.valueOf((vfgas2tbl[6] * h2o)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double hcl = (double)CP_DB_DATA.get(i).get("hcl");
			  CP_DB_DATA.get(i).put("hcl", BigDecimal.valueOf((vfgas2tbl[7] * hcl)).setScale(12, RoundingMode.HALF_UP)
		    		    .doubleValue()) ;
			  
			  double temp = (double)CP_DB_DATA.get(i).get("temp");
			  CP_DB_DATA.get(i).put("temp", lo.get(temp));
			  
		  }
		  double temp200mixgas = 0;
		  double temp1200mixgas = 0;
		  double temp200slope = 0;
		  double temp1200slope = 0;
		  double temp1300mixgas = 0;
		  double temp1400mixgas = 0;
		  double temp1500mixgas = 0;
		  
		  for(int i=0; i < CP_DB_DATA.size(); i++) {
			  double temp = (double)CP_DB_DATA.get(i).get("temp");
			  if (temp < 1300 && temp > 100) {
				  
				  if(temp == 200) {
					  Map tempmap = new HashMap();
					  tempmap.put("wpid", OptConstant.WPID);
					  tempmap.put("temp", temp);
					  List<CombusitionCpDTO> o = optMapper.getCpBytemp(tempmap);
					  temp200mixgas = o.get(0).getMixgas();
				  } else if(temp == 1200) {
					  Map tempmap = new HashMap();
					  tempmap.put("wpid", OptConstant.WPID);
					  tempmap.put("temp", temp);
					  List<CombusitionCpDTO> o = optMapper.getCpBytemp(tempmap);
					  temp1200mixgas = o.get(0).getMixgas();				  
					  
				  }
				  Map tempmap = new HashMap();
				  tempmap.put("wpid", OptConstant.WPID);
				  tempmap.put("temp", temp - 100);
				  List<CombusitionCpDTO> o = optMapper.getCpBytemp(tempmap);
				
				
				  CP_DB_DATA.get(i).put("slope",BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
				  		     .doubleValue());
				  if(temp == 200) {
					  temp200slope = BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
					  		     .doubleValue();
					  CP_DB_DATA.get(0).put("slope",BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
					  		     .doubleValue());
				  } else if(temp == 1200) {
					  temp1200slope = BigDecimal.valueOf(((double)((Map)CP_DB_DATA.get(i)).get("mixgas") - o.get(0).getMixgas()) / 100).setScale(12, RoundingMode.HALF_UP)
					  		     .doubleValue();				  
				  }
			  } else {
				 
				  if(temp == 1300) {
					  CP_DB_DATA.get(i).put("slope",temp1200slope);
					  CP_DB_DATA.get(i).put("mixgas",temp1200slope * temp200mixgas * 100 + temp200mixgas);
					  temp1300mixgas = temp1200slope * temp200mixgas * 100 + temp200mixgas;
				  } else if(temp == 1400) {
					  CP_DB_DATA.get(i).put("slope",temp1200slope);
					  CP_DB_DATA.get(i).put("mixgas",temp1200slope * temp1300mixgas * 100 + temp1300mixgas);
					  temp1400mixgas = temp1200slope * temp1300mixgas * 100 + temp1300mixgas;
					  
				  } else if(temp == 1500) {
					  CP_DB_DATA.get(i).put("slope",temp1200slope);
					  CP_DB_DATA.get(i).put("mixgas",temp1200slope * temp1400mixgas * 100 + temp1400mixgas);
				  } else if(temp == 100) {
					  
				  }
				  
			      
			  }
		  }
		 

		  // 1) t_gas :폐기물연소 배가스 온도 입력
		  // 2) 연산
		  // n1 = roundoff ( t_gas x 0.01 ) : n1 정수
		  // t1 = n1 x 100,0

		  double n1 = Math.round(t_gas * 0.01);
		  double t1 = n1 * 100;
		  double cp_wgas = 0;
		  int index = 0;
		  if(t1 == 100) {
			  index = 0;
		  } else if(t1 == 200) {
			  index = 1;
		  } else if(t1 == 300) {
			  index = 2;
		  } else if(t1 == 400) {
			  index = 3;
		  } else if(t1 == 500) {
			  index = 4;
		  } else if(t1 == 600) {
			  index = 5;
		  } else if(t1 == 700) {
			  index = 6;
		  } else if(t1 == 800) {
			  index = 7;
		  } else if(t1 == 900) {
			  index = 8;
		  } else if(t1 == 1000) {
			  index = 9;
		  } else if(t1 == 1100) {
			  index = 10;
		  } else if(t1 == 1200) {
			  index = 11;
		  } else if(t1 == 1300) {
			  index = 12;
		  } else if(t1 == 1400) {
			  index = 13;
		  } else if(t1 == 1500) {
			  index = 14;
		  }
		  if (t1 == t_gas) {
		    cp_wgas = (double)CP_DB_DATA.get(index).get("mixgas");;
		  } else {
		    // const n2 = n1 + 1;
		    // const t2 = t1 + 100; change (+) to (-)
		    double t2 = t1 + 100;
		    // const c1 = w2gas_cptbl(n1, 11);
		    double c1 = (double)CP_DB_DATA.get(index).get("mixgas");
		    // const c2 = w2gas_cptbl(n2, 11);
		    double c2 = (double)CP_DB_DATA.get(index+1).get("mixgas");;;
		    // cp_wgas = ((t_gas - t1) * (c1 - c2)) / (t1 - t2) + c1;
		    cp_wgas = c1 - ((c1 - c2) * (t1 - t_gas)) / (t1 - t2);
		  }
		  return cp_wgas;
	}
}
