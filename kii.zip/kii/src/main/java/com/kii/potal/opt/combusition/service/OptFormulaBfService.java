package com.kii.potal.opt.combusition.service;

import java.util.HashMap;

public interface OptFormulaBfService {
	HashMap mb_1_1_bf(HashMap map)throws Exception;
	HashMap mb_2_1_bf(HashMap map)throws Exception;
	HashMap mb_2_3_bf(HashMap map)throws Exception;
	HashMap mb_2_4_bf(HashMap map)throws Exception;
	
	HashMap hb_1_bf(HashMap map)throws Exception;
	HashMap hb_2_bf(HashMap map)throws Exception;
	HashMap mb_2_5_bf(HashMap map)throws Exception;
	HashMap mb_3_1_bf(HashMap map)throws Exception;
	HashMap bf_design(HashMap map)throws Exception;
	
}
