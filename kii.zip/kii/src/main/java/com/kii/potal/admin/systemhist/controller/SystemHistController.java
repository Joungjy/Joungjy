package com.kii.potal.admin.systemhist.controller;

import com.kii.potal.admin.systemhist.dto.SystemHistDTO;
import com.kii.potal.admin.systemhist.service.SystemHistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class SystemHistController {
    @Autowired
    SystemHistService systemHistService;

    /**
     * 시스템 이력관리 리스트 조회
     *
     * @param model
     * @param request
     * @param response
     * @return 시스템 이력관리 리스트 조회 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/systemHistList.do", method = RequestMethod.GET)
    public String getSystemHistList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        SystemHistDTO systemHistDTO = new SystemHistDTO();
        model.addAttribute("list",systemHistService.getSysHistList(systemHistDTO));
        return "admin/systemHist/system_hist_list";
    }

    /**
     * 시스템 이력관리 정보 등록
     *
     * @param model
     * @param request
     * @param response
     * @return 시스템 이력관리 정보 등록 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/systemHistInsertProc.do", method = RequestMethod.POST)
    public void insertSystemHistItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        SystemHistDTO systemHistDTO = new SystemHistDTO();
        systemHistService.insertSysHistItem(systemHistDTO);

    }

}
