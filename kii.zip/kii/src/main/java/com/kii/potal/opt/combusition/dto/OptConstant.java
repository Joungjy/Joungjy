package com.kii.potal.opt.combusition.dto;

public class OptConstant {
	public static String WPID = "1213";
	public static String wp_c_waste = "1102";
	public static String wp_h_waste = "1103";
	public static String wp_o_waste = "1104";
	public static String wp_n_waste = "1105";
	public static String wp_s_waste = "1106";
	public static String wp_cl_waste = "1107";
	public static String wp_h2o_waste = "1100";
	public static String wp_ash_waste = "1101";
	public static String mflow_waste = "1200";
	public static String ratio_exair_waste = "1201";
	
	public static String wp_h2_fuel1 = "1302";
	public static String wp_co_fuel1 = "1303";
	public static String wp_ch4_fuel1 = "1304";
	public static String wp_c2h6_fuel1 = "1305";
	public static String wp_n2_fuel1 = "1306";
	public static String wp_o2_fuel1 = "1307";
	
	public static String muflow_fuel1 = "1300";
	public static String ratio_exair_fuel1 = "1301";
	
	
	
}
