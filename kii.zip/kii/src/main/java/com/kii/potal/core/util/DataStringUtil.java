package com.kii.potal.core.util;

import org.apache.commons.lang3.StringUtils;

public class DataStringUtil {

    public static String defaultString(String str){
        return StringUtils.defaultString(str);
    }

    public static String defaultString(String str, String defaultStr){
        return StringUtils.defaultString(str, defaultStr);
    }

    public static String defaultIfBlank(String str, String defaultStr) {
        return StringUtils.defaultIfBlank(str, defaultStr);
    }

    public static String toString(Object obj){
        //return Objects.toString(obj);
        return obj == null ? null : obj.toString();
    }

    public static boolean equals(String str1, String str2) {
        return StringUtils.equals(str1, str2);
    }

    public static boolean notEquals(String str1, String str2) {
        return !equals(str1, str2);
    }

    public static boolean equalsAny(CharSequence string, CharSequence... searchStrings){
        return StringUtils.equalsAny(string, searchStrings);
    }

    public static boolean equalsAny(String string, String[] searchStrings){
        return StringUtils.equalsAny(string, searchStrings);
    }

    public static boolean isEmpty(String str){
        return StringUtils.isEmpty(str);
    }

    public static boolean isNotEmpty(String str){
        return StringUtils.isNotEmpty(str);
    }

    public static boolean contains(String str, String searchStr){
        return StringUtils.contains(str, searchStr);
    }

    public static String nl2br(String str) {
        return (str != null) ? str.replace("\n", "<br />") : "";
    }

    public static String cleanScript(String value) {

        //value = value.replaceAll("\\(", "& #40;").replaceAll("\\)", "& #41;");

        //value = value.replaceAll("'", "& #39;");

        value = value.replaceAll("eval\\((.*)\\)", "");

        value = value.replaceAll("[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']", "\"\"");

        value = value.replaceAll("script", "");

        //value = org.springframework.web.util.HtmlUtils.htmlEscape(value);
        //SQL injection characters
        //value = StringEscapeUtils.escapeSql(value);

        return value;
    }

    public static int length(CharSequence cs){
        return StringUtils.length(cs);
    }

}
