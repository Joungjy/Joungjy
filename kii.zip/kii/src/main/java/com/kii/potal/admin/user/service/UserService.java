package com.kii.potal.admin.user.service;

import com.kii.potal.admin.user.dto.UserDTO;

import java.util.List;

public interface UserService {

    //사용자 리스트
    List<UserDTO> getUserList(UserDTO userDTO) throws Exception;

    //사용자 상세 정보
    UserDTO getUserItem(UserDTO userDTO)throws Exception;

    //사용자 정보 업데이트
    void updateUserItem(UserDTO userDTO)throws Exception;

    //사용자 정보 삽입
    void insertUserItem(UserDTO userDTO) throws Exception;

    void delUserItem(UserDTO userDTO) throws Exception;

    boolean getDuplicate(UserDTO userDTO) throws Exception;


}
