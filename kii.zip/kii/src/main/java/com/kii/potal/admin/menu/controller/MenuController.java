package com.kii.potal.admin.menu.controller;

import com.kii.potal.admin.menu.dto.MenuDTO;
import com.kii.potal.admin.menu.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class MenuController {


    @Autowired
    MenuService menuService;
    /**
     * 메뉴 리스트 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 메뉴 리스트 정보 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuList.do", method = RequestMethod.GET)
    public String getUserList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        MenuDTO menuDTO = new MenuDTO();
        menuService.getMenuList(menuDTO);

        return "admin/menu/menu_list";
    }

    /**
     * 메뉴 정보 상세보기 
     *
     * @param model
     * @param request
     * @param response
     * @return 메뉴 정보 상세보기 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuView.do", method = RequestMethod.GET)
    public String getUserItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        MenuDTO menuDTO = new MenuDTO();
        menuService.getMenuList(menuDTO);

        return "admin/menu/menu_view";
    }

    /**
     * 메뉴 정보 삽입 페이지
     *
     * @param model
     * @param request
     * @param response
     * @return 메뉴 정보 삽입 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuInsert.do", method = RequestMethod.GET)
    public String inserMenuItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        MenuDTO menuDTO = new MenuDTO();
        menuService.getMenuList(menuDTO);

        return "admin/menu/menu_insert";
    }

    /**
     * 메뉴 정보 삽입 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 메뉴 정보 삽입 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuInsertProc.do", method = RequestMethod.POST)
    public String inserMenuItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        MenuDTO menuDTO = new MenuDTO();
        menuService.getMenuList(menuDTO);

        return "redirect:/admin/menuInsert.do";
    }

    /**
     * 메뉴 정보 업데이트 페이지
     *
     * @param model
     * @param request
     * @param response
     * @return 메뉴 정보 업데이트 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuUpdate.do", method = RequestMethod.GET)
    public String updateMenuItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        MenuDTO menuDTO = new MenuDTO();
        menuService.getMenuList(menuDTO);

        return "admin/menu/menu_update";
    }

    /**
     * 메뉴 정보 업데이트 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 메뉴 정보 업데이트 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuUpdateProc.do", method = RequestMethod.GET)
    public String updateMenuItemProc(HttpServletRequest request, HttpServletResponse response, Model model, MenuDTO menuDTO) throws Exception {

        //MenuDTO menuDTO = new MenuDTO();
        menuService.updateMenuItem(menuDTO);

        return "redirect:/admin/menuUpdate.do";
    }

    /**
     * 메뉴 정보 삭제 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return json result
     * @throws Exception
     */
    @RequestMapping(value = "/admin/menuDeleteProc.do", method = RequestMethod.GET)
    public String deleteMenuItem(HttpServletRequest request, HttpServletResponse response, Model model, MenuDTO menuDTO) throws Exception {

        //MenuDTO menuDTO = new MenuDTO();
        menuService.deleteMenuItem(menuDTO);

        return "json";
    }



}
