package com.kii.potal.opt.combusition.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;

public interface OptFormulaElementService {
	HashMap waste(HashMap map,List<CombusitionPipeOutDTO> el1list)throws Exception;
	HashMap dry_waste(HashMap map,List<CombusitionPipeOutDTO> el1list)throws Exception;
	HashMap hhv_drywaste(HashMap map,List<CombusitionPipeOutDTO> el1list)throws Exception;
	HashMap hhv_waste(HashMap map,List<CombusitionPipeOutDTO> el1list)throws Exception;
	HashMap lhv_waste(HashMap map,List<CombusitionPipeOutDTO> el1list)throws Exception;
	
	
}
