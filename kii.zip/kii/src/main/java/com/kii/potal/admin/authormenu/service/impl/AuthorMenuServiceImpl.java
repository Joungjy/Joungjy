package com.kii.potal.admin.authormenu.service.impl;

import com.kii.potal.admin.authormenu.dto.AuthorMenuDTO;
import com.kii.potal.admin.authormenu.service.AuthorMenuService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthorMenuServiceImpl extends EgovAbstractServiceImpl implements AuthorMenuService {

    @Autowired
    AuthorMenuMapper authorMenuMapper;

    @Override
    public List<AuthorMenuDTO> getAuthorMenutList(AuthorMenuDTO authorMenuDTO) throws Exception {
        return null;
    }

    @Override
    public void insertAuthorMenuItem(AuthorMenuDTO authorMenuDTO) throws Exception {

    }

    @Override
    public void deleteAuthorMenuItem(AuthorMenuDTO authorMenuDTO) throws Exception {

    }
}
