package com.kii.potal.admin.eqpdefect.controller;

import com.kii.potal.admin.eqpdefect.service.EqpDefectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class EqpDefectController {

    @Autowired
    EqpDefectService eqpDefectService;



}
