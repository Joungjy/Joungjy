package com.kii.potal.admin.user.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserDTO {
    private Long usrNo;
    private String usrNm;
    private String usrId;
    private String fcltyCd;
    private String fcltyNm;
    private String lastConectDt;
    private String grpNo;
    private String grpNm;
    private String athrCd;
    private String athrNm;
    private Long conectCnt;
    private String athrList;
    private String athrListStr;

    @Builder
    public UserDTO(Long usrNo, String usrNm, String usrId, String athrCd) {
        this.usrNo = usrNo;
        this.usrNm = usrNm;
        this.usrId = usrId;
        this.athrCd = athrCd;
    }
}
