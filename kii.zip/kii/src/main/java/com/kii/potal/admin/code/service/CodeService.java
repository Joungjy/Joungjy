package com.kii.potal.admin.code.service;

import com.kii.potal.admin.code.dto.CodeDTO;

import java.util.List;

public interface CodeService {

    //코드 리스트 
    List<CodeDTO> getCodeList(CodeDTO codeDTO);
    //코드 상세 정보
    CodeDTO getCodeItem(CodeDTO codeDTO);
    //코드 정보 삽입
    void insertCodeItem(CodeDTO codeDTO);
    //코드 정보 수정 
    void updateCodeItem(CodeDTO codeDTO);
    //코드 정보 삭제
    void deleteCodeItem(CodeDTO codeDTO);

}
