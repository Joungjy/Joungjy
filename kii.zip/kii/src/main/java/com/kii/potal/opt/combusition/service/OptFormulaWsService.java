package com.kii.potal.opt.combusition.service;

import java.util.HashMap;

public interface OptFormulaWsService {
	HashMap mb_1_1_ws(HashMap map)throws Exception;
	HashMap mb_1_2_ws(HashMap map)throws Exception;
	HashMap hb_1_ws(HashMap map)throws Exception;
	HashMap mb_1_3_ws(HashMap map)throws Exception;
	HashMap mb_1_4_ws(HashMap map)throws Exception;
	HashMap hb_2_ws(HashMap map)throws Exception;
	HashMap mb_2_ws(HashMap map)throws Exception;
	HashMap mb_3_ws(HashMap map)throws Exception;
	HashMap etc_ws(HashMap map)throws Exception;
	HashMap ws_design1(HashMap map)throws Exception;
	HashMap ws_design2(HashMap map)throws Exception;
	HashMap ws_design3(HashMap map)throws Exception;
}
