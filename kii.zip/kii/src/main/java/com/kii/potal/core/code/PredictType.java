package com.kii.potal.core.code;

public enum PredictType {
    REAL_MSMT("실측수질", "REAL_MSMT"),
    TAG_MSMT("계측수질", "TAG_MSMT");

    private final String name;

    private final String value;

    PredictType(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() { return this.name; }

    public String getValue() { return this.value; }
}
