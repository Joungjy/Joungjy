package com.kii.potal.admin.authormenu.service;

import com.kii.potal.admin.authormenu.dto.AuthorMenuDTO;

import java.util.List;

public interface AuthorMenuService {

    //관리자 메뉴 권한 리스트
    List<AuthorMenuDTO> getAuthorMenutList(AuthorMenuDTO authorMenuDTO) throws Exception;

    //관리자 메뉴 권한 정보 등록
    void insertAuthorMenuItem(AuthorMenuDTO authorMenuDTO) throws Exception;
    
    //관리자 메뉴 권한 삭제
    void deleteAuthorMenuItem(AuthorMenuDTO authorMenuDTO) throws Exception;


}
