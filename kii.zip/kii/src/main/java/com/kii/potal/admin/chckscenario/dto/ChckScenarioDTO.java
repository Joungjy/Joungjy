package com.kii.potal.admin.chckscenario.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ChckScenarioDTO {


    private String chckSenarioId;       //점검시나리오 아이디
    private String chckSenarioNm;       //점검 시나리오 명
    private String tagId;       //점검 시나리오 태그 아이디
    private String tagNm;       //점검 시나리오 태그 명
    private String registDt;        //등록일
    private String regstrNo;        //등록자 번호
    private String updtDt;      //수정일
    private String updtNo;      //수정자 번호
    private String delDt;       //삭제일시
    private String dltrNo;      //삭제자번호
    private String delYn;       //삭제여부


}
