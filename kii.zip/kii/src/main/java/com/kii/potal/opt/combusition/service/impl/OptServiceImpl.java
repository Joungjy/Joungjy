package com.kii.potal.opt.combusition.service.impl;



import com.kii.potal.admin.user.dto.UserDTO;
import com.kii.potal.admin.user.service.UserService;
import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.service.OptService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptServiceImpl extends EgovAbstractServiceImpl implements OptService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public List<CombusitionElementInDTO> getElementin(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getElementin(map);
	}
	@Override
	public List<CombusitionElementInDTO> getElementinByname(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getElementinByname(map);
	}
	
	@Override
	public List<CombusitionPipeAddDTO> getPipeadd(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getPipeadd(map);
	}

	@Override
	public List<CombusitionPipeAddDTO> getPipeaddByname(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getPipeaddByname(map);
	}

	
	@Override
	public List<CombusitionConsTantDTO> getConstant(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getConstant(map);
	}
	@Override
	public List<CombusitionConsTantDTO> getConstantByField(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getConstantByField(map);
	}
	
	@Override
	public List<CombusitionPipeOutDTO> getPipeout(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getPipeout(map);
	}
	@Override
	public List<CombusitionPipeOutDTO> getPipeoutByField(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getPipeoutByField(map);
	}
	@Override
	public List<CombusitionPipeOutDTO> getPipeoutBygroupcd(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getPipeoutBygroupcd(map);
	}
	
	@Override
	public void insertElementin(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.insertElementin(map);
	}

	@Override
	public void insertPipeadd(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.insertPipeadd(map);
	}

	@Override
	public void insertConstant(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.insertConstant(map);
	}

	@Override
	public void insertPipeout(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.insertPipeout(map);
	}

	@Override
	public void updatePipeadd(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.updatePipeadd(map);
	}

	@Override
	public void updateElementin(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.updateElementin(map);
	}

	@Override
	public void updateConstant(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.updateConstant(map);
	}

	@Override
	public void updatePipeout(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.updatePipeout(map);
	}
	
	@Override
	public void updatePipeoutValue(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.updatePipeoutValue(map);
	}
	

	@Override
	public void delElementin(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.delElementin(map);
	}

	@Override
	public void delPipeadd(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.delPipeadd(map);
	}

	@Override
	public void delConstant(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.delConstant(map);
	}

	@Override
	public void delPipeout(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.delPipeout(map);
	}

	@Override
	public List<CombusitionCpDTO> getCp(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getCp(map);
	}
	@Override
	public List<CombusitionCpDTO> getCpBytemp(Map map) throws Exception {
		// TODO Auto-generated method stub
		return optMapper.getCpBytemp(map);
	}
	
	@Override
	public void insertCp(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.insertConstant(map);
	}

	@Override
	public void delCp(Map map) throws Exception {
		// TODO Auto-generated method stub
		optMapper.delConstant(map);
	}

	

   
}
