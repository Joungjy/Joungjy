package com.kii.potal.admin.code.service.impl;

import com.kii.potal.admin.code.dto.CodeDTO;
import com.kii.potal.admin.code.service.CodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CodeServiceImpl extends EgovAbstractServiceImpl implements CodeService {
    @Override
    public List<CodeDTO> getCodeList(CodeDTO codeDTO) {
        return null;
    }

    @Override
    public CodeDTO getCodeItem(CodeDTO codeDTO) {
        return null;
    }

    @Override
    public void insertCodeItem(CodeDTO codeDTO) {

    }

    @Override
    public void updateCodeItem(CodeDTO codeDTO) {

    }

    @Override
    public void deleteCodeItem(CodeDTO codeDTO) {

    }
}
