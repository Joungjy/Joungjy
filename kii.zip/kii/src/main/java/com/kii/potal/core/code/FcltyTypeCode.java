package com.kii.potal.core.code;

public class FcltyTypeCode {
    public static final String FCLTY_TY_CD_01 = "01";
    public static final String FCLTY_TY_CD_02 = "02";
    public static final String FCLTY_TY_CD_03 = "03";
    public static final String FCLTY_TY_CD_04 = "04";

    public static final String FCLTY_TY_CD_05 = "05";

    public static final String FCLTY_TY_CD_06 = "06";

    public static final String FCLTY_TY_CD_07 = "07";
}
