package com.kii.potal.core.model;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.kii.potal.core.code.ErrorCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ErrorEntity<ErrorResponse> {
    private String code;
    private String errorMessage;
    private int errorNum;
    private String exception;
    private LocalDateTime errorTime;

    private ErrorResponse response;

    public ErrorEntity(ErrorResponse response, String code) {
        this.response = response;
        this.code = code;
        this.errorTime = LocalDateTime.now();
    }

    public ErrorEntity(ErrorResponse response, HttpStatus status) {
        this.response = response;
        this.code = Integer.toString(status.value());
        this.errorTime = LocalDateTime.now();
    }

    public ErrorEntity(ErrorResponse response, ErrorCode code) {
        this.response = response;
        this.code = Integer.toString(code.getStatus());
        this.errorMessage = code.getMessage();
        this.errorTime = LocalDateTime.now();
    }

}
