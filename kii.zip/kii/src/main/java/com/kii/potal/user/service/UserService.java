package com.kii.potal.user.service;

public interface UserService {
}
