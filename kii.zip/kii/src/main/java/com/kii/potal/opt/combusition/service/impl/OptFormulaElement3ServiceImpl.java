package com.kii.potal.opt.combusition.service.impl;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaElement3Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaElement3ServiceImpl extends EgovAbstractServiceImpl implements OptFormulaElement3Service {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap waste(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		pmap.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
				
		map.put("code", OptConstant.wp_h2_fuel1);
		List<CombusitionElementInDTO> wp_h2_fuel1_list =  optMapper.getElementin(map);
		double wp_h2_fuel1 = wp_h2_fuel1_list.get(0).getValue();
		
		
	    map.put("code", OptConstant.wp_co_fuel1);
		List<CombusitionElementInDTO> wp_co_fuel1_list =  optMapper.getElementin(map);
		double wp_co_fuel1 = wp_co_fuel1_list.get(0).getValue();
		
	    map.put("code", OptConstant.wp_ch4_fuel1);
		List<CombusitionElementInDTO> wp_ch4_fuel1_list =  optMapper.getElementin(map);
		double wp_ch4_fuel1 = wp_ch4_fuel1_list.get(0).getValue();
	    
		map.put("code", OptConstant.wp_c2h6_fuel1);
		List<CombusitionElementInDTO> wp_c2h6_fuel1_list =  optMapper.getElementin(map);
		double wp_c2h6_fuel1 = wp_c2h6_fuel1_list.get(0).getValue();

		map.put("code", OptConstant.wp_n2_fuel1);
		List<CombusitionElementInDTO> wp_n2_fuel1_list =  optMapper.getElementin(map);
		double wp_n2_fuel1 = wp_n2_fuel1_list.get(0).getValue();
		
		map.put("code", OptConstant.wp_o2_fuel1);
		List<CombusitionElementInDTO> wp_o2_fuel1_list =  optMapper.getElementin(map);
		double wp_o2_fuel1 = wp_o2_fuel1_list.get(0).getValue();
		
		
	    map.put("code", OptConstant.mflow_waste);
		List<CombusitionElementInDTO> mflow_waste_list =  optMapper.getElementin(map);
		double mflow_waste = mflow_waste_list.get(0).getValue();
		
	    map.put("code", OptConstant.muflow_fuel1);
		List<CombusitionElementInDTO> muflow_fuel1_list =  optMapper.getElementin(map);
		double muflow_fuel1 = muflow_fuel1_list.get(0).getValue();
		
	    map.put("code", OptConstant.ratio_exair_fuel1);
		List<CombusitionElementInDTO> ratio_exair_fuel1_list =  optMapper.getElementin(map);
		double ratio_exair_fuel1 = ratio_exair_fuel1_list.get(0).getValue();
		
		
		map.put("fieldnm", "molv_igas");
		List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
		double molv_igas = molv_igas_list.get(0).getValue();
		
		
		map.put("fieldnm", "molm_co2");
		List<CombusitionConsTantDTO> molm_co2_list =  optMapper.getConstantByField(map);
		double molm_co2 = molm_co2_list.get(0).getValue();
		
		map.put("fieldnm", "molm_n2");
		List<CombusitionConsTantDTO> molm_n2_list =  optMapper.getConstantByField(map);
		double molm_n2 = molm_n2_list.get(0).getValue();
		

		map.put("fieldnm", "molm_o2");
		List<CombusitionConsTantDTO> molm_o2_list =  optMapper.getConstantByField(map);
		double molm_o2 = molm_o2_list.get(0).getValue();
		

		map.put("fieldnm", "molm_h2o");
		List<CombusitionConsTantDTO> molm_h2o_list =  optMapper.getConstantByField(map);
		double molm_h2o = molm_h2o_list.get(0).getValue();
		
		
		
		
		// formula

	    // setp_1) 이론연소공기량 (Nm3/Nm3)
	    // vuflow_iair_fuel1 = 2.38 * ( wp_h2fuel1 + wp_co_fuel1) + 9.52 * wp_ch4_fuel1 + 16.67 * wp_c2h6_fuel1 -  4.76 * wp_o2_fuel1
	    // setp_2) 보조연료 연소용 과잉공기비율
	    // # set ratio_exair_fuel1
	    // setp_3) 보조연료 연소에 실제 공급되는 공기량 (Nm3/kg)
	    // vuflow_air_fuel1 = ( ratio_exair_fuel1 * vuflow_iair_fuel1 ) / 0.8
	    //
	    //
	    // (2023-02-15,SHKim) 체적기준 보조연료 이론연소공기량 계산 입력값의 단위(%)를 고려하여 계산식 수정 (기존식/100)
	    double vuflow_iair_fuel1 =
	      (2.38 * (wp_h2_fuel1 + wp_co_fuel1) + 9.52 * wp_ch4_fuel1 + 16.67 * wp_c2h6_fuel1 - 4.76 * wp_o2_fuel1) / 100.0;
	    double vuflow_air_fuel1 = (ratio_exair_fuel1 * vuflow_iair_fuel1) / 0.8;

	    //
	    // setp_4)
	    // # Gen. gas volume per unit fuel1 of each component gas (Nm3/Nm3)
	    // vuflow_co2_fuel1 = ( wp_ch4_fuel1 + 2.0 * wp_c2h6_fuel1 ) / 100.0
	    // vuflow_n2_fuel1 = 0.79 * vuflow_air_fuel1 * 0.8 + (wp_n2_waste / 100.0)
	    // vuflow_o2_fuel1 = 0.21 * ( ratio_exair_fuel1 – 1.0 ) * vuflow_iair_fuel1
	    // vuflow_h2o_fuel1 = ( 2.0 * wp_ch4_fuel1 + 3.0 * wp_c2h6_fuel1 ) / 100.
	    // vuflow_gas_fuel1 = ( vuflow_co2_fuel1 + vuflow_n2_fuel1 + vuflow_o2_fuel1 + vuflow_h2o_fuel1 )
	    // # Gen. gas volume fraction (%)
	    // vufp_co2_fuel1 = vuflow_co2_fuel1 / vuflow_gas_fuel1
	    // vufp_n2_fuel1 = vuflow_n2_fuel1 / vuflow_gas_fuel1
	    // vufp_o2_fuel1 = vuflow_o2_fuel1 / vuflow_gas_fuel1
	    // vufp_h2o_fuel1 = vuflow_h2o_fuel1 / vuflow_gas_fuel1
	    double vuflow_co2_fuel1 = (wp_ch4_fuel1 + 2.0 * wp_c2h6_fuel1) / 100.0;
	    double vuflow_n2_fuel1 = 0.79 * vuflow_air_fuel1 * 0.8 + wp_n2_fuel1 / 100.0;
	    double vuflow_o2_fuel1 = 0.21 * (ratio_exair_fuel1 - 1.0) * vuflow_iair_fuel1;
	    double vuflow_h2o_fuel1 = (2.0 * wp_ch4_fuel1 + 3.0 * wp_c2h6_fuel1) / 100;
	    double vuflow_gas_fuel1 =
	      vuflow_co2_fuel1 +
	      vuflow_n2_fuel1 +
	      vuflow_o2_fuel1 +
	      vuflow_h2o_fuel1;

	    //
	    // (2023-02-15,SHKim) 체적기준 보조연료 발생가스 구성비율 단위(%)를 고려하여 계산식 수정 (기존식 * 100.)
	    //
	    double vufp_co2_fuel1 = (vuflow_co2_fuel1 / vuflow_gas_fuel1) * 100.0;
	    double vufp_n2_fuel1 = (vuflow_n2_fuel1 / vuflow_gas_fuel1) * 100.0;
	    double vufp_o2_fuel1 = (vuflow_o2_fuel1 / vuflow_gas_fuel1) * 100.0;
	    double vufp_h2o_fuel1 = (vuflow_h2o_fuel1 / vuflow_gas_fuel1) * 100.0;

	    // #  Gen. gas mass flow per unit waste of each component gas (kg/kg)
	    // muflow_co2_fuel1 = ( vuflow_co2_fuel1 * molm_co2 ) / molv_igas
	    // muflow_n2_fuel1 = ( vuflow_n2_fuel1 * molm_co2 ) / molv_igas
	    // muflow_o2_fuel1 = ( vuflow_o2_fuel1 * molm_co2 ) / molv_igas
	    // muflow_h2o_fuel1 = ( vuflow_h2o_fuel1 * molm_co2 ) / molv_igas
	    // muflow_gas_fuel1 = ( muflow_co2_fuel1 + muflow_n2_fuel1 + muflow_o2_fuel1 + muflow_h2o_fuel1 )
	    // # Gen. gas mass fraction (%)
	    // mufp_co2_fuel1 = muflow_co2_fuel1 / muflow_gas_fuel1
	    // mufp_n2_fuel1 = muflow_n2_fuel1 / muflow_gas_fuel1
	    // mufp_o2_fuel1 = muflow_o2_fuel1 / muflow_gas_fuel1
	    // mufp_h2o_fuel1 = muflow_h2o_fuel1 / muflow_gas_fuel1
	    //
	    // (2023-02-15,SHKim) 보조연료인 LNG의 비중을 고려하여 계산식을 수정 (기존식 / 0.8)
	    // (2023-02-15,SHKim) 변수이름 오류 기존) molm_co2 -> 수정)molm_n2,molm_o2,molm_h20
	    //                   density_LNG = 0.804kg/m2 ; 0도씨 101.325kPa에서 LNG 비중값, 물리상수값을 사전에 정의하여 수정할 것
	    //
	    double muflow_co2_fuel1 = (vuflow_co2_fuel1 * molm_co2) / molv_igas / 0.804;
	    double muflow_n2_fuel1 = (vuflow_n2_fuel1 * molm_n2) / molv_igas / 0.804;
	    double muflow_o2_fuel1 = (vuflow_o2_fuel1 * molm_o2) / molv_igas / 0.804;
	    double muflow_h2o_fuel1 = (vuflow_h2o_fuel1 * molm_h2o) / molv_igas / 0.804;
	    double muflow_gas_fuel1 =
	      muflow_co2_fuel1 +
	      muflow_n2_fuel1 +
	      muflow_o2_fuel1 +
	      muflow_h2o_fuel1;
	    //
	    //
	    // (2023-02-15,SHKim) 체적기준 보조연료 발생가스 구성비율 단위(%)를 고려하여 계산식 수정 (기존식 * 100.)
	    //
	    double mufp_co2_fuel1 = (muflow_co2_fuel1 / muflow_gas_fuel1) * 100;
	    double mufp_n2_fuel1 = (muflow_n2_fuel1 / muflow_gas_fuel1) * 100;
	    double mufp_o2_fuel1 = (muflow_o2_fuel1 / muflow_gas_fuel1) * 100;
	    double mufp_h2o_fuel1 = (muflow_h2o_fuel1 / muflow_gas_fuel1) * 100;

	    //
	    // vflow_air_fuel1 = muflow_fuel1 * mflow_waste * vuflow_air_fuel1;
	    // vflow_gas_fuel1 = muflow_fuel1 * mflow_waste * vuflow_gas_fuel1;
	    double vflow_air_fuel1 = muflow_fuel1 * mflow_waste * vuflow_air_fuel1;
	    double vflow_gas_fuel1 = muflow_fuel1 * mflow_waste * vuflow_gas_fuel1;
	    
	    map.put("groupcd", "5003");
	    map.put("fieldnm", "vuflow_iair_fuel1");
		map.put("value", vuflow_iair_fuel1);
		pmap.put("vuflow_iair_fuel1", vuflow_iair_fuel1);
		optMapper.updatePipeoutValue(map);
		

	    map.put("fieldnm", "vuflow_air_fuel1");
		map.put("value", vuflow_air_fuel1);
		pmap.put("vuflow_air_fuel1", vuflow_air_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    
	    map.put("fieldnm", "vuflow_co2_fuel1");
		map.put("value", vuflow_co2_fuel1);
		pmap.put("vuflow_co2_fuel1", vuflow_co2_fuel1);
		optMapper.updatePipeoutValue(map);
		

	    map.put("fieldnm", "vuflow_n2_fuel1");
		map.put("value", vuflow_n2_fuel1);
		pmap.put("vuflow_n2_fuel1", vuflow_n2_fuel1);
		optMapper.updatePipeoutValue(map);
		

	    map.put("fieldnm", "vuflow_o2_fuel1");
		map.put("value", vuflow_o2_fuel1);
		pmap.put("vuflow_o2_fuel1", vuflow_o2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vuflow_h2o_fuel1");
		map.put("value", vuflow_h2o_fuel1);
		pmap.put("vuflow_h2o_fuel1", vuflow_h2o_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vuflow_gas_fuel1");
		map.put("value", vuflow_gas_fuel1);
		pmap.put("vuflow_gas_fuel1", vuflow_gas_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vufp_co2_fuel1");
		map.put("value", vufp_co2_fuel1);
		pmap.put("vufp_co2_fuel1", vufp_co2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vufp_n2_fuel1");
		map.put("value", vufp_n2_fuel1);
		pmap.put("vufp_n2_fuel1", vufp_n2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vufp_o2_fuel1");
		map.put("value", vufp_o2_fuel1);
		pmap.put("vufp_o2_fuel1", vufp_o2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vufp_h2o_fuel1");
		map.put("value", vufp_h2o_fuel1);
		pmap.put("vufp_h2o_fuel1", vufp_h2o_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "muflow_co2_fuel1");
		map.put("value", muflow_co2_fuel1);
		pmap.put("muflow_co2_fuel1", muflow_co2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "muflow_n2_fuel1");
		map.put("value", muflow_n2_fuel1);
		pmap.put("muflow_n2_fuel1", muflow_n2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "muflow_o2_fuel1");
		map.put("value", muflow_o2_fuel1);
		pmap.put("muflow_o2_fuel1", muflow_o2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "muflow_h2o_fuel1");
		map.put("value", muflow_h2o_fuel1);
		pmap.put("muflow_h2o_fuel1", muflow_h2o_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "muflow_gas_fuel1");
		map.put("value", muflow_gas_fuel1);
		pmap.put("muflow_gas_fuel1", muflow_gas_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mufp_co2_fuel1");
		map.put("value", mufp_co2_fuel1);
		pmap.put("mufp_co2_fuel1", mufp_co2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mufp_n2_fuel1");
		map.put("value", mufp_n2_fuel1);
		pmap.put("mufp_n2_fuel1", mufp_n2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mufp_o2_fuel1");
		map.put("value", mufp_o2_fuel1);
		pmap.put("mufp_o2_fuel1", mufp_o2_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "mufp_h2o_fuel1");
		map.put("value", mufp_h2o_fuel1);
		pmap.put("mufp_h2o_fuel1", mufp_h2o_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_air_fuel1");
		map.put("value", vflow_air_fuel1);
		pmap.put("vflow_air_fuel1", vflow_air_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    map.put("fieldnm", "vflow_gas_fuel1");
		map.put("value", vflow_gas_fuel1);
		pmap.put("vflow_gas_fuel1", vflow_gas_fuel1);
		optMapper.updatePipeoutValue(map);
		
	    
		return pmap;
	}


}
