package com.kii.potal.admin.systemhist.service.impl;

import com.kii.potal.admin.systemhist.dto.SystemHistDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface SystemHistMapper {

    List<SystemHistDTO> getSysHistList(SystemHistDTO systemHistDTO) throws Exception;
    //시스템 이력 정보 등록
    void insertSysHistItem(SystemHistDTO systemHistDTO) throws Exception;

}
