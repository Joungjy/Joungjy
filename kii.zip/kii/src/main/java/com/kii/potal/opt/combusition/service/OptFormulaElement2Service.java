package com.kii.potal.opt.combusition.service;

import java.util.HashMap;

public interface OptFormulaElement2Service {
	HashMap waste(HashMap map)throws Exception;
}
