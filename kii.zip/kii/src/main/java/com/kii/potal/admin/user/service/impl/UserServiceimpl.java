package com.kii.potal.admin.user.service.impl;

import com.kii.potal.admin.user.dto.UserDTO;
import com.kii.potal.admin.user.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceimpl extends EgovAbstractServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    //사용자 정보 리스트
    @Override
    public List<UserDTO> getUserList(UserDTO userDTO) throws Exception {
        return userMapper.getUserList(userDTO);
    }

    //사용자 상세 정보
    @Override
    public UserDTO getUserItem(UserDTO userDTO) throws Exception {
        return null;
    }

    //사용자 정보 업데이트
    @Override
    public void updateUserItem(UserDTO userDTO) throws Exception {

    }

    //사용자 정보 삽입
    @Override
    public void insertUserItem(UserDTO userDTO) throws Exception {

    }

    //사용자 정보 삭제
    @Override
    public void delUserItem(UserDTO userDTO) throws Exception {

    }

    //사용자 중복 확인
    @Override
    public boolean getDuplicate(UserDTO userDTO) throws Exception {
        return false;
    }

}
