package com.kii.potal.opt.combusition.service.impl;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaCpService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaCpServiceImpl extends EgovAbstractServiceImpl implements OptFormulaCpService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public List<CombusitionCpDTO> calc_mix_gas(List<CombusitionCpDTO> list) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		map.put("fieldnm", "vufp_o2_combst1");
		map.put("groupcd", "6002");
		List<CombusitionPipeOutDTO> vufp_o2_combst1_list = optMapper.getPipeoutByField(map);
		double vufp_o2_combst1 = vufp_o2_combst1_list.get(0).getValue();
		
		map.put("fieldnm", "vufp_n2_combst1");
		List<CombusitionPipeOutDTO> vufp_n2_combst1_list = optMapper.getPipeoutByField(map);
		double vufp_n2_combst1 = vufp_n2_combst1_list.get(0).getValue();

		map.put("fieldnm", "vufp_co2_combst1");
		List<CombusitionPipeOutDTO> vufp_co2_combst1_list = optMapper.getPipeoutByField(map);
		double vufp_co2_combst1 = vufp_co2_combst1_list.get(0).getValue();
		
		
		double vufp_co_combst1 = 0;
		double vufp_no_combst1 = 0;
	    
		map.put("fieldnm", "vufp_so2_combst1");
		List<CombusitionPipeOutDTO> vufp_so2_combst1_list = optMapper.getPipeoutByField(map);
		double vufp_so2_combst1 = vufp_so2_combst1_list.get(0).getValue();
		
		map.put("fieldnm", "vufp_h2o_combst1");
		List<CombusitionPipeOutDTO> vufp_h2o_combst1_list = optMapper.getPipeoutByField(map);
		double vufp_h2o_combst1 = vufp_h2o_combst1_list.get(0).getValue();
	    
	    map.put("fieldnm", "vufp_hcl_combst1");
		List<CombusitionPipeOutDTO> vufp_hcl_combst1_list = optMapper.getPipeoutByField(map);
		double vufp_hcl_combst1 = vufp_hcl_combst1_list.get(0).getValue();
	    // fuel
	    
	    map.put("fieldnm", "vufp_o2_fuel1");
		List<CombusitionPipeOutDTO> vufp_o2_fuel1_list = optMapper.getPipeoutByField(map);
		double vufp_o2_fuel1 = vufp_o2_fuel1_list.get(0).getValue();
	    
	    map.put("fieldnm", "vufp_n2_fuel1");
		List<CombusitionPipeOutDTO> vufp_n2_fuel1_list = optMapper.getPipeoutByField(map);
		double vufp_n2_fuel1 = vufp_n2_fuel1_list.get(0).getValue();
	    
	    map.put("fieldnm", "vufp_co2_fuel1");
		List<CombusitionPipeOutDTO> vufp_co2_fuel1_list = optMapper.getPipeoutByField(map);
		double vufp_co2_fuel1 = vufp_co2_fuel1_list.get(0).getValue();
	    
	    
	    double vufp_co_fuel1 = 0;
	    double vufp_no_fuel1 = 0;
	    double vufp_so2_fuel1 = 0;
	    
	    map.put("fieldnm", "vufp_h2o_fuel1");
		List<CombusitionPipeOutDTO> vufp_h2o_fuel1_list = optMapper.getPipeoutByField(map);
		double vufp_h2o_fuel1 = vufp_h2o_fuel1_list.get(0).getValue();
	    
	    double vufp_hcl_fuel1 = 0;
	    
	    List<CombusitionCpDTO> reslist = new ArrayList<CombusitionCpDTO>();
	    
	    for(int i=0; i < list.size(); i++) {
	    	CombusitionCpDTO dto = list.get(i);
	    	if(dto.getCptype().equals("1")) {
		    	float val = Float.parseFloat(String.valueOf(vufp_o2_combst1 * dto.getO2())) +
		  	          Float.parseFloat(String.valueOf(vufp_n2_combst1 * dto.getN2())) +
		  	          Float.parseFloat(String.valueOf(vufp_co2_combst1 * dto.getCo2())) +
		  	          Float.parseFloat(String.valueOf(vufp_co_combst1 * dto.getCo())) +
		  	          Float.parseFloat(String.valueOf(vufp_no_combst1 * dto.getNo())) +
		  	          Float.parseFloat(String.valueOf(vufp_so2_combst1 * dto.getSo2())) +
		  	          Float.parseFloat(String.valueOf(vufp_h2o_combst1 * dto.getH2o())) +
		  	          Float.parseFloat(String.valueOf(vufp_hcl_combst1 * dto.getHcl())) ;
		  	    	
		  	    	val = val / 100;
		  	    	
		  	    	double truncatedDouble = BigDecimal.valueOf(val)
		  	    		    .setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
		  	    	dto.setMixgas(truncatedDouble); 	    		
	    	} else if(dto.getCptype().equals("2")) {
	    		
	    		 double o2 = BigDecimal.valueOf((vufp_o2_combst1 * dto.getO2())) .setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double n2 = BigDecimal.valueOf((vufp_n2_combst1 * dto.getN2())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double co2 = BigDecimal.valueOf((vufp_co2_combst1 * dto.getCo2())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double co = BigDecimal.valueOf((vufp_co_combst1 * dto.getCo())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double no = BigDecimal.valueOf((vufp_no_combst1 * dto.getNo())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double so2 = BigDecimal.valueOf((vufp_so2_combst1 * dto.getSo2())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double h2o = BigDecimal.valueOf((vufp_h2o_combst1 * dto.getH2o())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double hcl = BigDecimal.valueOf((vufp_hcl_combst1 * dto.getHcl())).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        double airlo = dto.getAirlo();
	    	        //
	    	        // 2023.02.23, SHKim ; change r.mixgas cal. after each components cal.
	    	        //
	    	        double mixgas = BigDecimal.valueOf(((o2 + n2 + co2 + co + no + so2 + h2o + hcl) / 100)).setScale(3, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
	    	        
	    	        dto.setO2(o2);
	    	        dto.setN2(n2);
	    	        dto.setCo2(co2);
	    	        dto.setCo(co);
	    	        dto.setNo(no);
	    	        dto.setSo2(so2);
	    	        dto.setH2o(h2o);
	    	        dto.setHcl(hcl);
	    	        dto.setAirlo(airlo);
	    	        dto.setMixgas(mixgas);
	    		
	    	} else if(dto.getCptype().equals("3")) {
	    		double o2 = BigDecimal.valueOf((vufp_o2_fuel1 * dto.getO2())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double n2 = BigDecimal.valueOf((vufp_n2_fuel1 * dto.getN2())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double co2 = BigDecimal.valueOf((vufp_co2_fuel1 * dto.getCo2())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double co = BigDecimal.valueOf((vufp_co_fuel1 * dto.getCo())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double no = BigDecimal.valueOf((vufp_no_fuel1 * dto.getNo())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double so2 = BigDecimal.valueOf((vufp_so2_fuel1 * dto.getSo2())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double h2o = BigDecimal.valueOf((vufp_h2o_fuel1 * dto.getH2o())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double hcl = BigDecimal.valueOf((vufp_hcl_fuel1 * dto.getHcl())).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		double airlo =  dto.getAirlo();
	            //
	            //2023-02-23, SHKim : mixed gas cp cal. after each components gas cp cal & summation
	    		double mixgas = BigDecimal.valueOf((o2 + n2 + co2 + co + no + so2 + h2o + hcl)).setScale(3, RoundingMode.HALF_UP)
	  	    		    .doubleValue();
	    		
	    		 dto.setO2(o2);
	    	        dto.setN2(n2);
	    	        dto.setCo2(co2);
	    	        dto.setCo(co);
	    	        dto.setNo(no);
	    	        dto.setSo2(so2);
	    	        dto.setH2o(h2o);
	    	        dto.setHcl(hcl);
	    	        dto.setAirlo(airlo);
	    	        dto.setMixgas(mixgas);
	    		
	    	}
	    	reslist.add(dto);
	    }
		
		
		
		return reslist;
	}

	@Override
	public List<CombusitionCpDTO> calc_slope(List<CombusitionCpDTO> list) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		double cpdbslope1400 = 0;
		double cpdbslope200 = 0;
		
		double cpwasteslope200 = 0;
		double cpwasteslope1200 = 0;
		double cpwasteslope1300 = 0;
		double cpwasteslope1400 = 0;
		
		double cpwastemixgas1200 = 0;
		double cpwastemixgas1300 = 0;
		double cpwastemixgas1400 = 0;
		
		
		
		for(int i=0; i < list.size(); i++) {
			CombusitionCpDTO dto = list.get(i);
			Long temp = dto.getTemp();
			if(dto.getCptype().equals("1")) {
				
				if (temp < 1500 && temp > 100) {
					map.put("temp", temp - 100);
					List<CombusitionCpDTO> tempDto = optMapper.getCpBytemp(map);
					double slope =  BigDecimal.valueOf(((dto.getMixgas() - tempDto.get(0).getMixgas())/100)).setScale(7, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
						dto.setSlope(slope);
					if(temp == 1400) {
						cpdbslope1400 = slope;
					} else if(temp == 200) {
						cpdbslope200 = slope;
					}
			    } else {
			        	
			    	if(temp == 1500) {
						dto.setSlope(cpdbslope1400);
			    	} else if (temp == 100) {
						dto.setSlope(cpdbslope200);
			    	}
			    }
				
			} else if(dto.getCptype().equals("2")) {
				if (temp < 1300 && temp > 100) {
					map.put("temp", temp - 100);
					List<CombusitionCpDTO> tempDto = optMapper.getCpBytemp(map);
					double slope =  BigDecimal.valueOf(((dto.getMixgas() - tempDto.get(0).getMixgas())/100)).setScale(7, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
						dto.setSlope(slope);
						if(temp == 1200) {
							cpwasteslope1200 = slope;
							cpwastemixgas1200 = dto.getMixgas();
						}
						if(temp == 200) {
							cpwasteslope200 = slope;
						}
			    } else {
			        	
			    	if(temp == 1500) {
						dto.setSlope(cpwasteslope1200);
						dto.setMixgas(dto.getSlope() * cpwastemixgas1400 * 100 + cpwastemixgas1400);
			    	} else if (temp == 1400) {
						dto.setSlope(cpwasteslope1200);
						cpwastemixgas1400 = dto.getMixgas();
						dto.setMixgas(dto.getSlope() * cpwastemixgas1300 * 100 + cpwastemixgas1300);
			    	} else if (temp == 1300) {
						dto.setSlope(cpwasteslope1200);
						cpwastemixgas1300 = dto.getMixgas();
						dto.setMixgas(dto.getSlope() * cpwastemixgas1200 * 100 + cpwastemixgas1200);
			    	} else if (temp == 100) {
						dto.setSlope(cpwasteslope200);
			    	}
			    }
			} else if(dto.getCptype().equals("3")) {
				
				if (temp < 1300 && temp > 100) {
					map.put("temp", temp - 100);
					List<CombusitionCpDTO> tempDto = optMapper.getCpBytemp(map);
					double slope =  BigDecimal.valueOf(((dto.getMixgas() - tempDto.get(0).getMixgas())/100)).setScale(7, RoundingMode.HALF_UP)
		  	    		    .doubleValue();
						dto.setSlope(slope);
				} else {
					if(temp == 1500) {
						dto.setSlope(cpwasteslope1200);
						dto.setMixgas(dto.getSlope() * cpwastemixgas1400 * 100 + cpwastemixgas1400);
			    	} else if (temp == 1400) {
						dto.setSlope(cpwasteslope1200);
						cpwastemixgas1400 = dto.getMixgas();
						dto.setMixgas(dto.getSlope() * cpwastemixgas1300 * 100 + cpwastemixgas1300);
			    	} else if (temp == 1300) {
						dto.setSlope(cpwasteslope1200);
						cpwastemixgas1300 = dto.getMixgas();
						dto.setMixgas(dto.getSlope() * cpwastemixgas1200 * 100 + cpwastemixgas1200);
			    	} else if (temp == 100) {
						dto.setSlope(cpwasteslope200);
			    	}
				}
			}
			map.put("idx", dto.getIdx());
			optMapper.delCp(map);
			map.put("wpid", dto.getWpid());
			map.put("cptype", dto.getCptype());
			map.put("cpindex", dto.getCpindex());
			map.put("statecd", dto.getStatecd());
			map.put("temp", dto.getTemp());
			map.put("o2", dto.getO2());
			map.put("n2", dto.getN2());
			map.put("co2", dto.getCo2());
			map.put("co", dto.getCo());
			map.put("so2", dto.getSo2());
			map.put("h2o", dto.getH2o());
			map.put("hcl", dto.getHcl());
			map.put("airlo", dto.getAirlo());
			map.put("mixgas", dto.getMixgas());
			map.put("slope", dto.getSlope());
			optMapper.insertCp(map);
			
		}
		
		return null;
	}

	@Override
	public void insert_to_queue(List<CombusitionCpDTO> list) {
		// TODO Auto-generated method stub
		
	}


}
