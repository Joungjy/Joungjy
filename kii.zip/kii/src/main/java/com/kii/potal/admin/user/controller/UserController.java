package com.kii.potal.admin.user.controller;

import com.kii.potal.admin.user.dto.UserDTO;
import com.kii.potal.admin.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class UserController {

    @Autowired
    UserService userService;

    /**
     * 사용자 리스트 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 사용자 리스트 정보
     * @throws Exception
     */
    @RequestMapping(value = "/admin/userList.do")
    public String getUserList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        UserDTO userDTO = new UserDTO();
        //사용자 리스트

        model.addAttribute("list",userService.getUserList(userDTO));
        return "admin/user/user_list";
    }

    /**
     * 사용자 상세 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 사용자 리스트 정보
     * @throws Exception
     */
    @RequestMapping(value = "/admin/userView.do")
    public String getUserItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        UserDTO userDTO = new UserDTO();
        //사용자 상세 정보
        String userId = (String) request.getAttribute("user_id");
        userDTO.setUsrId(userId);
        userService.getUserItem(userDTO);

        return "admin/user/user_view";
    }

    /**
     * 사용자 업데이트 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 사용자 리스트 정보
     * @throws Exception
     */
    @RequestMapping(value = "/admin/userUpdate.do", method = RequestMethod.POST)
    public String updateUserItem(HttpServletRequest request, HttpServletResponse response, Model model, UserDTO userDTO) throws Exception {


        String userId = (String) request.getAttribute("user_id");

        userService.updateUserItem(userDTO);

        return "admin/user/user_view";
    }

    /**
     * 사용자 회원가입 삽입
     * @param model
     * @param request
     * @param response
     * @return 사용자 리스트 정보
     * @exception Exception
     */
    @RequestMapping(value="/admin/insertUserItem.do",method = RequestMethod.POST)
    public String insertUserItem(HttpServletRequest request, HttpServletResponse response, Model model, UserDTO userDTO) throws Exception {

        String userId = (String)request.getAttribute("user_id");
        userDTO.setUsrId(userId);
        userService.getUserItem(userDTO);

        return "user/sign_up";
    }


    /**
     * 사용자 로그인 화면
     * @param model
     * @param request
     * @param response
     * @return 사용자 로그인 화면
     * @exception Exception
     */
    @RequestMapping(value="/login.do",method = RequestMethod.GET)
    public String login(HttpServletRequest request, HttpServletResponse response, Model model, UserDTO userDTO) throws Exception {

        String userId = (String)request.getAttribute("user_id");
        userDTO.setUsrId(userId);
        userService.getUserItem(userDTO);

        return "user/login_view";
    }

    /**
     * 사용자 로그인 화면
     * @param model
     * @param request
     * @param response
     * @return 사용자 로그인 화면
     * @exception Exception
     */
    @RequestMapping(value="/signUp.do",method = RequestMethod.GET)
    public String signUp(HttpServletRequest request, HttpServletResponse response, Model model, UserDTO userDTO) throws Exception {

        String userId = (String)request.getAttribute("user_id");
        userDTO.setUsrId(userId);
        userService.getUserItem(userDTO);

        return "user/sign_up";
    }

    /**
     * 사용자 로그인 프로세스
     * @param model
     * @param request
     * @param response
     * @return 사용자 로그인 프로세스
     * @exception Exception
     */
    @RequestMapping(value="/loginProc.do",method = RequestMethod.POST)
    public String loginProc(HttpServletRequest request, HttpServletResponse response, Model model, UserDTO userDTO) throws Exception {

        String userId = (String)request.getAttribute("user_id");
        userDTO.setUsrId(userId);
        userService.getUserItem(userDTO);

        return "redirect:/admin/main.do";
    }





}
