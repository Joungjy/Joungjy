package com.kii.potal.core.code;

public enum PeriodType {
    HOUR("시간별", "HOUR"),
    DAY("일별", "DAY"),
    WEEK("주별", "WEEK"),
    MONTH("월별", "MOdNTH"),
    QUARTER("분기별", "QUARTER"),
    YEAR("년별", "YEAR");

    private final String name;
    private final String value;

    PeriodType(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return this.name;
    }

    public String getValue() {
        return this.value;
    }

}
