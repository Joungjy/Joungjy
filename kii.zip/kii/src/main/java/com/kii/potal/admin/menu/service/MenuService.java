package com.kii.potal.admin.menu.service;

import com.kii.potal.admin.menu.dto.MenuDTO;

import java.util.List;

public interface MenuService {

    //메뉴 리스트
    List<MenuDTO> getMenuList(MenuDTO menuDTO);
    //메뉴 정보
    MenuDTO getMenuItem(MenuDTO menuDTO);
    //메뉴 정보 삽입
    void insertMenuItem(MenuDTO menuDTO);
    //메뉴 정보 업데이트
    void updateMenuItem(MenuDTO menuDTO);
    //메뉴 정보 삭제
    void deleteMenuItem(MenuDTO menuDTO);

}
