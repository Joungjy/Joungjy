package com.kii.potal.admin.systemhist.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SystemHistDTO {

    private String syslogId;    //시스템이력아이디
    private String usrNo;       //사용자 번호
    private String action;      //사용자 액션
    private String dscriptoin;  //시스템이력 설명
    private String registDt;    //등록일시

}
