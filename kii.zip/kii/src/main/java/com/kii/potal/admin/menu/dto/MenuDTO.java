package com.kii.potal.admin.menu.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MenuDTO {
    private Long menuId;        //메뉴번호
    private String menuNm;      //메뉴명
    private String description;     //메뉴설명
    private String upMenuNo;        //상위 메뉴 번호
    private String viewYn;      //메뉴 보기 여부
    private String link;        //메뉴 링크
    private String aprcAthrNo;      //메뉴접근권한번호
    private String sort;        //메뉴정렬
    private String registDt;        //등록일시
    private String registUsrNo;     //등록자번호
    private String updtDt;      //수정일시
    private String updusrNo;        //수정자번호
    private String delDt;       //삭제일시
    private String dltrNo;      //삭제자번호
    private String delYn;       //삭제여부

}
