package com.kii.potal.admin.eqptag.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EqpTagDTO {

    private String tagId;       //태그아이디
    private String tagNm;       //태그명
    private String tagType;     //태그유형
    private String x;           //x좌표
    private String y;           //y좌표
    private String z;           //z좌표
    private String dtCor;       //DT색상
    private String dtNm;        //DT명칭
    private String colType;     //수집 유형
    private String registDt;    //등록일
    private String regstrNo;    //등록자 번호
    private String updtDt;      //수정일
    private String updtNo;      //수정자 번호
    private String delDt;       //삭제일시
    private String dltrNo;      //삭제자번호
    private String delYn;       //삭제여부

}
