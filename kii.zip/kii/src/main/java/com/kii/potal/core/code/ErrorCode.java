package com.kii.potal.core.code;

import lombok.Getter;

@Getter
public enum ErrorCode {

    INVALID_PARAMETER(400, "C000", "Invalid Input value"),
    NOT_FOUND_USER_INFO(401, "C001", "사용자 정보를 찾을 수 없습니다."),
    METHOD_NOT_ALLOWED(402, "C002", "Invalid Input value"),
    HANDLE_ACCESS_DENIED(403, "C003", "Access is Denied"),
    LOGIN_INPUT_INVALID(400, "M001", "Login input is invalid"),
    LOGIN_ACCESS_TOKEN_EXPIRED(419, "M019", "Login Access Token Expired");

    private final String code;
    private final String message;
    private int status;

    ErrorCode(final int status, final String code, final String message) {
        this.status = status;
        this.message = message;
        this.code = code;
    }
}
