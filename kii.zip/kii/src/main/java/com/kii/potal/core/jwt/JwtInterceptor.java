package com.kii.potal.core.jwt;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.kii.potal.core.code.exception.ExpiredTokenException;
import com.kii.potal.core.util.DataStringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtInterceptor implements HandlerInterceptor {

    private final JwtUtil jwtUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        // prelight를 위한 OPTIONS 요청은 그냥 전달
        if (request.getMethod().equals("OPTIONS")) {
            return true;
        } else if (request.getRequestURI().contains("/api/wtqlt/national")) {
            log.info("=================================================> passed");
            return true;
        }

        // request의 헤더에서 jwt-auth-token으로 넘어온 정보를 찾는다.
        String accessToken = request.getHeader("x-access-token");
        String refreshToken = request.getHeader("x-refresh-token");
        log.info("======================================== JwtInterceptor ======================================");
        log.info("accessToken : {}", accessToken);
        log.info("refreshToken : {}", refreshToken);
        log.info("경로 : {}, 토큰 : {}", request.getServletPath(), accessToken);

        if (accessToken != null && refreshToken != null) {
            if (DataStringUtil.isNotEmpty(accessToken) && accessToken != null) {
                log.info("accessToken : {}", accessToken);
                // 유효한 토큰이면 진행, 그렇지 않으면 예외를 발생시킨다.
                Map<String, Object> userInfo = jwtUtil.checkAndGetClaims(accessToken);



            } else {
                throw new ExpiredTokenException("인증 토큰이 없습니다.");
            }
        } else if (accessToken == null && refreshToken != null) {
            throw new ExpiredTokenException("인증 토큰이 없습니다.");
        }
        return true;
    }
}
