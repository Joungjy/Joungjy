package com.kii.potal.admin.eqptag.service.impl;

import com.kii.potal.admin.eqptag.dto.EqpTagDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface EqpTagMapper {
    //태그 관리 정보 리스트 조회
    List<EqpTagDTO> getEqpTagList(EqpTagDTO eqpTagDTO) throws Exception;

    //태그 관리 정보 등록
    void insertEqpTagItem (EqpTagDTO eqpTagDTO) throws Exception;

    //태그 관리 정보 수정
    void updateEqpTagItem(EqpTagDTO eqpTagDTO) throws Exception;

    //태그 관리 정보 삭제
    void deleteEqpTagItem(EqpTagDTO eqpTagDTO) throws Exception;
}
