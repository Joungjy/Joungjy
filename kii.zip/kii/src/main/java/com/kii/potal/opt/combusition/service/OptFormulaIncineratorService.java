package com.kii.potal.opt.combusition.service;

import java.util.HashMap;
import java.util.List;

import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;

public interface OptFormulaIncineratorService {
	HashMap hb_10_inci(HashMap map)throws Exception;
	HashMap hb_20_inci(HashMap map)throws Exception;
	HashMap hb_30_inci(HashMap map)throws Exception;
	HashMap hb_40_inci(HashMap map)throws Exception;
	
}
