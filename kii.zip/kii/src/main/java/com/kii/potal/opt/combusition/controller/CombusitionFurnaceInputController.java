package com.kii.potal.opt.combusition.controller;



import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.kii.potal.admin.user.dto.UserDTO;
import com.kii.potal.admin.user.service.UserService;
import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaCpService;
import com.kii.potal.opt.combusition.service.OptFormulaElement2Service;
import com.kii.potal.opt.combusition.service.OptFormulaElement3Service;
import com.kii.potal.opt.combusition.service.OptFormulaElementService;
import com.kii.potal.opt.combusition.service.OptService;
import com.kii.potal.opt.combusition.service.impl.OptFormulaBfServiceImpl;
import com.kii.potal.opt.combusition.service.impl.OptFormulaIncineratorServiceImpl;
import com.kii.potal.opt.combusition.service.impl.OptFormulaScrServiceImpl;
import com.kii.potal.opt.combusition.service.impl.OptFormulaSdrServiceImpl;
import com.kii.potal.opt.combusition.service.impl.OptFormulaWsServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class CombusitionFurnaceInputController {

    @Autowired
    OptService optService;

    @Autowired
    OptFormulaElementService optFormulaElementService;
    
    @Autowired
    OptFormulaElement2Service optFormulaElement2Service;
    
    @Autowired
    OptFormulaElement3Service optFormulaElement3Service;
    
    @Autowired
    OptFormulaIncineratorServiceImpl optFormulaIncineratorServiceImpl;
    
    @Autowired
    OptFormulaSdrServiceImpl optFormulaSdrServiceImpl;
    
    @Autowired
    OptFormulaScrServiceImpl optFormulaScrServiceImpl;
    
    @Autowired
    OptFormulaWsServiceImpl optFormulaWsServiceImpl;
    
    
    @Autowired
    OptFormulaBfServiceImpl optFormulaBfServiceImpl;
    
    
    @Autowired
    OptFormulaCpService optFormulaCpService;
    
    /**
     * 사용자 리스트 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 사용자 리스트 정보
     * @throws Exception
     */
    @RequestMapping(value = "/opt/initialList.do")
    public String initialList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        UserDTO userDTO = new UserDTO();
        //사용자 리스트
        List list = new ArrayList();
        //wpid : 1213 -- 설계값
        //wpid : 1214 -- 실측값
        
        // : 불연분
        // : 탄소(C)
        // : 수소(H)
        // : 산소(O)
        // : 질소(N)
        // : 황(S)
        // : 염소(CL)
        Map pmap = new HashMap();
        /*******************************************************
         * 설계값
         **********************************************************/
        pmap.put("wpid", "1213");
        //1100 : 수분(H2O)
        pmap.put("code", "1100");
        model.addAttribute("list_1213_1100",optService.getElementin(pmap));
        //불연분
        pmap.put("code", "1101");
        model.addAttribute("list_1213_1101",optService.getElementin(pmap));
        //탄소(C)
        pmap.put("code", "1102");
        model.addAttribute("list_1213_1102",optService.getElementin(pmap));
        //수소(H)
        pmap.put("code", "1103");
        model.addAttribute("list_1213_1103",optService.getElementin(pmap));
        //산소(O)
        pmap.put("code", "1104");
        model.addAttribute("list_1213_1104",optService.getElementin(pmap));
        //질소(N)
        pmap.put("code", "1105");
        model.addAttribute("list_1213_1105",optService.getElementin(pmap));
        //황(S)
        pmap.put("code", "1106");
        model.addAttribute("list_1213_1106",optService.getElementin(pmap));
        //염소(CL)
        pmap.put("code", "1107");
        model.addAttribute("list_1213_1107",optService.getElementin(pmap));
        //소각량
        pmap.put("code", "1200");
        model.addAttribute("list_1213_1200",optService.getElementin(pmap));
        //과잉공기비
        pmap.put("code", "1201");
        model.addAttribute("list_1213_1201",optService.getElementin(pmap));
        
        
        //폐기물 투입 온도
        pmap.put("code", "2400");
        model.addAttribute("list_1213_2400",optService.getPipeadd(pmap));
        //연소용 공기 온도
        pmap.put("code", "2401");
        model.addAttribute("list_1213_2401",optService.getPipeadd(pmap));
        //필요 공기공급 비율 70%
        pmap.put("code", "2402");
        model.addAttribute("list_1213_2402",optService.getPipeadd(pmap));

        //2차 연소공기 공급비율
        pmap.put("code", "2501");
        model.addAttribute("list_1213_2501",optService.getPipeadd(pmap));

        //sncr urea tank 농도
        pmap.put("code", "2509");
        model.addAttribute("list_1213_2509",optService.getPipeadd(pmap));

        //sncr urea spray 농도
        pmap.put("code", "2510");
        model.addAttribute("list_1213_2510",optService.getPipeadd(pmap));
        //출구 배출가스 설계온도
        pmap.put("code", "2600");
        model.addAttribute("list_1213_2600",optService.getPipeadd(pmap));
        //spray water 투입온도
        pmap.put("code", "2001");
        model.addAttribute("list_1213_2001",optService.getPipeadd(pmap));
        //출구가스 설계온도
        pmap.put("code", "2004");
        model.addAttribute("list_1213_2004",optService.getPipeadd(pmap));
        //공기 주입 유량/노즐
        pmap.put("code", "2200");
        model.addAttribute("list_1213_2200",optService.getPipeadd(pmap));
        
        
        //드럼 블로다운율
        pmap.put("code", "603");
        model.addAttribute("list_1213_603",optService.getConstant(pmap));
        //dust 제거효율
        pmap.put("code", "302");
        model.addAttribute("list_1213_302",optService.getConstant(pmap));        
        
        
        
        
        /*******************************************************
         * 실측값
         **********************************************************/
        pmap.put("wpid", "1214");
        //1100 : 수분(H2O)
        pmap.put("code", "1100");
        model.addAttribute("list_1214_1100",optService.getElementin(pmap));
        //불연분
        pmap.put("code", "1101");
        model.addAttribute("list_1214_1101",optService.getElementin(pmap));
        //탄소(C)
        pmap.put("code", "1102");
        model.addAttribute("list_1214_1102",optService.getElementin(pmap));
        //수소(H)
        pmap.put("code", "1103");
        model.addAttribute("list_1214_1103",optService.getElementin(pmap));
        //산소(O)
        pmap.put("code", "1104");
        model.addAttribute("list_1214_1104",optService.getElementin(pmap));
        //질소(N)
        pmap.put("code", "1105");
        model.addAttribute("list_1214_1105",optService.getElementin(pmap));
        //황(S)
        pmap.put("code", "1106");
        model.addAttribute("list_1214_1106",optService.getElementin(pmap));
        //염소(CL)
        pmap.put("code", "1107");
        model.addAttribute("list_1214_1107",optService.getElementin(pmap));
        //소각량
        pmap.put("code", "1200");
        model.addAttribute("list_1214_1200",optService.getElementin(pmap));
        //과잉공기비
        pmap.put("code", "1201");
        model.addAttribute("list_1214_1201",optService.getElementin(pmap));
        
        
      //폐기물 투입 온도
        pmap.put("code", "2400");
        model.addAttribute("list_1213_2400",optService.getPipeadd(pmap));
        //연소용 공기 온도
        pmap.put("code", "2401");
        model.addAttribute("list_1213_2401",optService.getPipeadd(pmap));
        //필요 공기공급 비율 70%
        pmap.put("code", "2402");
        model.addAttribute("list_1213_2402",optService.getPipeadd(pmap));

        //2차 연소공기 공급비율
        pmap.put("code", "2501");
        model.addAttribute("list_1213_2501",optService.getPipeadd(pmap));

        //sncr urea tank 농도
        pmap.put("code", "2509");
        model.addAttribute("list_1213_2509",optService.getPipeadd(pmap));

        //sncr urea spray 농도
        pmap.put("code", "2510");
        model.addAttribute("list_1213_2510",optService.getPipeadd(pmap));
        //출구 배출가스 설계온도
        pmap.put("code", "2600");
        model.addAttribute("list_1213_2600",optService.getPipeadd(pmap));
        //spray water 투입온도
        pmap.put("code", "2001");
        model.addAttribute("list_1213_2001",optService.getPipeadd(pmap));
        //출구가스 설계온도
        pmap.put("code", "2004");
        model.addAttribute("list_1213_2004",optService.getPipeadd(pmap));
        //공기 주입 유량/노즐
        pmap.put("code", "2200");
        model.addAttribute("list_1213_2200",optService.getPipeadd(pmap));
        
      //드럼 블로다운율
        pmap.put("code", "603");
        model.addAttribute("list_1213_603",optService.getConstant(pmap));
        //dust 제거효율
        pmap.put("code", "302");
        model.addAttribute("list_1213_302",optService.getConstant(pmap));        
        
        
        return "admin/user/user_list";
    }
    private String convertNullToString(JsonElement ele) {
		if(ele == null) {
			return "";
		}
		return ele.getAsString();
	}
    /**
     * 사용자 리스트 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 사용자 리스트 정보
     * @throws Exception
     */
    @RequestMapping(value = "/opt/saveList.do")
    public String saveList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

    	String rows = request.getParameter("saveRows");
		
		
		JsonParser parser = new JsonParser();		
		JsonArray dataList = (JsonArray) parser.parse(rows);

		for(int i=0; i < dataList.size(); i++) {
			JsonElement ele = dataList.get(i);
			String idx = convertNullToString(ele.getAsJsonObject().get("idx"));
			String wpid = convertNullToString(ele.getAsJsonObject().get("wpid"));
			String groupcd = convertNullToString(ele.getAsJsonObject().get("groupcd"));
			String code = convertNullToString(ele.getAsJsonObject().get("code"));
			String name = convertNullToString(ele.getAsJsonObject().get("name"));
			String fieldnm = convertNullToString(ele.getAsJsonObject().get("fieldnm"));
			String statecd = convertNullToString(ele.getAsJsonObject().get("statecd"));
			String value = convertNullToString(ele.getAsJsonObject().get("value"));
			//String actval = convertNullToString(ele.getAsJsonObject().get("actval"));
			String unit = convertNullToString(ele.getAsJsonObject().get("unit"));
			String color = convertNullToString(ele.getAsJsonObject().get("color"));
			Map map = new HashMap();
			map.put("idx", idx);
			map.put("wpid", wpid);
			map.put("groupcd", groupcd);
			map.put("code", code);
			map.put("name", name);
			map.put("fieldnm", fieldnm);
			map.put("statecd", statecd);
			map.put("value", value);
			map.put("unit", unit);
			map.put("color", color);
			
			
			if("1100".equals(code)
					|| "1101".equals(code)
					|| "1102".equals(code)
					|| "1103".equals(code)
					|| "1104".equals(code)
					|| "1105".equals(code)
					|| "1106".equals(code)
					|| "1107".equals(code)
					|| "1200".equals(code)
					|| "1201".equals(code)
					) {
				optService.delElementin(map);
				optService.insertElementin(map);
			} else if("2400".equals(code)
					|| "2401".equals(code)
					|| "2402".equals(code)
					|| "2501".equals(code)
					|| "2509".equals(code)
					|| "2510".equals(code)
					|| "2600".equals(code)
					|| "2001".equals(code)
					|| "2004".equals(code)
					|| "2200".equals(code)
					)	{
				optService.delPipeadd(map);
				optService.insertPipeadd(map);
			} else if("603".equals(code)
					|| "302".equals(code)
					)	{
				optService.delConstant(map);
				optService.insertConstant(map);
			}

		}
		HashMap pmap = new HashMap();
//		formula_element
		pmap.put("wpid", OptConstant.WPID);
		pmap.put("groupcd", "5001");
		List<CombusitionPipeOutDTO> el1list = optService.getPipeoutBygroupcd(pmap);
		
		
		pmap = optFormulaElementService.waste(pmap,el1list);
		pmap = optFormulaElementService.dry_waste(pmap,el1list);
		pmap = optFormulaElementService.hhv_drywaste(pmap,el1list);
		pmap = optFormulaElementService.hhv_waste(pmap,el1list);
		pmap = optFormulaElementService.lhv_waste(pmap,el1list);
		
//		formula_element2
		pmap = optFormulaElement2Service.waste(pmap);
		
//		formula_element3		
		pmap = optFormulaElement3Service.waste(pmap);

//		formula_cp
		List<CombusitionCpDTO> cplist = optService.getCp(pmap);
		List<CombusitionCpDTO> calc1list = optFormulaCpService.calc_mix_gas(cplist);
		optFormulaCpService.calc_slope(calc1list);
		

//		formula_incinerator
		pmap.put("groupcd", "6100");
		List<CombusitionPipeOutDTO> incilist = optService.getPipeoutBygroupcd(pmap);
		pmap = optFormulaIncineratorServiceImpl.hb_10_inci(pmap);
		pmap = optFormulaIncineratorServiceImpl.hb_20_inci(pmap);
		pmap = optFormulaIncineratorServiceImpl.hb_30_inci(pmap);
		pmap = optFormulaIncineratorServiceImpl.hb_40_inci(pmap);
		
		
//		formula_sdr
		pmap = optFormulaSdrServiceImpl.module_sdr(pmap);
//		formula_bf
		pmap = optFormulaBfServiceImpl.mb_1_1_bf(pmap);
		pmap = optFormulaBfServiceImpl.mb_2_1_bf(pmap);
		pmap = optFormulaBfServiceImpl.mb_2_3_bf(pmap);
		pmap = optFormulaBfServiceImpl.mb_2_4_bf(pmap);
		pmap = optFormulaBfServiceImpl.hb_1_bf(pmap);
		pmap = optFormulaBfServiceImpl.hb_1_bf(pmap);
		pmap = optFormulaBfServiceImpl.mb_2_5_bf(pmap);
		pmap = optFormulaBfServiceImpl.mb_3_1_bf(pmap);
		pmap = optFormulaBfServiceImpl.bf_design(pmap);
		
//		formula_scr
		pmap = optFormulaScrServiceImpl.mb_1_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_2_1_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_2_2_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_2_3_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_3_1_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_3_2_scr(pmap);
		pmap = optFormulaScrServiceImpl.hb_1_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_4_scr(pmap);
		pmap = optFormulaScrServiceImpl.hb_2_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_5_1_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_5_2_scr(pmap);
		pmap = optFormulaScrServiceImpl.mb_5_3_scr(pmap);
		pmap = optFormulaScrServiceImpl.etc_scr(pmap);
		pmap = optFormulaScrServiceImpl.scr_design(pmap);
//		formula_ws      
		pmap = optFormulaWsServiceImpl.mb_1_1_ws(pmap);
		pmap = optFormulaWsServiceImpl.mb_1_2_ws(pmap);
		pmap = optFormulaWsServiceImpl.hb_1_ws(pmap);
		pmap = optFormulaWsServiceImpl.mb_1_3_ws(pmap);
		pmap = optFormulaWsServiceImpl.mb_1_4_ws(pmap);
		pmap = optFormulaWsServiceImpl.hb_2_ws(pmap);
		pmap = optFormulaWsServiceImpl.mb_2_ws(pmap);
		pmap = optFormulaWsServiceImpl.mb_3_ws(pmap);
		pmap = optFormulaWsServiceImpl.etc_ws(pmap);
		pmap = optFormulaWsServiceImpl.ws_design1(pmap);
		pmap = optFormulaWsServiceImpl.ws_design2(pmap);
		pmap = optFormulaWsServiceImpl.ws_design3(pmap);
        return "admin/user/user_list";
    }

  




}
