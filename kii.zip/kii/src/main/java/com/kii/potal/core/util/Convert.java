package com.kii.potal.core.util;

import java.math.BigDecimal;

public class Convert {
    public static BigDecimal fromString(String str) {
        BigDecimal value = null;
        try {
            value = new BigDecimal(str);
        } catch (NumberFormatException e) {
            // e.printStackTrace();
            value = new BigDecimal("0");
        }
        return value;
    }
}
