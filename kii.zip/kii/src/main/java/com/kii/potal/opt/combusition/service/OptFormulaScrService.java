package com.kii.potal.opt.combusition.service;

import java.util.HashMap;

public interface OptFormulaScrService {

	HashMap mb_1_scr(HashMap map)throws Exception;
	HashMap mb_2_1_scr(HashMap map)throws Exception;
	HashMap mb_2_2_scr(HashMap map)throws Exception;
	HashMap mb_2_3_scr(HashMap map)throws Exception;
	HashMap mb_3_1_scr(HashMap map)throws Exception;
	HashMap mb_3_2_scr(HashMap map)throws Exception;
	HashMap hb_1_scr(HashMap map)throws Exception;
	HashMap mb_4_scr(HashMap map)throws Exception;
	HashMap hb_2_scr(HashMap map)throws Exception;
	HashMap mb_5_1_scr(HashMap map)throws Exception;
	HashMap mb_5_2_scr(HashMap map)throws Exception;
	HashMap mb_5_3_scr(HashMap map)throws Exception;
	HashMap etc_scr(HashMap map)throws Exception;
	HashMap scr_design(HashMap map)throws Exception;
	
}
