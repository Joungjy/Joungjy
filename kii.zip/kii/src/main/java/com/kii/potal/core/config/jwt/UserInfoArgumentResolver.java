package com.kii.potal.core.config.jwt;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.kii.potal.admin.user.dto.UserDTO;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.kii.potal.core.jwt.JwtUtil;
import com.kii.potal.core.util.MapUtil;
//import com.kii.potal.admin.user.dto.UserDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class UserInfoArgumentResolver implements HandlerMethodArgumentResolver {

    private final JwtUtil jwtUtil;


    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        boolean isJwtUserInfo = parameter.getParameterAnnotation(UserInfo.class) != null;
        return isJwtUserInfo;
    }

    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
        HttpServletRequest request =webRequest.getNativeRequest(HttpServletRequest.class);

        String accessToken = request.getHeader("x-access-token");

        log.info("x-access-token : {}", accessToken);
        Map<String, Object> userInfo = jwtUtil.checkAndGetClaims(accessToken);
        log.info("userInfo ============================> {}", userInfo);
        Long usrNo = Long.parseLong(MapUtil.getDefaultString(userInfo, "userNo", "0"));
        String usrId = MapUtil.getString(userInfo, "userId");
        String usrNm = MapUtil.getString(userInfo, "userNm");
        String athrCd = MapUtil.getString(userInfo, "athrCd");

        UserDTO userVo = UserDTO.builder().usrNo(usrNo).usrId(usrId).usrNm(usrNm).athrCd(athrCd).build();
        log.info("userVo ================> {}", userVo);
        return userVo;
    }
}
