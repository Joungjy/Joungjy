package com.kii.potal.opt.combusition.service.impl;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaElementService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaElementServiceImpl extends EgovAbstractServiceImpl implements OptFormulaElementService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap waste(HashMap pmap ,List<CombusitionPipeOutDTO> el1list) throws Exception {
		pmap.put("wpid", OptConstant.WPID);
		// TODO Auto-generated method stub
		Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		map.put("code", OptConstant.wp_c_waste);
		List<CombusitionElementInDTO> wp_c_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_h_waste);
		List<CombusitionElementInDTO> wp_h_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_o_waste);
		List<CombusitionElementInDTO> wp_o_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_n_waste);
		List<CombusitionElementInDTO> wp_n_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_s_waste);
		List<CombusitionElementInDTO> wp_s_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_cl_waste);
		List<CombusitionElementInDTO> wp_cl_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_h2o_waste);
		List<CombusitionElementInDTO> wp_h2o_waste_list =  optMapper.getElementin(map);
		map.put("code", OptConstant.wp_ash_waste);
		List<CombusitionElementInDTO> wp_ash_waste_list =  optMapper.getElementin(map);
		
		
		double wp_c_waste = wp_c_waste_list.get(0).getValue();
		double wp_h_waste = wp_h_waste_list.get(0).getValue();
		double wp_o_waste = wp_o_waste_list.get(0).getValue();
		double wp_n_waste = wp_n_waste_list.get(0).getValue();
		double wp_s_waste = wp_s_waste_list.get(0).getValue();
		double wp_cl_waste = wp_cl_waste_list.get(0).getValue();
		double wp_h2o_waste = wp_h2o_waste_list.get(0).getValue();
		double wp_ash_waste = wp_ash_waste_list.get(0).getValue();
		
		
		
		double wp_cw_waste = wp_c_waste + wp_h_waste + wp_o_waste + wp_n_waste + wp_s_waste + wp_cl_waste;
		double wp_3comp_waste = wp_cw_waste + wp_h2o_waste + wp_ash_waste;
		
		
		
		map.put("fieldnm", "wp_cw_waste");
		map.put("value", wp_cw_waste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_3comp_waste");
		map.put("value", wp_ash_waste);
		optMapper.updatePipeoutValue(map);
		
		pmap.put("wp_c_waste", wp_c_waste);
		pmap.put("wp_h_waste", wp_h_waste);
		pmap.put("wp_o_waste", wp_o_waste);
		pmap.put("wp_n_waste", wp_n_waste);
		pmap.put("wp_s_waste", wp_s_waste);
		pmap.put("wp_cl_waste", wp_cl_waste);
		pmap.put("wp_h2o_waste", wp_h2o_waste);
		pmap.put("wp_ash_waste", wp_ash_waste);
		
		return pmap;
	}

	@Override
	public HashMap dry_waste(HashMap pmap ,List<CombusitionPipeOutDTO> el1list) throws Exception {
		// TODO Auto-generated method stub
		
		Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		
		float wp_comp_drywaste =
				Float.parseFloat((String)pmap.get("wp_c_waste")) +
			     Float.parseFloat((String)pmap.get("wp_h_waste")) +
			     Float.parseFloat((String)pmap.get("wp_o_waste")) +
			     Float.parseFloat((String)pmap.get("wp_n_waste")) +
			     Float.parseFloat((String)pmap.get("wp_s_waste")) +
			     Float.parseFloat((String)pmap.get("wp_cl_waste")) +
			     Float.parseFloat((String)pmap.get("wp_ash_waste"));
		
		
		float wp_c_drywaste = (Float.parseFloat((String)pmap.get("wp_c_waste")) * 100) / wp_comp_drywaste;
	    float wp_h_drywaste = (Float.parseFloat((String)pmap.get("wp_h_waste")) * 100) / wp_comp_drywaste;
	    float wp_o_drywaste = (Float.parseFloat((String)pmap.get("wp_o_waste")) * 100) / wp_comp_drywaste;
	    float wp_n_drywaste = (Float.parseFloat((String)pmap.get("wp_n_waste")) * 100) / wp_comp_drywaste;
	    float wp_s_drywaste = (Float.parseFloat((String)pmap.get("wp_s_waste")) * 100) / wp_comp_drywaste;
	    float wp_cl_drywaste = (Float.parseFloat((String)pmap.get("wp_cl_waste")) * 100) / wp_comp_drywaste;
	    float wp_ash_drywaste = (Float.parseFloat((String)pmap.get("wp_ash_waste")) * 100) / wp_comp_drywaste;
	    
		
	    map.put("groupcd", "5001");
	    
	    map.put("fieldnm", "wp_c_drywaste");
		map.put("value", wp_c_drywaste);
		pmap.put("wp_c_drywaste", wp_c_drywaste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_h_drywaste");
		map.put("value", wp_h_drywaste);
		pmap.put("wp_h_drywaste", wp_h_drywaste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_o_drywaste");
		map.put("value", wp_o_drywaste);
		pmap.put("wp_o_drywaste", wp_o_drywaste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_n_drywaste");
		map.put("value", wp_n_drywaste);
		pmap.put("wp_n_drywaste", wp_n_drywaste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_s_drywaste");
		map.put("value", wp_s_drywaste);
		pmap.put("wp_s_drywaste", wp_s_drywaste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_cl_drywaste");
		map.put("value", wp_cl_drywaste);
		pmap.put("wp_cl_drywaste", wp_cl_drywaste);
		optMapper.updatePipeoutValue(map);
		
		map.put("fieldnm", "wp_ash_drywaste");
		map.put("value", wp_ash_drywaste);
		pmap.put("wp_ash_drywaste", wp_ash_drywaste);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap hhv_drywaste(HashMap pmap ,List<CombusitionPipeOutDTO> el1list) throws Exception {
		// TODO Auto-generated method stub
		
		float hhv_drywaste =
			      (8100 * Float.parseFloat((String)pmap.get("wp_c_drywaste")) +
			        2500 * Float.parseFloat((String)pmap.get("wp_s_drywaste")) +
			        34000 * (Float.parseFloat((String)pmap.get("wp_h_drywaste")) - Float.parseFloat((String)pmap.get("wp_o_drywaste")) / 8)) /
			      100;

	    Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
	    map.put("fieldnm", "hhv_drywaste");
		map.put("value", hhv_drywaste);
		pmap.put("hhv_drywaste", hhv_drywaste);
		optMapper.updatePipeoutValue(map);
				
				
		
		return pmap;
	}

	@Override
	public HashMap hhv_waste(HashMap pmap ,List<CombusitionPipeOutDTO> el1list) throws Exception {
		// TODO Auto-generated method stub
		float hhv_waste =
			      (8100 * Float.parseFloat((String)pmap.get("wp_c_waste")) +
			        2500 * Float.parseFloat((String)pmap.get("wp_s_waste")) +
			        34000 * (Float.parseFloat((String)pmap.get("wp_h_waste")) - Float.parseFloat((String)pmap.get("wp_o_waste")) / 8)) /
			      100;

		Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
	    map.put("fieldnm", "hhv_waste");
		map.put("value", hhv_waste);
		pmap.put("hhv_waste", hhv_waste);
		optMapper.updatePipeoutValue(map);
		
		return pmap;
	}

	@Override
	public HashMap lhv_waste(HashMap pmap ,List<CombusitionPipeOutDTO> el1list) throws Exception {
		// TODO Auto-generated method stub
		
		float lhv_waste =
				Float.parseFloat((String)pmap.get("hhv_waste")) - 600 * ((9 * Float.parseFloat((String)pmap.get("wp_h_waste")) + Float.parseFloat((String)pmap.get("wp_h2o_waste"))) / 100);

			    // store to db
		
		Map map = new HashMap();
		map.put("wpid", OptConstant.WPID);
	    map.put("fieldnm", "lhv_waste");
		map.put("value", lhv_waste);
		pmap.put("lhv_waste", lhv_waste);
		optMapper.updatePipeoutValue(map);
		return pmap;
	}


}
