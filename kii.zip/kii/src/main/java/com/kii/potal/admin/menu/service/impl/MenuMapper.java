package com.kii.potal.admin.menu.service.impl;

import com.kii.potal.admin.menu.dto.MenuDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface MenuMapper {

    //메뉴 리스트
    List<MenuDTO> getMenuList(MenuDTO menuDTO);
    //메뉴 정보
    MenuDTO getMenuItem(MenuDTO menuDTO);
    //메뉴 정보 삽입
    void insertMenuItem(MenuDTO menuDTO);
    //메뉴 정보 업데이트
    void updateMenuItem(MenuDTO menuDTO);
    //메뉴 정보 삭제
    void deleteMenuItem(MenuDTO menuDTO);
}
