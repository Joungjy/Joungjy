package com.kii.potal.admin.code.controller;

import com.kii.potal.admin.code.dto.CodeDTO;
import com.kii.potal.admin.code.service.CodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class CodeController {

    @Autowired
    CodeService codeService;

    /**
     * 코드 리스트 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 리스트 정보 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeList.do", method = RequestMethod.GET)
    public String getCodeList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.getCodeList(codeDTO);

        return "admin/code/code_list";
    }


    /**
     * 코드 상세 정보
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 상세 정보 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeView.do", method = RequestMethod.GET)
    public String getCodeItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.getCodeItem(codeDTO);

        return "admin/code/code_view";
    }


    /**
     * 코드 정보 등록
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 정보 등록 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeInsert.do", method = RequestMethod.GET)
    public String inserCodeItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.getCodeItem(codeDTO);

        return "admin/code/code_insert";
    }
    /**
     * 코드 정보 등록
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 정보 등록 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeInsertProc.do", method = RequestMethod.POST)
    public String inserCodeItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.insertCodeItem(codeDTO);

        return "redirect:/admin/codeInsert.do";
    }

    /**
     * 코드 정보 수정
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 정보 수정 페이지
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeUpdate.do", method = RequestMethod.GET)
    public String updateCodeItem(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.getCodeItem(codeDTO);

        return "admin/code/code_update";
    }

    /**
     * 코드 정보 수정 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 정보 수정 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeUpdateProc.do", method = RequestMethod.POST)
    public String updateCodeItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.getCodeItem(codeDTO);

        return "redirect:/admin/codeUpdate.do";
    }

    /**
     * 코드 정보 삭제 프로세스
     *
     * @param model
     * @param request
     * @param response
     * @return 코드 정보 삭제 프로세스
     * @throws Exception
     */
    @RequestMapping(value = "/admin/codeDeleteProc.do", method = RequestMethod.GET)
    @ResponseBody
    public String deleteCodeItemProc(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {

        CodeDTO codeDTO = new CodeDTO();
        codeService.deleteCodeItem(codeDTO);

        return "json";
    }

    




}
