package com.kii.potal.opt.combusition.service.impl;



import java.util.HashMap;
import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kii.potal.opt.combusition.dto.CombusitionConsTantDTO;
import com.kii.potal.opt.combusition.dto.CombusitionCpDTO;
import com.kii.potal.opt.combusition.dto.CombusitionElementInDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeAddDTO;
import com.kii.potal.opt.combusition.dto.CombusitionPipeOutDTO;
import com.kii.potal.opt.combusition.dto.OptConstant;
import com.kii.potal.opt.combusition.service.OptFormulaSdrService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptFormulaSdrServiceImpl extends EgovAbstractServiceImpl implements OptFormulaSdrService {

    @Autowired
    OptMapper optMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public HashMap module_sdr(HashMap pmap) throws Exception {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("wpid", OptConstant.WPID);
		 
		map.put("fieldnm", "qout3_gas_outblr");
		List<CombusitionPipeOutDTO>qout3_gas_outblr_list = optMapper.getPipeoutByField(map);
		double q_gas_inSDR = qout3_gas_outblr_list.get(0).getValue();
			   
		map.put("fieldnm", "t_gas_outblr");
		List<CombusitionPipeOutDTO> t_gas_outblr_list = optMapper.getPipeoutByField(map);
		double t_gas_inSDR = t_gas_outblr_list.get(0).getValue();
			   
		 map.put("fieldnm", "vflow_gas_outblr");
			List<CombusitionPipeOutDTO>vflow_gas_outblr_list = optMapper.getPipeoutByField(map);
			double vflow_gas_inSDR = vflow_gas_outblr_list.get(0).getValue();
			   
		 map.put("fieldnm", "vflow_co2_outblr");
			List<CombusitionPipeOutDTO>vflow_co2_outblr_list = optMapper.getPipeoutByField(map);
			double vflow_co2_inSDR = vflow_co2_outblr_list.get(0).getValue();
			   
		 map.put("fieldnm", "vflow_n2_outblr");
			List<CombusitionPipeOutDTO>vflow_n2_outblr_list = optMapper.getPipeoutByField(map);
			double vflow_n2_inSDR = vflow_n2_outblr_list.get(0).getValue();
			   
		 map.put("fieldnm", "vflow_o2_outblr");
			List<CombusitionPipeOutDTO>vflow_o2_outblr_list = optMapper.getPipeoutByField(map);
			double vflow_o2_inSDR = vflow_o2_outblr_list.get(0).getValue();
			   
		 map.put("fieldnm", "vflow_h2o_outblr");
			List<CombusitionPipeOutDTO>vflow_h2o_outblr_list = optMapper.getPipeoutByField(map);
			double vflow_h2o_inSDR = vflow_h2o_outblr_list.get(0).getValue();
			   
		 
		 map.put("fieldnm", "vflow_so2_outblr");
			List<CombusitionPipeOutDTO>vflow_so2_outblr_list = optMapper.getPipeoutByField(map);
			double vflow_so2_inSDR = vflow_so2_outblr_list.get(0).getValue();
			
		map.put("fieldnm", "vflow_hcl_outblr");
		List<CombusitionPipeOutDTO>vflow_hcl_outblr_list = optMapper.getPipeoutByField(map);
		double vflow_hcl_inSDR = vflow_hcl_outblr_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_no2_outblr");
		List<CombusitionPipeOutDTO>vppm_no2_outblr_list = optMapper.getPipeoutByField(map);
		double vppm_no2_inSDR = vppm_no2_outblr_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_co_outblr");
		List<CombusitionPipeOutDTO>vppm_co_outblr_list = optMapper.getPipeoutByField(map);
		double vppm_co_inSDR = vppm_co_outblr_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_so2_outblr");
		List<CombusitionPipeOutDTO>vppm_so2_outblr_list = optMapper.getPipeoutByField(map);
		double vppm_so2_inSDR = vppm_so2_outblr_list.get(0).getValue();
		
		map.put("fieldnm", "vppm_hcl_outblr");
		List<CombusitionPipeOutDTO>vppm_hcl_outblr_list = optMapper.getPipeoutByField(map);
		double vppm_hcl_inSDR = vppm_hcl_outblr_list.get(0).getValue();
		
		map.put("fieldnm", "qout11_flyash_waste_outblr");
		List<CombusitionPipeOutDTO>qout11_flyash_waste_outblr_list = optMapper.getPipeoutByField(map);
		double q_flyash_waste_inSDR = qout11_flyash_waste_outblr_list.get(0).getValue();
		
		map.put("fieldnm", "qout12_flyash_ubw_outblr");
		List<CombusitionPipeOutDTO>qout12_flyash_ubw_outblr_list = optMapper.getPipeoutByField(map);
		double q_flyash_ubw_inSDR = qout12_flyash_ubw_outblr_list.get(0).getValue();
		
	    map.put("fieldnm", "mflow_flyash_waste_outblr");
		List<CombusitionPipeOutDTO>mflow_flyash_waste_outblr_list = optMapper.getPipeoutByField(map);
		double mflow_flyash_waste_inSDR = mflow_flyash_waste_outblr_list.get(0).getValue();
		
	    map.put("fieldnm", "mflow_flyash_ubw_outblr");
		List<CombusitionPipeOutDTO>mflow_flyash_ubw_outblr_list = optMapper.getPipeoutByField(map);
		double mflow_flyash_ubw_inSDR = mflow_flyash_ubw_outblr_list.get(0).getValue();
			
			
		    
		    
		    
		    
		    map.put("fieldnm", "mflow_waste");
			List<CombusitionElementInDTO> mflow_waste_list = optMapper.getElementinByname(map);
			double  mflow_waste = mflow_waste_list.get(0).getValue();
			
		    // temp
		    // const mflow_dust_inSDR = mflow_flyash_waste_inSDR + mflow_flyash_ubw_inSDR;
		    map.put("fieldnm", "mpv_dioxin_outblr");
			List<CombusitionPipeOutDTO>mpv_dioxin_outblr_list = optMapper.getPipeoutByField(map);
			double mpv_dioxin_inSDR = mpv_dioxin_outblr_list.get(0).getValue();
			
		    // pipe add (func: return value)
		    map.put("fieldnm", "t_dgngas_outSDR");
			List<CombusitionPipeAddDTO> t_dgngas_outSDR_list = optMapper.getPipeaddByname(map);
			double t_dgngas_outSDR = t_dgngas_outSDR_list.get(0).getValue();
			
		    map.put("fieldnm", "cct_cao2h2_inSDR");
			List<CombusitionPipeAddDTO> cct_cao2h2_inSDR_list = optMapper.getPipeaddByname(map);
			double cct_cao2h2_inSDR = cct_cao2h2_inSDR_list.get(0).getValue();

			map.put("fieldnm", "t_wtr_inSDR");
			List<CombusitionPipeAddDTO> t_wtr_inSDR_list = optMapper.getPipeaddByname(map);
			double t_wtr_inSDR = t_wtr_inSDR_list.get(0).getValue();

			map.put("fieldnm", "t_air_inSDR");
			List<CombusitionPipeAddDTO> t_air_inSDR_list = optMapper.getPipeaddByname(map);
			double t_air_inSDR = t_air_inSDR_list.get(0).getValue();

			map.put("fieldnm", "mps_gasvel_SDR");
			List<CombusitionPipeAddDTO> mps_gasvel_SDR_list = optMapper.getPipeaddByname(map);
			double mps_gasvel_SDR = mps_gasvel_SDR_list.get(0).getValue();

			map.put("fieldnm", "sec_mrt_SDR");
			List<CombusitionPipeAddDTO> sec_mrt_SDR_list = optMapper.getPipeaddByname(map);
			double sec_mrt_SDR = sec_mrt_SDR_list.get(0).getValue();

			map.put("fieldnm", "k1_hclncacl2_SDR");
			List<CombusitionConsTantDTO> k1_hclncacl2_SDR_list =  optMapper.getConstantByField(map);
			double k1_hclncacl2_SDR = k1_hclncacl2_SDR_list.get(0).getValue();
			
			map.put("fieldnm", "k2_hclncao2h2_SDR");
			List<CombusitionConsTantDTO> k2_hclncao2h2_SDR_list =  optMapper.getConstantByField(map);
			double k2_hclncao2h2_SDR = k2_hclncao2h2_SDR_list.get(0).getValue();
			
			map.put("fieldnm", "k3_elso2_SDR");
			List<CombusitionConsTantDTO> k3_elso2_SDR_list =  optMapper.getConstantByField(map);
			double k3_elso2_SDR = k3_elso2_SDR_list.get(0).getValue();
			
		    map.put("fieldnm", "k4_elhcl_SDR");
			List<CombusitionConsTantDTO> k4_elhcl_SDR_list =  optMapper.getConstantByField(map);
			double k4_elhcl_SDR = k4_elhcl_SDR_list.get(0).getValue();
			
		    map.put("fieldnm", "k5_eldust_SDR");
			List<CombusitionConsTantDTO> k5_eldust_SDR_list =  optMapper.getConstantByField(map);
			double k5_eldust_SDR = k5_eldust_SDR_list.get(0).getValue();
			
		    map.put("fieldnm", "k6_flydust_SDR");
			List<CombusitionConsTantDTO> k6_flydust_SDR_list =  optMapper.getConstantByField(map);
			double k6_flydust_SDR = k6_flydust_SDR_list.get(0).getValue();
			
		    map.put("fieldnm", "k7_hloss_SDR");
			List<CombusitionConsTantDTO> k7_hloss_SDR_list =  optMapper.getConstantByField(map);
			double k7_hloss_SDR = k7_hloss_SDR_list.get(0).getValue();
			
		    map.put("fieldnm", "k8_a2w_SDR");
			List<CombusitionConsTantDTO> k8_a2w_SDR_list =  optMapper.getConstantByField(map);
			double k8_a2w_SDR = k8_a2w_SDR_list.get(0).getValue();
			
		    map.put("fieldnm", "vpm_w2s");
			List<CombusitionConsTantDTO> vpm_w2s_list =  optMapper.getConstantByField(map);
			double vpm_w2s = vpm_w2s_list.get(0).getValue();
			
		    map.put("fieldnm", "sph_stm");
			List<CombusitionConsTantDTO> sph_stm_list =  optMapper.getConstantByField(map);
			double sph_stm = sph_stm_list.get(0).getValue();
			
		    map.put("fieldnm", "lath_w2s");
			List<CombusitionConsTantDTO> lath_w2s_list =  optMapper.getConstantByField(map);
			double lath_w2s = lath_w2s_list.get(0).getValue();
			
		    map.put("fieldnm", "ktemp");
			List<CombusitionConsTantDTO> ktemp_list =  optMapper.getConstantByField(map);
			double ktemp = ktemp_list.get(0).getValue();
			
		    map.put("fieldnm", "unit_mega");
			List<CombusitionConsTantDTO> unit_mega_list =  optMapper.getConstantByField(map);
			double unit_mega = unit_mega_list.get(0).getValue();
			
		    map.put("fieldnm", "molv_igas");
			List<CombusitionConsTantDTO> molv_igas_list =  optMapper.getConstantByField(map);
			double molv_igas = molv_igas_list.get(0).getValue();
			
		    map.put("fieldnm", "molm_so2");
			List<CombusitionConsTantDTO> molm_so2_list =  optMapper.getConstantByField(map);
			double molm_so2 = molm_so2_list.get(0).getValue();
			
		    map.put("fieldnm", "molm_caso4");
			List<CombusitionConsTantDTO> molm_caso4_list =  optMapper.getConstantByField(map);
			double molm_caso4 = molm_caso4_list.get(0).getValue();
			
		    map.put("fieldnm", "molm_hcl");
			List<CombusitionConsTantDTO> molm_hcl_list =  optMapper.getConstantByField(map);
			double molm_hcl = molm_hcl_list.get(0).getValue();
			
		    map.put("fieldnm", "molm_cacl2");
			List<CombusitionConsTantDTO> molm_cacl2_list =  optMapper.getConstantByField(map);
			double molm_cacl2 = molm_cacl2_list.get(0).getValue();
			
		    map.put("fieldnm", "molm_cao2h2");
			List<CombusitionConsTantDTO> molm_cao2h2_list =  optMapper.getConstantByField(map);
			double molm_cao2h2 = molm_cao2h2_list.get(0).getValue();
			
		    map.put("fieldnm", "rt_n2inair");
			List<CombusitionConsTantDTO> rt_n2inair_list =  optMapper.getConstantByField(map);
			double rt_n2inair = rt_n2inair_list.get(0).getValue();
			
		    map.put("fieldnm", "rt_o2inair");
			List<CombusitionConsTantDTO> rt_o2inair_list =  optMapper.getConstantByField(map);
			double rt_o2inair = rt_o2inair_list.get(0).getValue();
			
		    map.put("fieldnm", "min2hr");
			List<CombusitionConsTantDTO> min2hr_list =  optMapper.getConstantByField(map);
			double min2hr = min2hr_list.get(0).getValue();
			
		    map.put("fieldnm", "min2sec");
			List<CombusitionConsTantDTO> min2sec_list =  optMapper.getConstantByField(map);
			double min2sec = min2sec_list.get(0).getValue();
			
		    //
		    double mpv_dust_inSDR = ((mflow_flyash_waste_inSDR + mflow_flyash_ubw_inSDR) / vflow_gas_inSDR) * unit_mega;
		    
		    //
		    double vflow_drygas_inSDR = vflow_gas_inSDR - vflow_h2o_inSDR;
		    double vpercent_dryo2_inSDR = vflow_o2_inSDR / vflow_drygas_inSDR;
		    double vflow_calo2_drygas_inSDR = vflow_drygas_inSDR * ((0.21 - vpercent_dryo2_inSDR) / (0.21 - 0.12));
		    // 1차 코드에서 정의된 변수와 중복을 피하기 위해 vppm1을 사용함
		    // 금산군의 경우, 설계마진을 고려하여 인입 유해물질을 큰 상수값으로 입력함
		    double vppm1_so2_inSDR = (vflow_so2_inSDR / vflow_calo2_drygas_inSDR) * 1000000 * 0 + 200;
		    double vppm1_hcl_inSDR = (vflow_hcl_inSDR / vflow_calo2_drygas_inSDR) * 1000000 * 0 + 330;
		    //SDR 출구 농도
		    double vppm1_so2_outSDR = vppm1_so2_inSDR * (1.0 - k3_elso2_SDR);
		    double vppm1_hcl_outSDR = vppm1_hcl_inSDR * (1.0 - k4_elhcl_SDR);
		    //
		    // 이론 소석회 소모량
		    double mflow_cao2h2_elso2_SDR =
		      ((vppm1_so2_inSDR - vppm1_so2_outSDR) * 0.000001 * vflow_calo2_drygas_inSDR * molm_cao2h2) / (1 * 22.4);
		    double mflow_cao2h2_elhcl_SDR =
		      ((vppm1_hcl_inSDR - vppm1_hcl_outSDR) * 0.000001 * vflow_calo2_drygas_inSDR * molm_cao2h2) / (2 * 22.4);
		    double mflow_cao2h2_100p_SDR = mflow_cao2h2_elso2_SDR + mflow_cao2h2_elhcl_SDR;

		    // SDR에서 deSOx, deHcl 제거에 따른 소석회 반응 당량비
		    // 금산군은 1.5 --> 1.3 적용
		    double k1_re_SDR = 1.3;
		    // 실제공급소석회량
		    double mflow1_cao2h2_100p_SDR = k1_re_SDR * mflow_cao2h2_100p_SDR;
		    // 반입소석회 20%, 10%
		    double cao2h2_20p_SDR = 0.2;
		    double cao2h2_10p_SDR = 0.1;
		    double mflow1_cao2h2_20p_SDR = mflow_cao2h2_100p_SDR / cao2h2_20p_SDR;
		    //반입소석회량
		    double mflow_cao2h2_20p_SDR = mflow1_cao2h2_100p_SDR / cao2h2_20p_SDR;
		    //주입소석회량
		    double mflow_cao2h2_10p_SDR = mflow1_cao2h2_100p_SDR / cao2h2_10p_SDR;
		    double mflow_wtr_20p_SDR = mflow_cao2h2_20p_SDR - mflow1_cao2h2_100p_SDR;
		    //희석수량(10%인경우)
		    double mflow_wtr_10p_SDR = mflow_cao2h2_10p_SDR - mflow1_cao2h2_100p_SDR;
		    //희석용공정수필요량
		    double vflow_wtr_20p_SDR = (mflow_wtr_20p_SDR * molv_igas) / 18;
		    //
		    //
		    // 유해산성가스와 반응생성물 발생량
		    double molm_caso4_1 = 136.14;
		    double mflow_gencaso4_SDR = ((mflow_cao2h2_elso2_SDR * k1_re_SDR) / molm_cao2h2) * molm_caso4_1; // caso4
		    double mflow_gencacl2_SDR = ((mflow_cao2h2_elhcl_SDR * k1_re_SDR) / molm_cao2h2) * molm_cacl2; // cacl2
		    double mflow_notactcao2h2_SDR = mflow_cao2h2_20p_SDR - mflow1_cao2h2_20p_SDR; // cao2h2 (미반응소석회, 제일설계)
		    double mflow_total_genproduct_SDR = mflow_gencaso4_SDR + mflow_gencacl2_SDR + mflow_notactcao2h2_SDR;
		    // 금산군 미반응소석회량
		    double mflow_noact_product_SDR =
		      (mflow_cao2h2_elso2_SDR / 74) * 136 +
		      (mflow_cao2h2_elhcl_SDR / 74) * 111 +
		      (mflow1_cao2h2_100p_SDR - mflow_cao2h2_100p_SDR);
		    //
		    // SDR 하부 배출 비산재량
		    // k6 = 포집률
		    //
		    double mflow_flyash_inSDR = mflow_flyash_waste_inSDR + mflow_flyash_ubw_inSDR; //보일러 출구 비산재
		    double mflow_btmash_outSDR = (mflow_flyash_inSDR + mflow_noact_product_SDR) * k6_flydust_SDR; //SDR 포집 바닥재
		    double mflow_flyash_outSDR = (mflow_flyash_inSDR + mflow_noact_product_SDR) * (1 - k6_flydust_SDR); //SDR 출구 비산재 총량
		   
		    double mpv_flyash_outSDR = (mflow_flyash_outSDR / vflow_calo2_drygas_inSDR) * 1000000;

		    // 온도조절 냉각수량
		    //
		    //연소가스량 계산
		    //geneation - h2o
		    double mflow_genwtr_so2_SDR = (mflow_cao2h2_elso2_SDR * (1 * 22.4)) / molm_cao2h2;
		    double mflow_genwtr_hcl_SDR = (mflow_cao2h2_elhcl_SDR * (2 * 22.4)) / molm_cao2h2;
		    double mflow_genwtr_SDR = mflow_genwtr_so2_SDR + mflow_genwtr_hcl_SDR;
		    // 총생성된 수분량
		    double mflow_genwtr1_SDR = k1_re_SDR * mflow_genwtr_SDR;
		    //elimination - o2
		    double mflow_elo2_so2_SDR = (mflow_cao2h2_elso2_SDR * (0.5 * 22.4)) / (1 * molm_cao2h2);
		    //
		    // SDR 출구 연소가스량계산
		    //SOx
		    double vflow_so2_outSDR = vppm1_so2_outSDR * 0.000001 * vflow_calo2_drygas_inSDR;
		    //Hcl
		    double vflow_hcl_outSDR = vppm1_hcl_outSDR * 0.000001 * vflow_calo2_drygas_inSDR;
		    //
		    double vflow_delso2_SDR = vflow_so2_inSDR - vflow_so2_outSDR;
		    double vflow_delhcl_SDR = vflow_hcl_inSDR - vflow_hcl_outSDR;
		    
		    double cp_dgngas_outSDR = 0.3286;
		    
		    // 상기 식의 오류가 일부 있어 아래식으로 조정하여 사용함
		    double t5 = 100 - t_wtr_inSDR + lath_w2s + (t_dgngas_outSDR - 100) * sph_stm;
		    //
		    double cp_cw_inSDR = 1; //냉각수 비열
		    double t_cw_inSDR = 20; //냉각수 온도
		    double cp_cw_steam_inSDR = 0.3624; // 냉각수 증기 비열
		   
		    double cp_air_inSDR = returnCP_AIR(t_air_inSDR);
		    double qin1_inSDR = q_gas_inSDR * mflow_waste;
		    double a = cp_cw_inSDR * t_cw_inSDR; //냉각수 단위입열
		    double b = k8_a2w_SDR * cp_air_inSDR * t_air_inSDR; //압축공기 단위입열
		    double c = vflow_gas_inSDR * cp_dgngas_outSDR * t_dgngas_outSDR; //배가스 출열
		    double d = (22.4 / 18) * cp_cw_steam_inSDR + k8_a2w_SDR * cp_air_inSDR; // 냉각수 및 압축공기 단위출열
		    double f = 100 - t_cw_inSDR + lath_w2s + (t_dgngas_outSDR - 100) * sph_stm; //냉각수 현열 및 잠열
		    //출구 온도조절을 위한 냉각수량
		    double mflow_spwtr_inSDR =
		      ((1 - k7_hloss_SDR) * qin1_inSDR - c) / (f + (a + b) * (k7_hloss_SDR - 1) + t_dgngas_outSDR * d); //냉각수 총유량 계산

		    // 금산군의 경우, 냉각수량 상수 적용
		    mflow_spwtr_inSDR = 206.8;
		    double mflow_spwtr1_inSDR = 0;
		    if ( mflow_spwtr_inSDR >= mflow_wtr_20p_SDR) {
		      mflow_spwtr1_inSDR = mflow_spwtr_inSDR - mflow_wtr_20p_SDR;
		    } else {
		      mflow_spwtr1_inSDR = 0;
		      // call the system message
		      // "check the coolig water, must be greater than cao2h2 water
		    }

		    //
		    // 소석회 슬러리 및 냉각수 분무를 위한 압축 공기량 = 냉각수 + 희석수량(kg/hr) * 0.25 Nm3/kg
		    double mflow_compair_inSDR = mflow_wtr_20p_SDR;
		    double vflow_compair_inSDR = k8_a2w_SDR * mflow_spwtr_inSDR;
		    //
		    map.put("fieldnm", "mflow_spwtr_inSDR");
			map.put("value", mflow_spwtr_inSDR);
			pmap.put("mflow_spwtr_inSDR", mflow_spwtr_inSDR);
			optMapper.updatePipeoutValue(map);
		    
		    map.put("fieldnm", "mflow_compair_inSDR");
			map.put("value", mflow_compair_inSDR);
			pmap.put("mflow_compair_inSDR", mflow_compair_inSDR);
			optMapper.updatePipeoutValue(map);
		    // 실제 필요 냉각수량
		    double mflow_total_wtr_20p_inSDR = mflow_spwtr_inSDR - mflow_wtr_20p_SDR;
		    double vflow_total_wtr_20p_inSDR = (mflow_total_wtr_20p_inSDR * 22.4) / 18;
		    

		    //
		    // formula for mb-1
		    double vflow_co2_outSDR = vflow_co2_inSDR;
		    // 0degC에서 공기비중 = 1.293kg/NM3
		    // vflow_n2_outSDR = vflow_n2_inSDR + (mflow_compair_inSDR / sg_airat0c) * rt_n2inair;
		    double vflow_n2_outSDR = vflow_n2_inSDR + vflow_compair_inSDR * rt_n2inair;
		    // vflow_o2_outSDR = vflow_o2_inSDR + (mflow_compair_inSDR / sg_airat0c) * rt_o2inair;
		    double vflow_o2_outSDR = vflow_o2_inSDR + vflow_compair_inSDR * rt_o2inair;
		   
		    // ah_nm3 = ah_kg * (0.21*32 + 0.79 * 28)/18)
		    double ah_kg = 0.01469;
		    double ah_nm3 = (ah_kg * (0.21 * 32 + 0.79 * 28)) / 18;
		    //
		    double vflow_wtrincompair_SDR = (ah_nm3 + 1) * vflow_compair_inSDR;
		    double vflow_h2o_outSDR =
		      vflow_h2o_inSDR +
		      vflow_wtr_20p_SDR +
		      mflow_spwtr_inSDR * vpm_w2s +
		      mflow_genwtr1_SDR +
		      vflow_wtrincompair_SDR;
		    // 금산군에 적용된 수식 = 보일러출구 + 소석회슬러리희석수및냉각수분무량 + 산성가스제거시 생성된 수분량
		    vflow_h2o_outSDR =
		      vflow_h2o_inSDR +
		      vflow_wtr_20p_SDR +
		      mflow_spwtr1_inSDR * vpm_w2s +
		      mflow_genwtr_SDR;

		    //vflow_so2_outSDR = vflow_so2_inSDR * (1.0 - k3_elso2_SDR);
		    vflow_so2_outSDR = vflow_so2_outSDR;
		    //vflow_hcl_outSDR = vflow_hcl_inSDR * (1.0 - k4_elhcl_SDR);
		    vflow_hcl_outSDR = vflow_hcl_outSDR;
		    double vflow_no2_outSDR = (vppm_no2_inSDR * vflow_gas_inSDR) / 1000000;
		    double vflow_co_outSDR = (vppm_co_inSDR * vflow_gas_inSDR) / 1000000;
		    //
		    double vflow_gas_outSDR =
		      vflow_co2_outSDR +
		      vflow_n2_outSDR +
		      vflow_o2_outSDR +
		      vflow_no2_outSDR +
		      vflow_co_outSDR +
		      vflow_h2o_outSDR +
		      vflow_so2_outSDR +
		      vflow_hcl_outSDR;
		    double vflowa_gas_outSDR = vflow_gas_outSDR * ((ktemp + t_dgngas_outSDR) / ktemp);

		    // store to db after mb-1
		    map.put("fieldnm", "vflow_co2_outSDR");
			map.put("value", vflow_co2_outSDR);
			pmap.put("vflow_co2_outSDR", vflow_co2_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflow_n2_outSDR");
			map.put("value", vflow_n2_outSDR);
			pmap.put("vflow_n2_outSDR", vflow_n2_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflow_o2_outSDR");
			map.put("value", vflow_o2_outSDR);
			pmap.put("vflow_o2_outSDR", vflow_o2_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflow_h2o_outSDR");
			map.put("value", vflow_h2o_outSDR);
			pmap.put("vflow_h2o_outSDR", vflow_h2o_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflow_so2_outSDR");
			map.put("value", vflow_so2_outSDR);
			pmap.put("vflow_so2_outSDR", vflow_so2_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflow_hcl_outSDR");
			map.put("value", vflow_hcl_outSDR);
			pmap.put("vflow_hcl_outSDR", vflow_hcl_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflow_gas_outSDR");
			map.put("value", vflow_gas_outSDR);
			pmap.put("vflow_gas_outSDR", vflow_gas_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vflowa_gas_outSDR");
			map.put("value", vflowa_gas_outSDR);
			pmap.put("vflowa_gas_outSDR", vflowa_gas_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    //
		    // formula for hb2

		    double qi_wtr1_SDR = mflow_wtr_20p_SDR * t_wtr_inSDR * 1; // 희석수
		    double qi_wtr2_SDR = mflow_spwtr1_inSDR * t_cw_inSDR * cp_cw_inSDR; //
		    double qi_wtr_SDR = qi_wtr1_SDR + qi_wtr2_SDR;
		    double qi_air_SDR = vflow_compair_inSDR * t_air_inSDR * cp_air_inSDR;
		    double qi_flyash_SDR = q_flyash_waste_inSDR + q_flyash_ubw_inSDR;
		    double qi_gas_SDR = qin1_inSDR;
		    double qi_total_SDR =
		      qi_wtr_SDR +
		      qi_air_SDR +
		      qi_flyash_SDR +
		      qi_gas_SDR;
		    //
		    //SDR 출구 비산재 열량
		    double cp_genflyash_SDR = 0.3;
		    double t_genflyash_SDR = 170;
		    //
		    // qo_flyash_outSDR = cp_genflyash_SDR * t_genflyash_SDR * mflow_flyash_outSDR;
		    double qo_btmash_outSDR = cp_genflyash_SDR * t_genflyash_SDR * mflow_btmash_outSDR;
		    double qo_hloss_SDR = k7_hloss_SDR * qi_total_SDR; //방열손실
		    double q_gas_outSDR = vflow_gas_outSDR * cp_dgngas_outSDR * t_dgngas_outSDR; //SDR출구 연소가스
		    double qo_wtr_SDR = (mflow_spwtr1_inSDR + mflow_wtr_20p_SDR) * t5; // 수증기증발잠열
		    // qo_wtr_SDR = (mflow_spwtr1_inSDR + mflow_wtr_20p_SDR) * 620; // 수증기증발잠열
		    double qo_total_SDR =
		      // qo_flyash_outSDR +
		      qo_btmash_outSDR +
		      qo_hloss_SDR +
		      q_gas_outSDR +
		      qo_wtr_SDR;

		    // store to db after hb2
		    map.put("fieldnm", "qi_wtr_SDR");
			map.put("value", qi_wtr_SDR);
			pmap.put("qi_wtr_SDR", qi_wtr_SDR);
			optMapper.updatePipeoutValue(map);
			
		    
		    map.put("fieldnm", "qi_air_SDR");
			map.put("value", qi_air_SDR);
			pmap.put("qi_air_SDR", qi_air_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "qi_total_SDR");
			map.put("value", qi_total_SDR);
			pmap.put("qi_total_SDR", qi_total_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "qo_hloss_SDR");
			map.put("value", qo_hloss_SDR);
			pmap.put("qo_hloss_SDR", qo_hloss_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "q_gas_outSDR");
			map.put("value", q_gas_outSDR);
			pmap.put("q_gas_outSDR", q_gas_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "qo_wtr_SDR");
			map.put("value", qo_wtr_SDR);
			pmap.put("qo_wtr_SDR", qo_wtr_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "qo_total_SDR");
			map.put("value", qo_total_SDR);
			pmap.put("qo_total_SDR", qo_total_SDR);
			optMapper.updatePipeoutValue(map);
			
		    //
		    // formula for mb2-1
		    double vppm_no2_outSDR = (vppm_no2_inSDR * vflow_gas_inSDR) / vflow_gas_outSDR;
		    double vppm_co_outSDR = (vppm_co_inSDR * vflow_gas_inSDR) / vflow_gas_outSDR;
		    double mpv_dioxin_outSDR = mpv_dioxin_inSDR;

		    // store to db after mb2-1
		    map.put("fieldnm", "vppm_no2_outSDR");
			map.put("value", vppm_no2_outSDR);
			pmap.put("vppm_no2_outSDR", vppm_no2_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "vppm_co_outSDR");
			map.put("value", vppm_co_outSDR);
			pmap.put("vppm_co_outSDR", vppm_co_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mpv_dioxin_outSDR");
			map.put("value", mpv_dioxin_outSDR);
			pmap.put("mpv_dioxin_outSDR", mpv_dioxin_outSDR);
			optMapper.updatePipeoutValue(map);
		    //
		    // formula for mb2-2
		    double vppm_so2_outSDR =
		      (vppm_so2_inSDR * (1.0 - k3_elso2_SDR) * vflow_gas_inSDR) / vflow_gas_outSDR;

		    // store to db after mb2-2
		    map.put("fieldnm", "vppm_so2_outSDR");
			map.put("value", vppm_so2_outSDR);
			pmap.put("vppm_so2_outSDR", vppm_so2_outSDR);
			optMapper.updatePipeoutValue(map);
		    //
		    // formula for mb2-3
		    double vppm_hcl_outSDR =
		      (vppm_hcl_inSDR * (1.0 - k4_elhcl_SDR) * vflow_gas_inSDR) / vflow_gas_outSDR;

		    // store to db after mb2-3
		    map.put("fieldnm", "vppm_hcl_outSDR");
			map.put("value", vppm_hcl_outSDR);
			pmap.put("vppm_hcl_outSDR", vppm_hcl_outSDR);
			optMapper.updatePipeoutValue(map);
		    //
		    // formula for mb2-4
		    double mflow_so2_inSDR =
		      (molm_so2 / molv_igas) * ((vppm_so2_inSDR * vflow_gas_outSDR) / unit_mega);
		    double mflow_caso4_SDR = (mflow_so2_inSDR * molm_caso4) / molm_so2;
		    double mflow_hcl_inSDR =
		      (molm_hcl / molv_igas) * ((vppm_hcl_inSDR * vflow_gas_outSDR) / unit_mega);
		    double mflow_cacl2_SDR = (mflow_hcl_inSDR * molm_cacl2) / (molm_hcl * k1_hclncacl2_SDR);
		    double mflow_product_outSDR = mflow_caso4_SDR + mflow_cacl2_SDR;
		    double mflow_flydust_outSDR = mflow_product_outSDR * k6_flydust_SDR;
		    double mflow_btmdust_outSDR =
		      (mpv_dust_inSDR * (1.0 - k5_eldust_SDR) * vflow_gas_outSDR) / unit_mega;
		    double mflow_totaldust_outSDR =
		      mflow_btmdust_outSDR + mflow_flydust_outSDR;
		    double mpv_dust_outSDR =
		      (mflow_totaldust_outSDR / vflow_gas_outSDR) * unit_mega;

		    
		    //
		    // 새롭게 계산된 비산재 및 바닥재 적용
		    // formula for mb2-5
		    mflow_gencaso4_SDR = mflow_gencaso4_SDR;
		    mflow_gencacl2_SDR = mflow_gencacl2_SDR;
		    mflow_notactcao2h2_SDR = mflow_notactcao2h2_SDR;
		    
		    map.put("fieldnm", "mflow_gencaso4_SDR");
			map.put("value", mflow_gencaso4_SDR);
			pmap.put("mflow_gencaso4_SDR", mflow_gencaso4_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mflow_gencacl2_SDR");
			map.put("value", mflow_gencacl2_SDR);
			pmap.put("mflow_gencacl2_SDR", mflow_gencacl2_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mflow_notactcao2h2_SDR");
			map.put("value", mflow_notactcao2h2_SDR);
			pmap.put("mflow_notactcao2h2_SDR", mflow_notactcao2h2_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mflow_total_genproduct_SDR");
			map.put("value", mflow_total_genproduct_SDR);
			pmap.put("mflow_total_genproduct_SDR", mflow_total_genproduct_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mflow_total_genproduct_SDR");
			map.put("value", mflow_total_genproduct_SDR);
			pmap.put("mflow_total_genproduct_SDR", mflow_total_genproduct_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mflow_btmash_outSDR");
			map.put("value", mflow_btmash_outSDR);
			pmap.put("mflow_btmash_outSDR", mflow_btmash_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mflow_flyash_outSDR");
			map.put("value", mflow_flyash_outSDR);
			pmap.put("mflow_flyash_outSDR", mflow_flyash_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "mpv_flyash_outSDR");
			map.put("value", mpv_flyash_outSDR);
			pmap.put("mpv_flyash_outSDR", mpv_flyash_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    //
		    //
		    // formula mb3
		    double mflow1_cao2h2_inSDR = (mflow_so2_inSDR / molm_so2) * molm_cao2h2;
		    double mflow2_cao2h2_inSDR =
		      (mflow_hcl_inSDR / (molm_hcl * k2_hclncao2h2_SDR)) * molm_cao2h2;
		    double mflow_cao2h2_inSDR = mflow1_cao2h2_inSDR + mflow2_cao2h2_inSDR;
		    double mflow_cctcao2h2_inSDR = mflow_cao2h2_inSDR / cct_cao2h2_inSDR;

		    // store to db after mb3
		    map.put("fieldnm", "mflow_cao2h2_inSDR");
			map.put("value", mflow_cao2h2_inSDR);
			pmap.put("mflow_cao2h2_inSDR", mflow_cao2h2_inSDR);
			optMapper.updatePipeoutValue(map);

		    map.put("fieldnm", "mflow_cctcao2h2_inSDR");
			map.put("value", mflow_cctcao2h2_inSDR);
			pmap.put("mflow_cctcao2h2_inSDR", mflow_cctcao2h2_inSDR);
			optMapper.updatePipeoutValue(map);
			
			
		    // formula etc
		    double t_gas_outSDR = t_dgngas_outSDR;
		    double cp_gas_outSDR = cp_dgngas_outSDR;

		    // store to db after etc
		    //
		    
		    map.put("fieldnm", "t_gas_outSDR");
			map.put("value", t_gas_outSDR);
			pmap.put("t_gas_outSDR", t_gas_outSDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "cp_gas_outSDR");
			map.put("value", cp_gas_outSDR);
			pmap.put("cp_gas_outSDR", cp_gas_outSDR);
			optMapper.updatePipeoutValue(map);
			
			
			double CMM_volume_SDR = (vflow_gas_inSDR * (ktemp + t_gas_inSDR)) / ktemp / min2hr;
		    double m2_area_SDR = (CMM_volume_SDR * mps_gasvel_SDR) / min2sec;
		    double m_dim_SDR = Math.pow((4 * m2_area_SDR) / 3.14, 0.5) ;
		    double m_height_SDR =Math.pow(((((CMM_volume_SDR / min2sec) * sec_mrt_SDR) / 3.14) * (m_dim_SDR / 2)), 2) ;
		      

		    // store to db after "design of SDR"
		    map.put("fieldnm", "m2_area_SDR");
			map.put("value", m2_area_SDR);
			pmap.put("m2_area_SDR", m2_area_SDR);
			optMapper.updatePipeoutValue(map);
			
		    map.put("fieldnm", "m_dim_SDR");
			map.put("value", m_dim_SDR);
			pmap.put("m_dim_SDR", m_dim_SDR);
			optMapper.updatePipeoutValue(map);

			map.put("fieldnm", "m_height_SDR");
			map.put("value", m_height_SDR);
			pmap.put("m_height_SDR", m_height_SDR);
			optMapper.updatePipeoutValue(map);
			
			return pmap;
	}

	private double returnCP_AIR(double t_air) throws Exception {

		double n1 = Math.round(t_air * 0.01);
		double t1 = n1 * 100;
		double cp_air = 0;
		HashMap map = new HashMap();
		
		if (t1 == t_air) {
			map.put("temp", t_air);
			List<CombusitionCpDTO> cpdtolist = optMapper.getCpBytemp(map);
		    cp_air = cpdtolist.get(0).getAirlo();
		} else {
		    if (t_air < 100) {
		      cp_air = 0.31;
		    } else {
		      // const n2 = n1 + 1;
		      double t2 = t1 + 100;
		      // const c1 = gas_cptbl(n1, 11);
		      map.put("temp", t1);
			  List<CombusitionCpDTO> cpdtolist = optMapper.getCpBytemp(map);
		      double c1 = cpdtolist.get(0).getAirlo();
		      // const c2 = gas_cptbl(n2, 11);
		      map.put("temp", t2);
			  cpdtolist = optMapper.getCpBytemp(map);
		      double c2 = cpdtolist.get(0).getAirlo();
		      cp_air = ((t_air - t1) * (c1 - c2)) / (t1 - t2) + c1;

		    }
		}
		return cp_air;
	}
}
