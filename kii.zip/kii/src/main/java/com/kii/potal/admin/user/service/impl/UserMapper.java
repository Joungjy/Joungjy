package com.kii.potal.admin.user.service.impl;

import com.kii.potal.admin.user.dto.UserDTO;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    //사용자 리스트
    List<UserDTO> getUserList(UserDTO userDTO) throws Exception;

    //사용자 상세 정보
    UserDTO getUserItem(UserDTO userDTO)throws Exception;

    //사용자 정보 업데이트
    void updateUserItem(UserDTO userDTO)throws Exception;

    //사용자 정보 삽입
    void insertUserItem(UserDTO userDTO) throws Exception;

    void delUserItem(UserDTO userDTO) throws Exception;

    boolean getDuplicate(UserDTO userDTO) throws Exception;

}
